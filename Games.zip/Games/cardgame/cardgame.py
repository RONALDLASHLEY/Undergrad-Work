import sys, os
import random
from PIL import Image

print ("""This is the card game. The objective of the game
is to guess the card that I am holding. Good Luck!""")
print ("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")

cards = ['King', 'Queen', 'Jack', 'Ace', '2', '3', '4', '5', '6', '7', '8', '9', '10']
suits = ['Clubs', 'Diamonds', 'Hearts', 'Spades']
correct = 0
attempts = 0
path = "Cards/"
name = raw_input("Insert your name: ")

def cardgame():
    print """Guess a Card (Ex. King Of Clubs, Queen Of Diamonds, 
    Jack Of Hearts, Ace Of Spades, 2 Of Spades)."""
    guess = raw_input("Insert Guess: ")
    guess = guess.title()
    random_choice = (random.choice(cards)) + " Of " + (random.choice(suits))
    global correct
    global attempts
    if guess == random_choice:
        print "Great guess you were correct"
        print "The card was: ", random_choice
        card_name = guess.replace(' ', '_').lower() + '.png'
        card_img1 = Image.open(path + card_name)
        card_img1.show()
        correct = correct +1
        attempts = attempts+1
    else:
        print "Sorry you guessed the wrong card"
        print "The card was: ", random_choice
        rand_card_name = random_choice.replace(' ', '_').lower() + '.png'
        card_img2 = Image.open(path + rand_card_name)
        card_img2.show()
        print "You guessed : ", guess
        card_name = guess.replace(' ', '_').lower() + '.png'
        card_img1 = Image.open(path + card_name)
        card_img1.show()
        attempts = attempts +1

def try_again():
    tryagain = raw_input("Would you like to try again? ['YES' or 'NO']: ")
    if tryagain == 'YES':
        cardgame()
        try_again()
    else:
        print "\nThank you for playing, bye bye!\n"
        print "Name: " + name + "       Score: " + str(correct) + " / "  + str(attempts)

cardgame() #Soon be 'Play' Button
try_again() # Soon be 'Play Again' Button
import sys, os
import random

print ("""This is the dice game. The objective of 
the game is to get as many matching dice 
each roll. Here goes your first roll...""")
print ("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")

die1 = [1,2,3,4,5,6]
die2 = [1,2,3,4,5,6]
match_die = 0
rolls = 0
name = raw_input("Insert your name: ")

def dice_roll():
    roll1 = random.choice(die1)
    roll2 = random.choice(die2)
    global match_die
    global rolls
    print("You rolled a " + str(roll1) + " and a " + str(roll2))
    if roll1 == roll2:
        match_die = match_die + 1
        rolls = rolls + 1
    else:
        rolls = rolls + 1

def roll_again():
    rollagain = raw_input("Would you like to roll again? ['YES' or 'NO']: ")
    if rollagain == 'YES':
        dice_roll()
        roll_again()
    else:
        print ("\nThank you for playing, bye bye!\n")
        print "Name: " +  name + "  Score: " + str(match_die) + "/" + str(rolls)

dice_roll()
roll_again()
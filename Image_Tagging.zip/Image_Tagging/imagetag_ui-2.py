# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'mainwindow-2.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui, uic
from PyQt4 import *
from PyQt4.QtGui import *
from PyQt4.QtCore import *
import sys
import glob, os

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName(_fromUtf8("MainWindow"))
        MainWindow.resize(650, 475)
        
        self.centralWidget = QtGui.QWidget(MainWindow)
        self.centralWidget.setObjectName(_fromUtf8("centralWidget"))
        
        self.verticalLayout = QtGui.QVBoxLayout(self.centralWidget)
        self.verticalLayout.setMargin(11)
        self.verticalLayout.setSpacing(6)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setMargin(11)
        self.horizontalLayout_2.setSpacing(6)
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))

        self.label = QtGui.QLabel(self.centralWidget)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label.sizePolicy().hasHeightForWidth())
        self.label.setSizePolicy(sizePolicy)
        self.label.setObjectName(_fromUtf8("label"))
        self.horizontalLayout_2.addWidget(self.label)
        
        self.comboBox = QtGui.QComboBox(self.centralWidget)
        self.comboBox.setEditable(True)
        self.comboBox.setInsertPolicy(QtGui.QComboBox.InsertAlphabetically)
        self.comboBox.setObjectName(_fromUtf8("comboBox"))
        
        self.horizontalLayout_2.addWidget(self.comboBox)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        
        spacerItem = QtGui.QSpacerItem(20, 10, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Fixed)
        self.verticalLayout.addItem(spacerItem)
        
        self.label_2 = QtGui.QLabel(self.centralWidget)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.verticalLayout.addWidget(self.label_2)
        
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setMargin(11)
        self.horizontalLayout_3.setSpacing(6)
        self.horizontalLayout_3.setObjectName(_fromUtf8("horizontalLayout_3"))
        
        self.verticalLayout_4 = QtGui.QVBoxLayout()
        self.verticalLayout_4.setMargin(11)
        self.verticalLayout_4.setSpacing(6)
        self.verticalLayout_4.setObjectName(_fromUtf8("verticalLayout_4"))
        
        self.label_3 = QtGui.QLabel(self.centralWidget)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.verticalLayout_4.addWidget(self.label_3)
        
        self.columnView = QtGui.QColumnView(self.centralWidget)
        self.columnView.setAcceptDrops(True)
        self.columnView.setDragDropOverwriteMode(True)
        self.columnView.setDragDropMode(QtGui.QAbstractItemView.DragDrop)
        self.columnView.setDefaultDropAction(QtCore.Qt.MoveAction)
        self.columnView.setObjectName(_fromUtf8("columnView"))
        self.verticalLayout_4.addWidget(self.columnView)
        
        self.horizontalLayout_3.addLayout(self.verticalLayout_4)
        spacerItem1 = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.horizontalLayout_3.addItem(spacerItem1)
        
        self.verticalLayout_2 = QtGui.QVBoxLayout()
        self.verticalLayout_2.setMargin(11)
        self.verticalLayout_2.setSpacing(6)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))

        self.label_4 = QtGui.QLabel(self.centralWidget)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.verticalLayout_2.addWidget(self.label_4)
        
        self.columnView_2 = QtGui.QColumnView(self.centralWidget)
        self.columnView_2.setAcceptDrops(True)
        self.columnView_2.setDragDropMode(QtGui.QAbstractItemView.DragDrop)
        self.columnView_2.setDefaultDropAction(QtCore.Qt.MoveAction)
        self.columnView_2.setObjectName(_fromUtf8("columnView_2"))
        self.verticalLayout_2.addWidget(self.columnView_2)
        
        self.horizontalLayout_3.addLayout(self.verticalLayout_2)
        self.verticalLayout.addLayout(self.horizontalLayout_3)
    
        self.progressBar = QtGui.QProgressBar(self.centralWidget)
        self.progressBar.setProperty("value", 2)
        self.progressBar.setObjectName(_fromUtf8("progressBar"))
        self.verticalLayout.addWidget(self.progressBar)
        
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.verticalLayout.addItem(spacerItem2)
        
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setMargin(11)
        self.horizontalLayout.setSpacing(6)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        
        self.pushButton = QtGui.QPushButton(self.centralWidget)
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.horizontalLayout.addWidget(self.pushButton)
        
        self.pushButton_2 = QtGui.QPushButton(self.centralWidget)
        self.pushButton_2.setObjectName(_fromUtf8("pushButton_2"))
        self.horizontalLayout.addWidget(self.pushButton_2)
        
        self.pushButton_3 = QtGui.QPushButton(self.centralWidget)
        self.pushButton_3.setObjectName(_fromUtf8("pushButton_3"))
        self.horizontalLayout.addWidget(self.pushButton_3)
        self.verticalLayout.addLayout(self.horizontalLayout)
        
        #MainWindow.setCentralWidget(self.centralWidget)
        #MainWindow.addToolBar(QtCore.Qt.TopToolBarArea, self.mainToolBar)
        self.statusBar = QtGui.QStatusBar(MainWindow)
        self.statusBar.setObjectName(_fromUtf8("statusBar"))
        #MainWindow.setStatusBar(self.statusBar)
        self.Buttons()
        self.combo_chosen()
        
        self.retranslateUi(MainWindow)


    #def Images(self):
        

    def Buttons(self):
        
        self.pushButton.clicked.connect(self.load)
        
        self.pushButton_2.clicked.connect(self.save)

        self.pushButton_3.clicked.connect(self.predict)

    def combo_chosen(self):
        """
        Handler called when a tag is chosen from the combo box
        """
        os.chdir("/Users/rlashley/Desktop/Image_Tagging/Tags")
        for files in glob.glob("*.*"):
            tagList = [files]
            self.comboBox.addItems(tagList)
            print(files)

        self.comboBox.currentIndexChanged.connect(self.selected)

    def selected(self):
        print "Current tag selected: ",self.comboBox.currentText()
        
    def load(self):
        print ("load")
        dir_ = QtGui.QFileDialog.getExistingDirectory(None, 'Select a folder:', 'C:/', QtGui.QFileDialog.ShowDirsOnly)
        #name = QtGui.QFileDialog.getOpenFileName(dir_, 'Open File')
        print str((dir_))
        os.chdir(str(dir_))
        for files in glob.glob("*.png"):
            print ("Loaded Images:" + (str((files))))

    def save(self):
        name = QtGui.QFileDialog.getSaveFileName(None, 'Save As', '/path/to/default/directory', selectedFilter='*.xml')
        if name:
            print ("Saved as: " + name)

    def predict(self):
        print ("Soon I will predict, but now I shall Quit!")
        sys.exit()
        
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(_translate("MainWindow", "ImageTagger", None))
        self.label.setText(_translate("MainWindow", "Current tag: ", None))
        self.label_2.setText(_translate("MainWindow", "<html><head/><body><p>Click on the incorrectly labeled images below to send them to the opposite group (positive &lt;==&gt; negative)</p></body></html>", None))
        self.label_3.setText(_translate("MainWindow", "Positive samples:", None))
        self.label_4.setText(_translate("MainWindow", "Negative samples:", None))
        self.pushButton.setText(_translate("MainWindow", "&Load ...", None))
        self.pushButton_2.setText(_translate("MainWindow", "&Save ...", None))
        self.pushButton_3.setText(_translate("MainWindow", "&Predict", None))
#Image Gallery#######################################################################################
class ImagePopup(QLabel):
    """ 
    The ImagePopup class is a QLabel that displays a popup, zoomed image 
    on top of another label.  
    """
    def __init__(self, parent):
        super(QLabel, self).__init__(parent)
        
        thumb = parent.pixmap()
        imageSize = thumb.size()
        imageSize.setWidth(imageSize.width()*2)
        imageSize.setHeight(imageSize.height()*2)
        self.setPixmap(thumb.scaled(imageSize,Qt.KeepAspectRatioByExpanding))
        
        # center the zoomed image on the thumb
        position = self.cursor().pos()
        position.setX(position.x() - thumb.size().width())
        position.setY(position.y() - thumb.size().height())
        self.move(position)
        
        # FramelessWindowHint may not work on some window managers on Linux
        # so I force also the flag X11BypassWindowManagerHint
        self.setWindowFlags(Qt.Popup | Qt.WindowStaysOnTopHint 
                            | Qt.FramelessWindowHint 
                            | Qt.X11BypassWindowManagerHint)

    def leaveEvent(self, event):
        """ When the mouse leave this widget, destroy it. """
        self.destroy()
        

class ImageLabel(QLabel):
    """ This widget displays an ImagePopup when the mouse enter its region """
    def enterEvent(self, event):
        self.p = ImagePopup(self)
        self.p.show()
        event.accept() 

class ImageGallery(QDialog):
    
    def __init__(self, parent=None):
        super(QDialog, self).__init__(parent)
        self.setWindowTitle("Image Gallery")
        self.setLayout(QGridLayout(self))
    
    def populate(self, pics, size, imagesPerRow=3, 
                 flags=Qt.KeepAspectRatioByExpanding):
        row = col = 0
        for pic in pics:
            label = ImageLabel("")
            pixmap = QPixmap(pic)
            pixmap = pixmap.scaled(size, flags)
            label.setPixmap(pixmap)
            self.layout().addWidget(label, row, col)
            col +=1
            if col % imagesPerRow == 0:
                row += 1
                col = 0
#Image Gallery####################################################################################
def main():
    app = QtGui.QApplication(sys.argv)
    widget = QtGui.QWidget() # or whatever your top-level class is
    ui = Ui_MainWindow()
    ui.setupUi(widget)
    widget.show()
    #
    os.chdir("C:/Users/rlashley/Desktop/Image_Tagging/Images")
    for files in glob.glob("*.png"):
        print("Images in folder:" + files)
        pics = [files]*6
        ig = ImageGallery()
        ig.populate(pics, QSize(48,48))
        ig.show()
    app.exec_()

if __name__ == '__main__':
    main()


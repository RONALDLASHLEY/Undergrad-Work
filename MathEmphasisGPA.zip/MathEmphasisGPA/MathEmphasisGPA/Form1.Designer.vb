﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.CheckBox5 = New System.Windows.Forms.CheckBox()
        Me.CheckBox7 = New System.Windows.Forms.CheckBox()
        Me.CheckBox9 = New System.Windows.Forms.CheckBox()
        Me.CheckBox11 = New System.Windows.Forms.CheckBox()
        Me.CheckBox12 = New System.Windows.Forms.CheckBox()
        Me.CheckBoxLangII = New System.Windows.Forms.CheckBox()
        Me.CheckBoxLangI = New System.Windows.Forms.CheckBox()
        Me.CheckBox13 = New System.Windows.Forms.CheckBox()
        Me.CheckBox10 = New System.Windows.Forms.CheckBox()
        Me.CheckBox8 = New System.Windows.Forms.CheckBox()
        Me.CheckBox6 = New System.Windows.Forms.CheckBox()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG13 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG12 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG11 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG10 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG9 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG8 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG7 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG6 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG5 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG4 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG3 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG2 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG1 = New System.Windows.Forms.ComboBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP13 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP13 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle13 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit13 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP12 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP12 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle12 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit12 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP11 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP11 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle11 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit11 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP10 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP10 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle10 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit10 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP9 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP9 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle9 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit9 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP8 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP8 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP7 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle8 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit8 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP7 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP6 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle7 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit7 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP5 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP6 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP5 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP4 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle6 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit6 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP4 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP3 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle5 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit5 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP3 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle4 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP2 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit4 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP2 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle3 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP1 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit3 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle2 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP1 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle1 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit2 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit1 = New System.Windows.Forms.TextBox()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.ButtonResetUni = New System.Windows.Forms.Button()
        Me.LabelGPA = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.CheckBox14 = New System.Windows.Forms.CheckBox()
        Me.CheckBox15 = New System.Windows.Forms.CheckBox()
        Me.CheckBox16 = New System.Windows.Forms.CheckBox()
        Me.CheckBox17 = New System.Windows.Forms.CheckBox()
        Me.CheckBox18 = New System.Windows.Forms.CheckBox()
        Me.CheckBox20 = New System.Windows.Forms.CheckBox()
        Me.CheckBox21 = New System.Windows.Forms.CheckBox()
        Me.CheckBox22 = New System.Windows.Forms.CheckBox()
        Me.CheckBox23 = New System.Windows.Forms.CheckBox()
        Me.CheckBox24 = New System.Windows.Forms.CheckBox()
        Me.CheckBox25 = New System.Windows.Forms.CheckBox()
        Me.CheckBox19 = New System.Windows.Forms.CheckBox()
        Me.ComboBoxLG25 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG24 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG23 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG22 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG21 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG20 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG19 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG18 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG17 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG16 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG15 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG14 = New System.Windows.Forms.ComboBox()
        Me.TextBoxQP25 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP25 = New System.Windows.Forms.TextBox()
        Me.TextBoxCoureTitle25 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit25 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP24 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP24 = New System.Windows.Forms.TextBox()
        Me.TextBoxCoureTitle24 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit24 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP23 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP23 = New System.Windows.Forms.TextBox()
        Me.TextBoxCoureTitle23 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit23 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP22 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP22 = New System.Windows.Forms.TextBox()
        Me.TextBoxCoureTitle22 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit22 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP21 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP21 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP20 = New System.Windows.Forms.TextBox()
        Me.TextBoxCoureTitle21 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit21 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP20 = New System.Windows.Forms.TextBox()
        Me.TextBoxCoureTitle20 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP19 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit20 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP18 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP19 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP18 = New System.Windows.Forms.TextBox()
        Me.TextBoxCoureTitle19 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP17 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit19 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP17 = New System.Windows.Forms.TextBox()
        Me.TextBoxCoureTitle18 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP16 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit18 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP16 = New System.Windows.Forms.TextBox()
        Me.TextBoxCoureTitle17 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP15 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit17 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP15 = New System.Windows.Forms.TextBox()
        Me.TextBoxCoureTitle16 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP14 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit16 = New System.Windows.Forms.TextBox()
        Me.TextBoxCoureTitle15 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP14 = New System.Windows.Forms.TextBox()
        Me.TextBoxCoureTitle14 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit15 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit14 = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.ButtonResetMajor = New System.Windows.Forms.Button()
        Me.LabelGPAMajor = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.CheckBox26 = New System.Windows.Forms.CheckBox()
        Me.CheckBox27 = New System.Windows.Forms.CheckBox()
        Me.CheckBox28 = New System.Windows.Forms.CheckBox()
        Me.CheckBox29 = New System.Windows.Forms.CheckBox()
        Me.CheckBox30 = New System.Windows.Forms.CheckBox()
        Me.ComboBoxLG30 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG29 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG28 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG27 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG26 = New System.Windows.Forms.ComboBox()
        Me.TextBoxQP30 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP30 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP29 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP29 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP28 = New System.Windows.Forms.TextBox()
        Me.TextBoxCoureTitle30 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit30 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP28 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP27 = New System.Windows.Forms.TextBox()
        Me.TextBoxCoureTitle29 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit29 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP27 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP26 = New System.Windows.Forms.TextBox()
        Me.TextBoxCoureTitle28 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit28 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP26 = New System.Windows.Forms.TextBox()
        Me.TextBoxCoureTitle27 = New System.Windows.Forms.TextBox()
        Me.TextBoxCoureTitle26 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit27 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit26 = New System.Windows.Forms.TextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.ButtonReseTMinor = New System.Windows.Forms.Button()
        Me.LabelGPAMinor = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.CheckBox31 = New System.Windows.Forms.CheckBox()
        Me.CheckBox32 = New System.Windows.Forms.CheckBox()
        Me.CheckBox33 = New System.Windows.Forms.CheckBox()
        Me.CheckBox34 = New System.Windows.Forms.CheckBox()
        Me.CheckBox35 = New System.Windows.Forms.CheckBox()
        Me.CheckBox36 = New System.Windows.Forms.CheckBox()
        Me.CheckBox37 = New System.Windows.Forms.CheckBox()
        Me.CheckBox38 = New System.Windows.Forms.CheckBox()
        Me.CheckBox39 = New System.Windows.Forms.CheckBox()
        Me.ComboBoxLG39 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG38 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG37 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG36 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG35 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG34 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG33 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG32 = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLG31 = New System.Windows.Forms.ComboBox()
        Me.TextBoxQP39 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP39 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle39 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseID9 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit39 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP38 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP38 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP37 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle38 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseID8 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit38 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP37 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle37 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseID7 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP36 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit37 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP35 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP36 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP35 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle36 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseID6 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP34 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit36 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle35 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP34 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseID5 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP33 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit35 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle34 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP33 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseID4 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP32 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit34 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle33 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP32 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseID3 = New System.Windows.Forms.TextBox()
        Me.TextBoxQP31 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle32 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit33 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseID2 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseTitle31 = New System.Windows.Forms.TextBox()
        Me.TextBoxTQP31 = New System.Windows.Forms.TextBox()
        Me.TextBoxCourseID1 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit32 = New System.Windows.Forms.TextBox()
        Me.TextBoxCredit31 = New System.Windows.Forms.TextBox()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.ResetElectives = New System.Windows.Forms.Button()
        Me.LabelGPAElectives = New System.Windows.Forms.Label()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.LabelCGPA = New System.Windows.Forms.Label()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.LabelGPAGen = New System.Windows.Forms.Label()
        Me.LabelSNGen = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.LabelErrorsGen = New System.Windows.Forms.Label()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.LabelGPAMi = New System.Windows.Forms.Label()
        Me.LabelSNMi = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.LabelErrorsMi = New System.Windows.Forms.Label()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.LabelGPAMa = New System.Windows.Forms.Label()
        Me.LabelSNM = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.LabelErrorsM = New System.Windows.Forms.Label()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.LabelGPAUni = New System.Windows.Forms.Label()
        Me.LabelSN = New System.Windows.Forms.Label()
        Me.LabelErrors = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.LabelTitle = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.LabelMath = New System.Windows.Forms.Label()
        Me.LabelTotalCredits = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.Panel14.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.TabControl1.Location = New System.Drawing.Point(3, 101)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.ShowToolTips = True
        Me.TabControl1.Size = New System.Drawing.Size(1075, 776)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.White
        Me.TabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage1.Controls.Add(Me.Panel4)
        Me.TabPage1.Controls.Add(Me.Panel3)
        Me.TabPage1.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage1.Location = New System.Drawing.Point(4, 34)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1067, 738)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "University Requirements"
        Me.TabPage1.ToolTipText = "All requirements must be completed before graduation"
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.CheckBox5)
        Me.Panel4.Controls.Add(Me.CheckBox7)
        Me.Panel4.Controls.Add(Me.CheckBox9)
        Me.Panel4.Controls.Add(Me.CheckBox11)
        Me.Panel4.Controls.Add(Me.CheckBox12)
        Me.Panel4.Controls.Add(Me.CheckBoxLangII)
        Me.Panel4.Controls.Add(Me.CheckBoxLangI)
        Me.Panel4.Controls.Add(Me.CheckBox13)
        Me.Panel4.Controls.Add(Me.CheckBox10)
        Me.Panel4.Controls.Add(Me.CheckBox8)
        Me.Panel4.Controls.Add(Me.CheckBox6)
        Me.Panel4.Controls.Add(Me.CheckBox4)
        Me.Panel4.Controls.Add(Me.CheckBox3)
        Me.Panel4.Controls.Add(Me.CheckBox2)
        Me.Panel4.Controls.Add(Me.CheckBox1)
        Me.Panel4.Controls.Add(Me.ComboBox2)
        Me.Panel4.Controls.Add(Me.ComboBox1)
        Me.Panel4.Controls.Add(Me.ComboBoxLG13)
        Me.Panel4.Controls.Add(Me.ComboBoxLG12)
        Me.Panel4.Controls.Add(Me.ComboBoxLG11)
        Me.Panel4.Controls.Add(Me.ComboBoxLG10)
        Me.Panel4.Controls.Add(Me.ComboBoxLG9)
        Me.Panel4.Controls.Add(Me.ComboBoxLG8)
        Me.Panel4.Controls.Add(Me.ComboBoxLG7)
        Me.Panel4.Controls.Add(Me.ComboBoxLG6)
        Me.Panel4.Controls.Add(Me.ComboBoxLG5)
        Me.Panel4.Controls.Add(Me.ComboBoxLG4)
        Me.Panel4.Controls.Add(Me.ComboBoxLG3)
        Me.Panel4.Controls.Add(Me.ComboBoxLG2)
        Me.Panel4.Controls.Add(Me.ComboBoxLG1)
        Me.Panel4.Controls.Add(Me.TextBox8)
        Me.Panel4.Controls.Add(Me.TextBox4)
        Me.Panel4.Controls.Add(Me.TextBoxQP13)
        Me.Panel4.Controls.Add(Me.TextBox7)
        Me.Panel4.Controls.Add(Me.TextBox3)
        Me.Panel4.Controls.Add(Me.TextBoxTQP13)
        Me.Panel4.Controls.Add(Me.TextBox6)
        Me.Panel4.Controls.Add(Me.TextBox2)
        Me.Panel4.Controls.Add(Me.TextBoxCourseTitle13)
        Me.Panel4.Controls.Add(Me.TextBox5)
        Me.Panel4.Controls.Add(Me.TextBox1)
        Me.Panel4.Controls.Add(Me.TextBoxCredit13)
        Me.Panel4.Controls.Add(Me.TextBoxQP12)
        Me.Panel4.Controls.Add(Me.TextBoxTQP12)
        Me.Panel4.Controls.Add(Me.TextBoxCourseTitle12)
        Me.Panel4.Controls.Add(Me.TextBoxCredit12)
        Me.Panel4.Controls.Add(Me.TextBoxQP11)
        Me.Panel4.Controls.Add(Me.TextBoxTQP11)
        Me.Panel4.Controls.Add(Me.TextBoxCourseTitle11)
        Me.Panel4.Controls.Add(Me.TextBoxCredit11)
        Me.Panel4.Controls.Add(Me.TextBoxQP10)
        Me.Panel4.Controls.Add(Me.TextBoxTQP10)
        Me.Panel4.Controls.Add(Me.TextBoxCourseTitle10)
        Me.Panel4.Controls.Add(Me.TextBoxCredit10)
        Me.Panel4.Controls.Add(Me.TextBoxQP9)
        Me.Panel4.Controls.Add(Me.TextBoxTQP9)
        Me.Panel4.Controls.Add(Me.TextBoxCourseTitle9)
        Me.Panel4.Controls.Add(Me.TextBoxCredit9)
        Me.Panel4.Controls.Add(Me.TextBoxQP8)
        Me.Panel4.Controls.Add(Me.TextBoxTQP8)
        Me.Panel4.Controls.Add(Me.TextBoxQP7)
        Me.Panel4.Controls.Add(Me.TextBoxCourseTitle8)
        Me.Panel4.Controls.Add(Me.TextBoxCredit8)
        Me.Panel4.Controls.Add(Me.TextBoxTQP7)
        Me.Panel4.Controls.Add(Me.TextBoxQP6)
        Me.Panel4.Controls.Add(Me.TextBoxCourseTitle7)
        Me.Panel4.Controls.Add(Me.TextBoxCredit7)
        Me.Panel4.Controls.Add(Me.TextBoxQP5)
        Me.Panel4.Controls.Add(Me.TextBoxTQP6)
        Me.Panel4.Controls.Add(Me.TextBoxTQP5)
        Me.Panel4.Controls.Add(Me.TextBoxQP4)
        Me.Panel4.Controls.Add(Me.TextBoxCourseTitle6)
        Me.Panel4.Controls.Add(Me.TextBoxCredit6)
        Me.Panel4.Controls.Add(Me.TextBoxTQP4)
        Me.Panel4.Controls.Add(Me.TextBoxQP3)
        Me.Panel4.Controls.Add(Me.TextBoxCourseTitle5)
        Me.Panel4.Controls.Add(Me.TextBoxCredit5)
        Me.Panel4.Controls.Add(Me.TextBoxTQP3)
        Me.Panel4.Controls.Add(Me.TextBoxCourseTitle4)
        Me.Panel4.Controls.Add(Me.TextBoxQP2)
        Me.Panel4.Controls.Add(Me.TextBoxCredit4)
        Me.Panel4.Controls.Add(Me.TextBoxTQP2)
        Me.Panel4.Controls.Add(Me.TextBoxCourseTitle3)
        Me.Panel4.Controls.Add(Me.TextBoxQP1)
        Me.Panel4.Controls.Add(Me.TextBoxCredit3)
        Me.Panel4.Controls.Add(Me.TextBoxCourseTitle2)
        Me.Panel4.Controls.Add(Me.TextBoxTQP1)
        Me.Panel4.Controls.Add(Me.TextBoxCourseTitle1)
        Me.Panel4.Controls.Add(Me.TextBoxCredit2)
        Me.Panel4.Controls.Add(Me.TextBoxCredit1)
        Me.Panel4.Controls.Add(Me.Label65)
        Me.Panel4.Controls.Add(Me.Label14)
        Me.Panel4.Controls.Add(Me.Label64)
        Me.Panel4.Controls.Add(Me.Label9)
        Me.Panel4.Controls.Add(Me.Label17)
        Me.Panel4.Controls.Add(Me.Label13)
        Me.Panel4.Controls.Add(Me.Label12)
        Me.Panel4.Controls.Add(Me.Label16)
        Me.Panel4.Controls.Add(Me.Label8)
        Me.Panel4.Controls.Add(Me.Label11)
        Me.Panel4.Controls.Add(Me.Label15)
        Me.Panel4.Controls.Add(Me.Label7)
        Me.Panel4.Controls.Add(Me.Label10)
        Me.Panel4.Controls.Add(Me.Label6)
        Me.Panel4.Controls.Add(Me.Label5)
        Me.Panel4.Controls.Add(Me.Label19)
        Me.Panel4.Controls.Add(Me.Label4)
        Me.Panel4.Controls.Add(Me.Label3)
        Me.Panel4.Controls.Add(Me.Label40)
        Me.Panel4.Controls.Add(Me.Label18)
        Me.Panel4.Controls.Add(Me.Label2)
        Me.Panel4.Controls.Add(Me.Label1)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(3, 3)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1057, 666)
        Me.Panel4.TabIndex = 0
        '
        'CheckBox5
        '
        Me.CheckBox5.AutoSize = True
        Me.CheckBox5.Enabled = False
        Me.CheckBox5.ForeColor = System.Drawing.Color.Orange
        Me.CheckBox5.Location = New System.Drawing.Point(969, 225)
        Me.CheckBox5.Name = "CheckBox5"
        Me.CheckBox5.Size = New System.Drawing.Size(59, 22)
        Me.CheckBox5.TabIndex = 4
        Me.CheckBox5.Text = "False"
        Me.CheckBox5.UseVisualStyleBackColor = True
        '
        'CheckBox7
        '
        Me.CheckBox7.AutoSize = True
        Me.CheckBox7.Enabled = False
        Me.CheckBox7.ForeColor = System.Drawing.Color.Orange
        Me.CheckBox7.Location = New System.Drawing.Point(969, 305)
        Me.CheckBox7.Name = "CheckBox7"
        Me.CheckBox7.Size = New System.Drawing.Size(59, 22)
        Me.CheckBox7.TabIndex = 4
        Me.CheckBox7.Text = "False"
        Me.CheckBox7.UseVisualStyleBackColor = True
        '
        'CheckBox9
        '
        Me.CheckBox9.AutoSize = True
        Me.CheckBox9.Enabled = False
        Me.CheckBox9.ForeColor = System.Drawing.Color.Orange
        Me.CheckBox9.Location = New System.Drawing.Point(969, 385)
        Me.CheckBox9.Name = "CheckBox9"
        Me.CheckBox9.Size = New System.Drawing.Size(59, 22)
        Me.CheckBox9.TabIndex = 4
        Me.CheckBox9.Text = "False"
        Me.CheckBox9.UseVisualStyleBackColor = True
        '
        'CheckBox11
        '
        Me.CheckBox11.AutoSize = True
        Me.CheckBox11.Enabled = False
        Me.CheckBox11.ForeColor = System.Drawing.Color.Orange
        Me.CheckBox11.Location = New System.Drawing.Point(969, 465)
        Me.CheckBox11.Name = "CheckBox11"
        Me.CheckBox11.Size = New System.Drawing.Size(59, 22)
        Me.CheckBox11.TabIndex = 4
        Me.CheckBox11.Text = "False"
        Me.CheckBox11.UseVisualStyleBackColor = True
        '
        'CheckBox12
        '
        Me.CheckBox12.AutoSize = True
        Me.CheckBox12.Enabled = False
        Me.CheckBox12.ForeColor = System.Drawing.Color.Orange
        Me.CheckBox12.Location = New System.Drawing.Point(969, 504)
        Me.CheckBox12.Name = "CheckBox12"
        Me.CheckBox12.Size = New System.Drawing.Size(59, 22)
        Me.CheckBox12.TabIndex = 4
        Me.CheckBox12.Text = "False"
        Me.CheckBox12.UseVisualStyleBackColor = True
        '
        'CheckBoxLangII
        '
        Me.CheckBoxLangII.AutoSize = True
        Me.CheckBoxLangII.Enabled = False
        Me.CheckBoxLangII.ForeColor = System.Drawing.Color.Orange
        Me.CheckBoxLangII.Location = New System.Drawing.Point(969, 638)
        Me.CheckBoxLangII.Name = "CheckBoxLangII"
        Me.CheckBoxLangII.Size = New System.Drawing.Size(59, 22)
        Me.CheckBoxLangII.TabIndex = 4
        Me.CheckBoxLangII.Text = "False"
        Me.CheckBoxLangII.UseVisualStyleBackColor = True
        '
        'CheckBoxLangI
        '
        Me.CheckBoxLangI.AutoSize = True
        Me.CheckBoxLangI.Enabled = False
        Me.CheckBoxLangI.ForeColor = System.Drawing.Color.Orange
        Me.CheckBoxLangI.Location = New System.Drawing.Point(969, 592)
        Me.CheckBoxLangI.Name = "CheckBoxLangI"
        Me.CheckBoxLangI.Size = New System.Drawing.Size(59, 22)
        Me.CheckBoxLangI.TabIndex = 4
        Me.CheckBoxLangI.Text = "False"
        Me.CheckBoxLangI.UseVisualStyleBackColor = True
        '
        'CheckBox13
        '
        Me.CheckBox13.AutoSize = True
        Me.CheckBox13.Enabled = False
        Me.CheckBox13.ForeColor = System.Drawing.Color.Orange
        Me.CheckBox13.Location = New System.Drawing.Point(969, 549)
        Me.CheckBox13.Name = "CheckBox13"
        Me.CheckBox13.Size = New System.Drawing.Size(59, 22)
        Me.CheckBox13.TabIndex = 4
        Me.CheckBox13.Text = "False"
        Me.CheckBox13.UseVisualStyleBackColor = True
        '
        'CheckBox10
        '
        Me.CheckBox10.AutoSize = True
        Me.CheckBox10.Enabled = False
        Me.CheckBox10.ForeColor = System.Drawing.Color.Orange
        Me.CheckBox10.Location = New System.Drawing.Point(969, 425)
        Me.CheckBox10.Name = "CheckBox10"
        Me.CheckBox10.Size = New System.Drawing.Size(59, 22)
        Me.CheckBox10.TabIndex = 4
        Me.CheckBox10.Text = "False"
        Me.CheckBox10.UseVisualStyleBackColor = True
        '
        'CheckBox8
        '
        Me.CheckBox8.AutoSize = True
        Me.CheckBox8.Enabled = False
        Me.CheckBox8.ForeColor = System.Drawing.Color.Orange
        Me.CheckBox8.Location = New System.Drawing.Point(969, 345)
        Me.CheckBox8.Name = "CheckBox8"
        Me.CheckBox8.Size = New System.Drawing.Size(59, 22)
        Me.CheckBox8.TabIndex = 4
        Me.CheckBox8.Text = "False"
        Me.CheckBox8.UseVisualStyleBackColor = True
        '
        'CheckBox6
        '
        Me.CheckBox6.AutoSize = True
        Me.CheckBox6.Enabled = False
        Me.CheckBox6.ForeColor = System.Drawing.Color.Orange
        Me.CheckBox6.Location = New System.Drawing.Point(969, 268)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(59, 22)
        Me.CheckBox6.TabIndex = 4
        Me.CheckBox6.Text = "False"
        Me.CheckBox6.UseVisualStyleBackColor = True
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Enabled = False
        Me.CheckBox4.ForeColor = System.Drawing.Color.Orange
        Me.CheckBox4.Location = New System.Drawing.Point(969, 186)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(59, 22)
        Me.CheckBox4.TabIndex = 4
        Me.CheckBox4.Text = "False"
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Enabled = False
        Me.CheckBox3.ForeColor = System.Drawing.Color.Orange
        Me.CheckBox3.Location = New System.Drawing.Point(969, 146)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(59, 22)
        Me.CheckBox3.TabIndex = 4
        Me.CheckBox3.Text = "False"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Enabled = False
        Me.CheckBox2.ForeColor = System.Drawing.Color.Orange
        Me.CheckBox2.Location = New System.Drawing.Point(969, 105)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(59, 22)
        Me.CheckBox2.TabIndex = 4
        Me.CheckBox2.Text = "False"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Enabled = False
        Me.CheckBox1.ForeColor = System.Drawing.Color.Orange
        Me.CheckBox1.Location = New System.Drawing.Point(969, 69)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(59, 22)
        Me.CheckBox1.TabIndex = 4
        Me.CheckBox1.Text = "False"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'ComboBox2
        '
        Me.ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox2.Enabled = False
        Me.ComboBox2.ForeColor = System.Drawing.Color.Orange
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBox2.Location = New System.Drawing.Point(575, 634)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(82, 26)
        Me.ComboBox2.TabIndex = 3
        '
        'ComboBox1
        '
        Me.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox1.Enabled = False
        Me.ComboBox1.ForeColor = System.Drawing.Color.Orange
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBox1.Location = New System.Drawing.Point(575, 588)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(82, 26)
        Me.ComboBox1.TabIndex = 3
        '
        'ComboBoxLG13
        '
        Me.ComboBoxLG13.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG13.ForeColor = System.Drawing.Color.Orange
        Me.ComboBoxLG13.FormattingEnabled = True
        Me.ComboBoxLG13.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG13.Location = New System.Drawing.Point(575, 545)
        Me.ComboBoxLG13.Name = "ComboBoxLG13"
        Me.ComboBoxLG13.Size = New System.Drawing.Size(82, 26)
        Me.ComboBoxLG13.TabIndex = 3
        '
        'ComboBoxLG12
        '
        Me.ComboBoxLG12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG12.ForeColor = System.Drawing.Color.Orange
        Me.ComboBoxLG12.FormattingEnabled = True
        Me.ComboBoxLG12.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG12.Location = New System.Drawing.Point(575, 504)
        Me.ComboBoxLG12.Name = "ComboBoxLG12"
        Me.ComboBoxLG12.Size = New System.Drawing.Size(82, 26)
        Me.ComboBoxLG12.TabIndex = 3
        '
        'ComboBoxLG11
        '
        Me.ComboBoxLG11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG11.ForeColor = System.Drawing.Color.Orange
        Me.ComboBoxLG11.FormattingEnabled = True
        Me.ComboBoxLG11.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG11.Location = New System.Drawing.Point(575, 465)
        Me.ComboBoxLG11.Name = "ComboBoxLG11"
        Me.ComboBoxLG11.Size = New System.Drawing.Size(82, 26)
        Me.ComboBoxLG11.TabIndex = 3
        '
        'ComboBoxLG10
        '
        Me.ComboBoxLG10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG10.ForeColor = System.Drawing.Color.Orange
        Me.ComboBoxLG10.FormattingEnabled = True
        Me.ComboBoxLG10.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG10.Location = New System.Drawing.Point(575, 425)
        Me.ComboBoxLG10.Name = "ComboBoxLG10"
        Me.ComboBoxLG10.Size = New System.Drawing.Size(82, 26)
        Me.ComboBoxLG10.TabIndex = 3
        '
        'ComboBoxLG9
        '
        Me.ComboBoxLG9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG9.ForeColor = System.Drawing.Color.Orange
        Me.ComboBoxLG9.FormattingEnabled = True
        Me.ComboBoxLG9.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG9.Location = New System.Drawing.Point(575, 385)
        Me.ComboBoxLG9.Name = "ComboBoxLG9"
        Me.ComboBoxLG9.Size = New System.Drawing.Size(82, 26)
        Me.ComboBoxLG9.TabIndex = 3
        '
        'ComboBoxLG8
        '
        Me.ComboBoxLG8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG8.ForeColor = System.Drawing.Color.Orange
        Me.ComboBoxLG8.FormattingEnabled = True
        Me.ComboBoxLG8.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG8.Location = New System.Drawing.Point(575, 345)
        Me.ComboBoxLG8.Name = "ComboBoxLG8"
        Me.ComboBoxLG8.Size = New System.Drawing.Size(82, 26)
        Me.ComboBoxLG8.TabIndex = 3
        '
        'ComboBoxLG7
        '
        Me.ComboBoxLG7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG7.ForeColor = System.Drawing.Color.Orange
        Me.ComboBoxLG7.FormattingEnabled = True
        Me.ComboBoxLG7.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG7.Location = New System.Drawing.Point(575, 305)
        Me.ComboBoxLG7.Name = "ComboBoxLG7"
        Me.ComboBoxLG7.Size = New System.Drawing.Size(82, 26)
        Me.ComboBoxLG7.TabIndex = 3
        '
        'ComboBoxLG6
        '
        Me.ComboBoxLG6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG6.ForeColor = System.Drawing.Color.Orange
        Me.ComboBoxLG6.FormattingEnabled = True
        Me.ComboBoxLG6.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG6.Location = New System.Drawing.Point(575, 265)
        Me.ComboBoxLG6.Name = "ComboBoxLG6"
        Me.ComboBoxLG6.Size = New System.Drawing.Size(82, 26)
        Me.ComboBoxLG6.TabIndex = 3
        '
        'ComboBoxLG5
        '
        Me.ComboBoxLG5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG5.ForeColor = System.Drawing.Color.Orange
        Me.ComboBoxLG5.FormattingEnabled = True
        Me.ComboBoxLG5.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG5.Location = New System.Drawing.Point(575, 225)
        Me.ComboBoxLG5.Name = "ComboBoxLG5"
        Me.ComboBoxLG5.Size = New System.Drawing.Size(82, 26)
        Me.ComboBoxLG5.TabIndex = 3
        '
        'ComboBoxLG4
        '
        Me.ComboBoxLG4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG4.ForeColor = System.Drawing.Color.Orange
        Me.ComboBoxLG4.FormattingEnabled = True
        Me.ComboBoxLG4.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG4.Location = New System.Drawing.Point(575, 185)
        Me.ComboBoxLG4.Name = "ComboBoxLG4"
        Me.ComboBoxLG4.Size = New System.Drawing.Size(82, 26)
        Me.ComboBoxLG4.TabIndex = 3
        '
        'ComboBoxLG3
        '
        Me.ComboBoxLG3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG3.ForeColor = System.Drawing.Color.Orange
        Me.ComboBoxLG3.FormattingEnabled = True
        Me.ComboBoxLG3.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG3.Location = New System.Drawing.Point(575, 146)
        Me.ComboBoxLG3.Name = "ComboBoxLG3"
        Me.ComboBoxLG3.Size = New System.Drawing.Size(82, 26)
        Me.ComboBoxLG3.TabIndex = 3
        '
        'ComboBoxLG2
        '
        Me.ComboBoxLG2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG2.ForeColor = System.Drawing.Color.Orange
        Me.ComboBoxLG2.FormattingEnabled = True
        Me.ComboBoxLG2.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG2.Location = New System.Drawing.Point(575, 105)
        Me.ComboBoxLG2.Name = "ComboBoxLG2"
        Me.ComboBoxLG2.Size = New System.Drawing.Size(82, 26)
        Me.ComboBoxLG2.TabIndex = 3
        '
        'ComboBoxLG1
        '
        Me.ComboBoxLG1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG1.ForeColor = System.Drawing.Color.Orange
        Me.ComboBoxLG1.FormattingEnabled = True
        Me.ComboBoxLG1.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG1.Location = New System.Drawing.Point(575, 69)
        Me.ComboBoxLG1.Name = "ComboBoxLG1"
        Me.ComboBoxLG1.Size = New System.Drawing.Size(82, 26)
        Me.ComboBoxLG1.TabIndex = 3
        '
        'TextBox8
        '
        Me.TextBox8.Enabled = False
        Me.TextBox8.Location = New System.Drawing.Point(697, 635)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(100, 25)
        Me.TextBox8.TabIndex = 2
        '
        'TextBox4
        '
        Me.TextBox4.Enabled = False
        Me.TextBox4.Location = New System.Drawing.Point(697, 589)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 25)
        Me.TextBox4.TabIndex = 2
        '
        'TextBoxQP13
        '
        Me.TextBoxQP13.Enabled = False
        Me.TextBoxQP13.Location = New System.Drawing.Point(697, 546)
        Me.TextBoxQP13.Name = "TextBoxQP13"
        Me.TextBoxQP13.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxQP13.TabIndex = 2
        '
        'TextBox7
        '
        Me.TextBox7.Enabled = False
        Me.TextBox7.Location = New System.Drawing.Point(829, 635)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(100, 25)
        Me.TextBox7.TabIndex = 2
        '
        'TextBox3
        '
        Me.TextBox3.Enabled = False
        Me.TextBox3.Location = New System.Drawing.Point(829, 589)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 25)
        Me.TextBox3.TabIndex = 2
        '
        'TextBoxTQP13
        '
        Me.TextBoxTQP13.Enabled = False
        Me.TextBoxTQP13.Location = New System.Drawing.Point(829, 546)
        Me.TextBoxTQP13.Name = "TextBoxTQP13"
        Me.TextBoxTQP13.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxTQP13.TabIndex = 2
        '
        'TextBox6
        '
        Me.TextBox6.Enabled = False
        Me.TextBox6.Location = New System.Drawing.Point(153, 637)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(271, 25)
        Me.TextBox6.TabIndex = 2
        Me.TextBox6.Text = "Complete Computer Prog II"
        '
        'TextBox2
        '
        Me.TextBox2.Enabled = False
        Me.TextBox2.Location = New System.Drawing.Point(153, 591)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(271, 25)
        Me.TextBox2.TabIndex = 2
        Me.TextBox2.Text = "Complete Computer Prog I"
        '
        'TextBoxCourseTitle13
        '
        Me.TextBoxCourseTitle13.Enabled = False
        Me.TextBoxCourseTitle13.Location = New System.Drawing.Point(153, 548)
        Me.TextBoxCourseTitle13.Name = "TextBoxCourseTitle13"
        Me.TextBoxCourseTitle13.Size = New System.Drawing.Size(271, 25)
        Me.TextBoxCourseTitle13.TabIndex = 2
        Me.TextBoxCourseTitle13.Text = "Intro to Music or Art"
        '
        'TextBox5
        '
        Me.TextBox5.Enabled = False
        Me.TextBox5.Location = New System.Drawing.Point(451, 635)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(100, 25)
        Me.TextBox5.TabIndex = 2
        '
        'TextBox1
        '
        Me.TextBox1.Enabled = False
        Me.TextBox1.Location = New System.Drawing.Point(451, 589)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 25)
        Me.TextBox1.TabIndex = 2
        '
        'TextBoxCredit13
        '
        Me.TextBoxCredit13.Location = New System.Drawing.Point(451, 546)
        Me.TextBoxCredit13.Name = "TextBoxCredit13"
        Me.TextBoxCredit13.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxCredit13.TabIndex = 2
        '
        'TextBoxQP12
        '
        Me.TextBoxQP12.Enabled = False
        Me.TextBoxQP12.Location = New System.Drawing.Point(697, 506)
        Me.TextBoxQP12.Name = "TextBoxQP12"
        Me.TextBoxQP12.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxQP12.TabIndex = 2
        '
        'TextBoxTQP12
        '
        Me.TextBoxTQP12.Enabled = False
        Me.TextBoxTQP12.Location = New System.Drawing.Point(829, 506)
        Me.TextBoxTQP12.Name = "TextBoxTQP12"
        Me.TextBoxTQP12.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxTQP12.TabIndex = 2
        '
        'TextBoxCourseTitle12
        '
        Me.TextBoxCourseTitle12.Enabled = False
        Me.TextBoxCourseTitle12.Location = New System.Drawing.Point(153, 508)
        Me.TextBoxCourseTitle12.Name = "TextBoxCourseTitle12"
        Me.TextBoxCourseTitle12.Size = New System.Drawing.Size(271, 25)
        Me.TextBoxCourseTitle12.TabIndex = 2
        Me.TextBoxCourseTitle12.Text = "Intro to Philosopy or Religion"
        '
        'TextBoxCredit12
        '
        Me.TextBoxCredit12.Location = New System.Drawing.Point(451, 506)
        Me.TextBoxCredit12.Name = "TextBoxCredit12"
        Me.TextBoxCredit12.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxCredit12.TabIndex = 2
        '
        'TextBoxQP11
        '
        Me.TextBoxQP11.Enabled = False
        Me.TextBoxQP11.Location = New System.Drawing.Point(697, 465)
        Me.TextBoxQP11.Name = "TextBoxQP11"
        Me.TextBoxQP11.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxQP11.TabIndex = 2
        '
        'TextBoxTQP11
        '
        Me.TextBoxTQP11.Enabled = False
        Me.TextBoxTQP11.Location = New System.Drawing.Point(829, 465)
        Me.TextBoxTQP11.Name = "TextBoxTQP11"
        Me.TextBoxTQP11.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxTQP11.TabIndex = 2
        '
        'TextBoxCourseTitle11
        '
        Me.TextBoxCourseTitle11.Enabled = False
        Me.TextBoxCourseTitle11.Location = New System.Drawing.Point(153, 467)
        Me.TextBoxCourseTitle11.Name = "TextBoxCourseTitle11"
        Me.TextBoxCourseTitle11.Size = New System.Drawing.Size(271, 25)
        Me.TextBoxCourseTitle11.TabIndex = 2
        Me.TextBoxCourseTitle11.Text = "Dimensions of Wellness"
        '
        'TextBoxCredit11
        '
        Me.TextBoxCredit11.Location = New System.Drawing.Point(451, 465)
        Me.TextBoxCredit11.Name = "TextBoxCredit11"
        Me.TextBoxCredit11.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxCredit11.TabIndex = 2
        '
        'TextBoxQP10
        '
        Me.TextBoxQP10.Enabled = False
        Me.TextBoxQP10.Location = New System.Drawing.Point(697, 426)
        Me.TextBoxQP10.Name = "TextBoxQP10"
        Me.TextBoxQP10.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxQP10.TabIndex = 2
        '
        'TextBoxTQP10
        '
        Me.TextBoxTQP10.Enabled = False
        Me.TextBoxTQP10.Location = New System.Drawing.Point(829, 426)
        Me.TextBoxTQP10.Name = "TextBoxTQP10"
        Me.TextBoxTQP10.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxTQP10.TabIndex = 2
        '
        'TextBoxCourseTitle10
        '
        Me.TextBoxCourseTitle10.Enabled = False
        Me.TextBoxCourseTitle10.Location = New System.Drawing.Point(153, 428)
        Me.TextBoxCourseTitle10.Name = "TextBoxCourseTitle10"
        Me.TextBoxCourseTitle10.Size = New System.Drawing.Size(271, 25)
        Me.TextBoxCourseTitle10.TabIndex = 2
        Me.TextBoxCourseTitle10.Text = "Math-106 or Above"
        '
        'TextBoxCredit10
        '
        Me.TextBoxCredit10.Location = New System.Drawing.Point(451, 426)
        Me.TextBoxCredit10.Name = "TextBoxCredit10"
        Me.TextBoxCredit10.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxCredit10.TabIndex = 2
        '
        'TextBoxQP9
        '
        Me.TextBoxQP9.Enabled = False
        Me.TextBoxQP9.Location = New System.Drawing.Point(697, 386)
        Me.TextBoxQP9.Name = "TextBoxQP9"
        Me.TextBoxQP9.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxQP9.TabIndex = 2
        '
        'TextBoxTQP9
        '
        Me.TextBoxTQP9.Enabled = False
        Me.TextBoxTQP9.Location = New System.Drawing.Point(829, 386)
        Me.TextBoxTQP9.Name = "TextBoxTQP9"
        Me.TextBoxTQP9.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxTQP9.TabIndex = 2
        '
        'TextBoxCourseTitle9
        '
        Me.TextBoxCourseTitle9.Location = New System.Drawing.Point(153, 388)
        Me.TextBoxCourseTitle9.Name = "TextBoxCourseTitle9"
        Me.TextBoxCourseTitle9.Size = New System.Drawing.Size(271, 25)
        Me.TextBoxCourseTitle9.TabIndex = 2
        Me.TextBoxCourseTitle9.Text = "Science 2"
        '
        'TextBoxCredit9
        '
        Me.TextBoxCredit9.Location = New System.Drawing.Point(451, 386)
        Me.TextBoxCredit9.Name = "TextBoxCredit9"
        Me.TextBoxCredit9.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxCredit9.TabIndex = 2
        '
        'TextBoxQP8
        '
        Me.TextBoxQP8.Enabled = False
        Me.TextBoxQP8.Location = New System.Drawing.Point(697, 346)
        Me.TextBoxQP8.Name = "TextBoxQP8"
        Me.TextBoxQP8.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxQP8.TabIndex = 2
        '
        'TextBoxTQP8
        '
        Me.TextBoxTQP8.Enabled = False
        Me.TextBoxTQP8.Location = New System.Drawing.Point(829, 346)
        Me.TextBoxTQP8.Name = "TextBoxTQP8"
        Me.TextBoxTQP8.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxTQP8.TabIndex = 2
        '
        'TextBoxQP7
        '
        Me.TextBoxQP7.Enabled = False
        Me.TextBoxQP7.Location = New System.Drawing.Point(697, 306)
        Me.TextBoxQP7.Name = "TextBoxQP7"
        Me.TextBoxQP7.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxQP7.TabIndex = 2
        '
        'TextBoxCourseTitle8
        '
        Me.TextBoxCourseTitle8.Location = New System.Drawing.Point(153, 348)
        Me.TextBoxCourseTitle8.Name = "TextBoxCourseTitle8"
        Me.TextBoxCourseTitle8.Size = New System.Drawing.Size(271, 25)
        Me.TextBoxCourseTitle8.TabIndex = 2
        Me.TextBoxCourseTitle8.Text = "Science 1"
        '
        'TextBoxCredit8
        '
        Me.TextBoxCredit8.Location = New System.Drawing.Point(451, 346)
        Me.TextBoxCredit8.Name = "TextBoxCredit8"
        Me.TextBoxCredit8.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxCredit8.TabIndex = 2
        '
        'TextBoxTQP7
        '
        Me.TextBoxTQP7.Enabled = False
        Me.TextBoxTQP7.Location = New System.Drawing.Point(829, 306)
        Me.TextBoxTQP7.Name = "TextBoxTQP7"
        Me.TextBoxTQP7.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxTQP7.TabIndex = 2
        '
        'TextBoxQP6
        '
        Me.TextBoxQP6.Enabled = False
        Me.TextBoxQP6.Location = New System.Drawing.Point(697, 266)
        Me.TextBoxQP6.Name = "TextBoxQP6"
        Me.TextBoxQP6.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxQP6.TabIndex = 2
        '
        'TextBoxCourseTitle7
        '
        Me.TextBoxCourseTitle7.Location = New System.Drawing.Point(153, 308)
        Me.TextBoxCourseTitle7.Name = "TextBoxCourseTitle7"
        Me.TextBoxCourseTitle7.Size = New System.Drawing.Size(271, 25)
        Me.TextBoxCourseTitle7.TabIndex = 2
        Me.TextBoxCourseTitle7.Text = "Social Science 2"
        '
        'TextBoxCredit7
        '
        Me.TextBoxCredit7.Location = New System.Drawing.Point(451, 306)
        Me.TextBoxCredit7.Name = "TextBoxCredit7"
        Me.TextBoxCredit7.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxCredit7.TabIndex = 2
        '
        'TextBoxQP5
        '
        Me.TextBoxQP5.Enabled = False
        Me.TextBoxQP5.Location = New System.Drawing.Point(697, 226)
        Me.TextBoxQP5.Name = "TextBoxQP5"
        Me.TextBoxQP5.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxQP5.TabIndex = 2
        '
        'TextBoxTQP6
        '
        Me.TextBoxTQP6.Enabled = False
        Me.TextBoxTQP6.Location = New System.Drawing.Point(829, 266)
        Me.TextBoxTQP6.Name = "TextBoxTQP6"
        Me.TextBoxTQP6.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxTQP6.TabIndex = 2
        '
        'TextBoxTQP5
        '
        Me.TextBoxTQP5.Enabled = False
        Me.TextBoxTQP5.Location = New System.Drawing.Point(829, 226)
        Me.TextBoxTQP5.Name = "TextBoxTQP5"
        Me.TextBoxTQP5.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxTQP5.TabIndex = 2
        '
        'TextBoxQP4
        '
        Me.TextBoxQP4.Enabled = False
        Me.TextBoxQP4.Location = New System.Drawing.Point(697, 186)
        Me.TextBoxQP4.Name = "TextBoxQP4"
        Me.TextBoxQP4.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxQP4.TabIndex = 2
        '
        'TextBoxCourseTitle6
        '
        Me.TextBoxCourseTitle6.Location = New System.Drawing.Point(153, 268)
        Me.TextBoxCourseTitle6.Name = "TextBoxCourseTitle6"
        Me.TextBoxCourseTitle6.Size = New System.Drawing.Size(271, 25)
        Me.TextBoxCourseTitle6.TabIndex = 2
        Me.TextBoxCourseTitle6.Text = "Social Science 1"
        '
        'TextBoxCredit6
        '
        Me.TextBoxCredit6.Location = New System.Drawing.Point(451, 266)
        Me.TextBoxCredit6.Name = "TextBoxCredit6"
        Me.TextBoxCredit6.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxCredit6.TabIndex = 2
        '
        'TextBoxTQP4
        '
        Me.TextBoxTQP4.Enabled = False
        Me.TextBoxTQP4.Location = New System.Drawing.Point(829, 186)
        Me.TextBoxTQP4.Name = "TextBoxTQP4"
        Me.TextBoxTQP4.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxTQP4.TabIndex = 2
        '
        'TextBoxQP3
        '
        Me.TextBoxQP3.Enabled = False
        Me.TextBoxQP3.Location = New System.Drawing.Point(697, 146)
        Me.TextBoxQP3.Name = "TextBoxQP3"
        Me.TextBoxQP3.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxQP3.TabIndex = 2
        '
        'TextBoxCourseTitle5
        '
        Me.TextBoxCourseTitle5.Enabled = False
        Me.TextBoxCourseTitle5.Location = New System.Drawing.Point(153, 228)
        Me.TextBoxCourseTitle5.Name = "TextBoxCourseTitle5"
        Me.TextBoxCourseTitle5.Size = New System.Drawing.Size(271, 25)
        Me.TextBoxCourseTitle5.TabIndex = 2
        Me.TextBoxCourseTitle5.Text = "World Lit I or II"
        '
        'TextBoxCredit5
        '
        Me.TextBoxCredit5.Location = New System.Drawing.Point(451, 226)
        Me.TextBoxCredit5.Name = "TextBoxCredit5"
        Me.TextBoxCredit5.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxCredit5.TabIndex = 2
        '
        'TextBoxTQP3
        '
        Me.TextBoxTQP3.Enabled = False
        Me.TextBoxTQP3.Location = New System.Drawing.Point(829, 146)
        Me.TextBoxTQP3.Name = "TextBoxTQP3"
        Me.TextBoxTQP3.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxTQP3.TabIndex = 2
        '
        'TextBoxCourseTitle4
        '
        Me.TextBoxCourseTitle4.Enabled = False
        Me.TextBoxCourseTitle4.Location = New System.Drawing.Point(153, 188)
        Me.TextBoxCourseTitle4.Name = "TextBoxCourseTitle4"
        Me.TextBoxCourseTitle4.Size = New System.Drawing.Size(271, 25)
        Me.TextBoxCourseTitle4.TabIndex = 2
        Me.TextBoxCourseTitle4.Text = "English Composition II"
        '
        'TextBoxQP2
        '
        Me.TextBoxQP2.Enabled = False
        Me.TextBoxQP2.Location = New System.Drawing.Point(697, 107)
        Me.TextBoxQP2.Name = "TextBoxQP2"
        Me.TextBoxQP2.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxQP2.TabIndex = 2
        '
        'TextBoxCredit4
        '
        Me.TextBoxCredit4.Location = New System.Drawing.Point(451, 186)
        Me.TextBoxCredit4.Name = "TextBoxCredit4"
        Me.TextBoxCredit4.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxCredit4.TabIndex = 2
        '
        'TextBoxTQP2
        '
        Me.TextBoxTQP2.Enabled = False
        Me.TextBoxTQP2.Location = New System.Drawing.Point(829, 107)
        Me.TextBoxTQP2.Name = "TextBoxTQP2"
        Me.TextBoxTQP2.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxTQP2.TabIndex = 2
        '
        'TextBoxCourseTitle3
        '
        Me.TextBoxCourseTitle3.Enabled = False
        Me.TextBoxCourseTitle3.Location = New System.Drawing.Point(153, 148)
        Me.TextBoxCourseTitle3.Name = "TextBoxCourseTitle3"
        Me.TextBoxCourseTitle3.Size = New System.Drawing.Size(271, 25)
        Me.TextBoxCourseTitle3.TabIndex = 2
        Me.TextBoxCourseTitle3.Text = "English Composition I"
        '
        'TextBoxQP1
        '
        Me.TextBoxQP1.Enabled = False
        Me.TextBoxQP1.Location = New System.Drawing.Point(697, 70)
        Me.TextBoxQP1.Name = "TextBoxQP1"
        Me.TextBoxQP1.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxQP1.TabIndex = 2
        '
        'TextBoxCredit3
        '
        Me.TextBoxCredit3.Location = New System.Drawing.Point(451, 146)
        Me.TextBoxCredit3.Name = "TextBoxCredit3"
        Me.TextBoxCredit3.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxCredit3.TabIndex = 2
        '
        'TextBoxCourseTitle2
        '
        Me.TextBoxCourseTitle2.Enabled = False
        Me.TextBoxCourseTitle2.Location = New System.Drawing.Point(153, 109)
        Me.TextBoxCourseTitle2.Name = "TextBoxCourseTitle2"
        Me.TextBoxCourseTitle2.Size = New System.Drawing.Size(271, 25)
        Me.TextBoxCourseTitle2.TabIndex = 2
        Me.TextBoxCourseTitle2.Text = "African American Experience"
        '
        'TextBoxTQP1
        '
        Me.TextBoxTQP1.Enabled = False
        Me.TextBoxTQP1.Location = New System.Drawing.Point(829, 70)
        Me.TextBoxTQP1.Name = "TextBoxTQP1"
        Me.TextBoxTQP1.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxTQP1.TabIndex = 2
        '
        'TextBoxCourseTitle1
        '
        Me.TextBoxCourseTitle1.Enabled = False
        Me.TextBoxCourseTitle1.Location = New System.Drawing.Point(153, 72)
        Me.TextBoxCourseTitle1.Name = "TextBoxCourseTitle1"
        Me.TextBoxCourseTitle1.Size = New System.Drawing.Size(271, 25)
        Me.TextBoxCourseTitle1.TabIndex = 2
        Me.TextBoxCourseTitle1.Text = "First Year Experience"
        '
        'TextBoxCredit2
        '
        Me.TextBoxCredit2.Location = New System.Drawing.Point(451, 107)
        Me.TextBoxCredit2.Name = "TextBoxCredit2"
        Me.TextBoxCredit2.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxCredit2.TabIndex = 2
        '
        'TextBoxCredit1
        '
        Me.TextBoxCredit1.Location = New System.Drawing.Point(451, 70)
        Me.TextBoxCredit1.Name = "TextBoxCredit1"
        Me.TextBoxCredit1.Size = New System.Drawing.Size(100, 25)
        Me.TextBoxCredit1.TabIndex = 2
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.ForeColor = System.Drawing.Color.Orange
        Me.Label65.Location = New System.Drawing.Point(14, 642)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(116, 18)
        Me.Label65.TabIndex = 1
        Me.Label65.Text = "LANG 2 (CSC159)"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.ForeColor = System.Drawing.Color.Orange
        Me.Label14.Location = New System.Drawing.Point(14, 433)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(122, 18)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "MAT 106 or Above"
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.ForeColor = System.Drawing.Color.Orange
        Me.Label64.Location = New System.Drawing.Point(14, 596)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(116, 18)
        Me.Label64.TabIndex = 1
        Me.Label64.Text = "LANG 1 (CSC158)"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.Color.Orange
        Me.Label9.Location = New System.Drawing.Point(14, 233)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(102, 18)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "ENG 207 or 208"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.ForeColor = System.Drawing.Color.Orange
        Me.Label17.Location = New System.Drawing.Point(14, 553)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(134, 18)
        Me.Label17.TabIndex = 1
        Me.Label17.Text = "ART 200 or MUS 200"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ForeColor = System.Drawing.Color.Orange
        Me.Label13.Location = New System.Drawing.Point(14, 393)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(76, 18)
        Me.Label13.TabIndex = 1
        Me.Label13.Text = "SCIENCE 2"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.ForeColor = System.Drawing.Color.Orange
        Me.Label12.Location = New System.Drawing.Point(14, 354)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(79, 18)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "SCIENCE 1 "
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.ForeColor = System.Drawing.Color.Orange
        Me.Label16.Location = New System.Drawing.Point(14, 513)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(127, 18)
        Me.Label16.TabIndex = 1
        Me.Label16.Text = "REL 200 or PHL 200"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.Color.Orange
        Me.Label8.Location = New System.Drawing.Point(14, 192)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(62, 18)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "ENG 102"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.Color.Orange
        Me.Label11.Location = New System.Drawing.Point(14, 313)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(107, 18)
        Me.Label11.TabIndex = 1
        Me.Label11.Text = "SOC SCIENCE 2"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.ForeColor = System.Drawing.Color.Orange
        Me.Label15.Location = New System.Drawing.Point(14, 473)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(60, 18)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "HPR 101"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.Orange
        Me.Label7.Location = New System.Drawing.Point(14, 153)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(62, 18)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "ENG 101"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.Color.Orange
        Me.Label10.Location = New System.Drawing.Point(14, 273)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(107, 18)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "SOC SCIENCE 1"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.Orange
        Me.Label6.Location = New System.Drawing.Point(14, 113)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(59, 18)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "SOS 151"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.Orange
        Me.Label5.Location = New System.Drawing.Point(14, 73)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 18)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "FYE 101"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Orange
        Me.Label19.Location = New System.Drawing.Point(939, 26)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(112, 26)
        Me.Label19.TabIndex = 0
        Me.Label19.Text = "Completed"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Orange
        Me.Label4.Location = New System.Drawing.Point(836, 26)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 26)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "TQP"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Orange
        Me.Label3.Location = New System.Drawing.Point(703, 26)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 26)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "QP"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.ForeColor = System.Drawing.Color.Orange
        Me.Label40.Location = New System.Drawing.Point(12, 26)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(98, 26)
        Me.Label40.TabIndex = 0
        Me.Label40.Text = "CourseID"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Orange
        Me.Label18.Location = New System.Drawing.Point(148, 26)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(122, 26)
        Me.Label18.TabIndex = 0
        Me.Label18.Text = "Course Title"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Orange
        Me.Label2.Location = New System.Drawing.Point(571, 26)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 26)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "LG"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Orange
        Me.Label1.Location = New System.Drawing.Point(455, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 26)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Credits"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.DarkBlue
        Me.Panel3.Controls.Add(Me.ButtonResetUni)
        Me.Panel3.Controls.Add(Me.LabelGPA)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.Location = New System.Drawing.Point(3, 669)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1057, 62)
        Me.Panel3.TabIndex = 0
        '
        'ButtonResetUni
        '
        Me.ButtonResetUni.BackColor = System.Drawing.Color.DarkBlue
        Me.ButtonResetUni.FlatAppearance.BorderSize = 0
        Me.ButtonResetUni.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonResetUni.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonResetUni.ForeColor = System.Drawing.Color.Orange
        Me.ButtonResetUni.Location = New System.Drawing.Point(938, 16)
        Me.ButtonResetUni.Name = "ButtonResetUni"
        Me.ButtonResetUni.Size = New System.Drawing.Size(116, 38)
        Me.ButtonResetUni.TabIndex = 1
        Me.ButtonResetUni.Text = "RESET"
        Me.ButtonResetUni.UseVisualStyleBackColor = False
        '
        'LabelGPA
        '
        Me.LabelGPA.AutoSize = True
        Me.LabelGPA.Font = New System.Drawing.Font("Palatino Linotype", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelGPA.ForeColor = System.Drawing.Color.Orange
        Me.LabelGPA.Location = New System.Drawing.Point(12, 17)
        Me.LabelGPA.Name = "LabelGPA"
        Me.LabelGPA.Size = New System.Drawing.Size(141, 28)
        Me.LabelGPA.TabIndex = 0
        Me.LabelGPA.Text = "GPA = [ 0.00 ]"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.White
        Me.TabPage2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage2.Controls.Add(Me.Panel6)
        Me.TabPage2.Controls.Add(Me.Panel5)
        Me.TabPage2.Location = New System.Drawing.Point(4, 34)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1067, 738)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Major Core Courses"
        Me.TabPage2.ToolTipText = "Core department courses"
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.CheckBox14)
        Me.Panel6.Controls.Add(Me.CheckBox15)
        Me.Panel6.Controls.Add(Me.CheckBox16)
        Me.Panel6.Controls.Add(Me.CheckBox17)
        Me.Panel6.Controls.Add(Me.CheckBox18)
        Me.Panel6.Controls.Add(Me.CheckBox20)
        Me.Panel6.Controls.Add(Me.CheckBox21)
        Me.Panel6.Controls.Add(Me.CheckBox22)
        Me.Panel6.Controls.Add(Me.CheckBox23)
        Me.Panel6.Controls.Add(Me.CheckBox24)
        Me.Panel6.Controls.Add(Me.CheckBox25)
        Me.Panel6.Controls.Add(Me.CheckBox19)
        Me.Panel6.Controls.Add(Me.ComboBoxLG25)
        Me.Panel6.Controls.Add(Me.ComboBoxLG24)
        Me.Panel6.Controls.Add(Me.ComboBoxLG23)
        Me.Panel6.Controls.Add(Me.ComboBoxLG22)
        Me.Panel6.Controls.Add(Me.ComboBoxLG21)
        Me.Panel6.Controls.Add(Me.ComboBoxLG20)
        Me.Panel6.Controls.Add(Me.ComboBoxLG19)
        Me.Panel6.Controls.Add(Me.ComboBoxLG18)
        Me.Panel6.Controls.Add(Me.ComboBoxLG17)
        Me.Panel6.Controls.Add(Me.ComboBoxLG16)
        Me.Panel6.Controls.Add(Me.ComboBoxLG15)
        Me.Panel6.Controls.Add(Me.ComboBoxLG14)
        Me.Panel6.Controls.Add(Me.TextBoxQP25)
        Me.Panel6.Controls.Add(Me.TextBoxTQP25)
        Me.Panel6.Controls.Add(Me.TextBoxCoureTitle25)
        Me.Panel6.Controls.Add(Me.TextBoxCredit25)
        Me.Panel6.Controls.Add(Me.TextBoxQP24)
        Me.Panel6.Controls.Add(Me.TextBoxTQP24)
        Me.Panel6.Controls.Add(Me.TextBoxCoureTitle24)
        Me.Panel6.Controls.Add(Me.TextBoxCredit24)
        Me.Panel6.Controls.Add(Me.TextBoxQP23)
        Me.Panel6.Controls.Add(Me.TextBoxTQP23)
        Me.Panel6.Controls.Add(Me.TextBoxCoureTitle23)
        Me.Panel6.Controls.Add(Me.TextBoxCredit23)
        Me.Panel6.Controls.Add(Me.TextBoxQP22)
        Me.Panel6.Controls.Add(Me.TextBoxTQP22)
        Me.Panel6.Controls.Add(Me.TextBoxCoureTitle22)
        Me.Panel6.Controls.Add(Me.TextBoxCredit22)
        Me.Panel6.Controls.Add(Me.TextBoxQP21)
        Me.Panel6.Controls.Add(Me.TextBoxTQP21)
        Me.Panel6.Controls.Add(Me.TextBoxQP20)
        Me.Panel6.Controls.Add(Me.TextBoxCoureTitle21)
        Me.Panel6.Controls.Add(Me.TextBoxCredit21)
        Me.Panel6.Controls.Add(Me.TextBoxTQP20)
        Me.Panel6.Controls.Add(Me.TextBoxCoureTitle20)
        Me.Panel6.Controls.Add(Me.TextBoxQP19)
        Me.Panel6.Controls.Add(Me.TextBoxCredit20)
        Me.Panel6.Controls.Add(Me.TextBoxQP18)
        Me.Panel6.Controls.Add(Me.TextBoxTQP19)
        Me.Panel6.Controls.Add(Me.TextBoxTQP18)
        Me.Panel6.Controls.Add(Me.TextBoxCoureTitle19)
        Me.Panel6.Controls.Add(Me.TextBoxQP17)
        Me.Panel6.Controls.Add(Me.TextBoxCredit19)
        Me.Panel6.Controls.Add(Me.TextBoxTQP17)
        Me.Panel6.Controls.Add(Me.TextBoxCoureTitle18)
        Me.Panel6.Controls.Add(Me.TextBoxQP16)
        Me.Panel6.Controls.Add(Me.TextBoxCredit18)
        Me.Panel6.Controls.Add(Me.TextBoxTQP16)
        Me.Panel6.Controls.Add(Me.TextBoxCoureTitle17)
        Me.Panel6.Controls.Add(Me.TextBoxQP15)
        Me.Panel6.Controls.Add(Me.TextBoxCredit17)
        Me.Panel6.Controls.Add(Me.TextBoxTQP15)
        Me.Panel6.Controls.Add(Me.TextBoxCoureTitle16)
        Me.Panel6.Controls.Add(Me.TextBoxQP14)
        Me.Panel6.Controls.Add(Me.TextBoxCredit16)
        Me.Panel6.Controls.Add(Me.TextBoxCoureTitle15)
        Me.Panel6.Controls.Add(Me.TextBoxTQP14)
        Me.Panel6.Controls.Add(Me.TextBoxCoureTitle14)
        Me.Panel6.Controls.Add(Me.TextBoxCredit15)
        Me.Panel6.Controls.Add(Me.TextBoxCredit14)
        Me.Panel6.Controls.Add(Me.Label20)
        Me.Panel6.Controls.Add(Me.Label21)
        Me.Panel6.Controls.Add(Me.Label23)
        Me.Panel6.Controls.Add(Me.Label24)
        Me.Panel6.Controls.Add(Me.Label25)
        Me.Panel6.Controls.Add(Me.Label26)
        Me.Panel6.Controls.Add(Me.Label27)
        Me.Panel6.Controls.Add(Me.Label28)
        Me.Panel6.Controls.Add(Me.Label29)
        Me.Panel6.Controls.Add(Me.Label30)
        Me.Panel6.Controls.Add(Me.Label31)
        Me.Panel6.Controls.Add(Me.Label32)
        Me.Panel6.Controls.Add(Me.Label33)
        Me.Panel6.Controls.Add(Me.Label34)
        Me.Panel6.Controls.Add(Me.Label35)
        Me.Panel6.Controls.Add(Me.Label43)
        Me.Panel6.Controls.Add(Me.Label41)
        Me.Panel6.Controls.Add(Me.Label36)
        Me.Panel6.Controls.Add(Me.Label37)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel6.Location = New System.Drawing.Point(3, 3)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(1057, 650)
        Me.Panel6.TabIndex = 2
        '
        'CheckBox14
        '
        Me.CheckBox14.AutoSize = True
        Me.CheckBox14.Enabled = False
        Me.CheckBox14.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox14.Location = New System.Drawing.Point(937, 69)
        Me.CheckBox14.Name = "CheckBox14"
        Me.CheckBox14.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox14.TabIndex = 4
        Me.CheckBox14.Text = "False"
        Me.CheckBox14.UseVisualStyleBackColor = True
        '
        'CheckBox15
        '
        Me.CheckBox15.AutoSize = True
        Me.CheckBox15.Enabled = False
        Me.CheckBox15.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox15.Location = New System.Drawing.Point(937, 105)
        Me.CheckBox15.Name = "CheckBox15"
        Me.CheckBox15.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox15.TabIndex = 4
        Me.CheckBox15.Text = "False"
        Me.CheckBox15.UseVisualStyleBackColor = True
        '
        'CheckBox16
        '
        Me.CheckBox16.AutoSize = True
        Me.CheckBox16.Enabled = False
        Me.CheckBox16.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox16.Location = New System.Drawing.Point(937, 146)
        Me.CheckBox16.Name = "CheckBox16"
        Me.CheckBox16.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox16.TabIndex = 4
        Me.CheckBox16.Text = "False"
        Me.CheckBox16.UseVisualStyleBackColor = True
        '
        'CheckBox17
        '
        Me.CheckBox17.AutoSize = True
        Me.CheckBox17.Enabled = False
        Me.CheckBox17.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox17.Location = New System.Drawing.Point(937, 185)
        Me.CheckBox17.Name = "CheckBox17"
        Me.CheckBox17.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox17.TabIndex = 4
        Me.CheckBox17.Text = "False"
        Me.CheckBox17.UseVisualStyleBackColor = True
        '
        'CheckBox18
        '
        Me.CheckBox18.AutoSize = True
        Me.CheckBox18.Enabled = False
        Me.CheckBox18.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox18.Location = New System.Drawing.Point(937, 225)
        Me.CheckBox18.Name = "CheckBox18"
        Me.CheckBox18.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox18.TabIndex = 4
        Me.CheckBox18.Text = "False"
        Me.CheckBox18.UseVisualStyleBackColor = True
        '
        'CheckBox20
        '
        Me.CheckBox20.AutoSize = True
        Me.CheckBox20.Enabled = False
        Me.CheckBox20.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox20.Location = New System.Drawing.Point(937, 305)
        Me.CheckBox20.Name = "CheckBox20"
        Me.CheckBox20.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox20.TabIndex = 4
        Me.CheckBox20.Text = "False"
        Me.CheckBox20.UseVisualStyleBackColor = True
        '
        'CheckBox21
        '
        Me.CheckBox21.AutoSize = True
        Me.CheckBox21.Enabled = False
        Me.CheckBox21.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox21.Location = New System.Drawing.Point(937, 345)
        Me.CheckBox21.Name = "CheckBox21"
        Me.CheckBox21.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox21.TabIndex = 4
        Me.CheckBox21.Text = "False"
        Me.CheckBox21.UseVisualStyleBackColor = True
        '
        'CheckBox22
        '
        Me.CheckBox22.AutoSize = True
        Me.CheckBox22.Enabled = False
        Me.CheckBox22.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox22.Location = New System.Drawing.Point(937, 385)
        Me.CheckBox22.Name = "CheckBox22"
        Me.CheckBox22.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox22.TabIndex = 4
        Me.CheckBox22.Text = "False"
        Me.CheckBox22.UseVisualStyleBackColor = True
        '
        'CheckBox23
        '
        Me.CheckBox23.AutoSize = True
        Me.CheckBox23.Enabled = False
        Me.CheckBox23.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox23.Location = New System.Drawing.Point(937, 425)
        Me.CheckBox23.Name = "CheckBox23"
        Me.CheckBox23.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox23.TabIndex = 4
        Me.CheckBox23.Text = "False"
        Me.CheckBox23.UseVisualStyleBackColor = True
        '
        'CheckBox24
        '
        Me.CheckBox24.AutoSize = True
        Me.CheckBox24.Enabled = False
        Me.CheckBox24.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox24.Location = New System.Drawing.Point(937, 465)
        Me.CheckBox24.Name = "CheckBox24"
        Me.CheckBox24.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox24.TabIndex = 4
        Me.CheckBox24.Text = "False"
        Me.CheckBox24.UseVisualStyleBackColor = True
        '
        'CheckBox25
        '
        Me.CheckBox25.AutoSize = True
        Me.CheckBox25.Enabled = False
        Me.CheckBox25.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox25.Location = New System.Drawing.Point(937, 504)
        Me.CheckBox25.Name = "CheckBox25"
        Me.CheckBox25.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox25.TabIndex = 4
        Me.CheckBox25.Text = "False"
        Me.CheckBox25.UseVisualStyleBackColor = True
        '
        'CheckBox19
        '
        Me.CheckBox19.AutoSize = True
        Me.CheckBox19.Enabled = False
        Me.CheckBox19.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox19.Location = New System.Drawing.Point(937, 266)
        Me.CheckBox19.Name = "CheckBox19"
        Me.CheckBox19.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox19.TabIndex = 4
        Me.CheckBox19.Text = "False"
        Me.CheckBox19.UseVisualStyleBackColor = True
        '
        'ComboBoxLG25
        '
        Me.ComboBoxLG25.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG25.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG25.FormattingEnabled = True
        Me.ComboBoxLG25.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG25.Location = New System.Drawing.Point(543, 504)
        Me.ComboBoxLG25.Name = "ComboBoxLG25"
        Me.ComboBoxLG25.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG25.TabIndex = 3
        '
        'ComboBoxLG24
        '
        Me.ComboBoxLG24.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG24.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG24.FormattingEnabled = True
        Me.ComboBoxLG24.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG24.Location = New System.Drawing.Point(543, 465)
        Me.ComboBoxLG24.Name = "ComboBoxLG24"
        Me.ComboBoxLG24.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG24.TabIndex = 3
        '
        'ComboBoxLG23
        '
        Me.ComboBoxLG23.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG23.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG23.FormattingEnabled = True
        Me.ComboBoxLG23.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG23.Location = New System.Drawing.Point(543, 425)
        Me.ComboBoxLG23.Name = "ComboBoxLG23"
        Me.ComboBoxLG23.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG23.TabIndex = 3
        '
        'ComboBoxLG22
        '
        Me.ComboBoxLG22.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG22.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG22.FormattingEnabled = True
        Me.ComboBoxLG22.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG22.Location = New System.Drawing.Point(543, 385)
        Me.ComboBoxLG22.Name = "ComboBoxLG22"
        Me.ComboBoxLG22.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG22.TabIndex = 3
        '
        'ComboBoxLG21
        '
        Me.ComboBoxLG21.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG21.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG21.FormattingEnabled = True
        Me.ComboBoxLG21.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG21.Location = New System.Drawing.Point(543, 345)
        Me.ComboBoxLG21.Name = "ComboBoxLG21"
        Me.ComboBoxLG21.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG21.TabIndex = 3
        '
        'ComboBoxLG20
        '
        Me.ComboBoxLG20.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG20.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG20.FormattingEnabled = True
        Me.ComboBoxLG20.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG20.Location = New System.Drawing.Point(543, 305)
        Me.ComboBoxLG20.Name = "ComboBoxLG20"
        Me.ComboBoxLG20.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG20.TabIndex = 3
        '
        'ComboBoxLG19
        '
        Me.ComboBoxLG19.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG19.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG19.FormattingEnabled = True
        Me.ComboBoxLG19.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG19.Location = New System.Drawing.Point(543, 265)
        Me.ComboBoxLG19.Name = "ComboBoxLG19"
        Me.ComboBoxLG19.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG19.TabIndex = 3
        '
        'ComboBoxLG18
        '
        Me.ComboBoxLG18.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG18.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG18.FormattingEnabled = True
        Me.ComboBoxLG18.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG18.Location = New System.Drawing.Point(543, 225)
        Me.ComboBoxLG18.Name = "ComboBoxLG18"
        Me.ComboBoxLG18.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG18.TabIndex = 3
        '
        'ComboBoxLG17
        '
        Me.ComboBoxLG17.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG17.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG17.FormattingEnabled = True
        Me.ComboBoxLG17.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG17.Location = New System.Drawing.Point(543, 185)
        Me.ComboBoxLG17.Name = "ComboBoxLG17"
        Me.ComboBoxLG17.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG17.TabIndex = 3
        '
        'ComboBoxLG16
        '
        Me.ComboBoxLG16.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG16.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG16.FormattingEnabled = True
        Me.ComboBoxLG16.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG16.Location = New System.Drawing.Point(543, 146)
        Me.ComboBoxLG16.Name = "ComboBoxLG16"
        Me.ComboBoxLG16.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG16.TabIndex = 3
        '
        'ComboBoxLG15
        '
        Me.ComboBoxLG15.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG15.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG15.FormattingEnabled = True
        Me.ComboBoxLG15.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG15.Location = New System.Drawing.Point(543, 105)
        Me.ComboBoxLG15.Name = "ComboBoxLG15"
        Me.ComboBoxLG15.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG15.TabIndex = 3
        '
        'ComboBoxLG14
        '
        Me.ComboBoxLG14.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG14.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG14.FormattingEnabled = True
        Me.ComboBoxLG14.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG14.Location = New System.Drawing.Point(543, 69)
        Me.ComboBoxLG14.Name = "ComboBoxLG14"
        Me.ComboBoxLG14.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG14.TabIndex = 3
        '
        'TextBoxQP25
        '
        Me.TextBoxQP25.Enabled = False
        Me.TextBoxQP25.Location = New System.Drawing.Point(665, 506)
        Me.TextBoxQP25.Name = "TextBoxQP25"
        Me.TextBoxQP25.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP25.TabIndex = 2
        '
        'TextBoxTQP25
        '
        Me.TextBoxTQP25.Enabled = False
        Me.TextBoxTQP25.Location = New System.Drawing.Point(797, 506)
        Me.TextBoxTQP25.Name = "TextBoxTQP25"
        Me.TextBoxTQP25.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP25.TabIndex = 2
        '
        'TextBoxCoureTitle25
        '
        Me.TextBoxCoureTitle25.Enabled = False
        Me.TextBoxCoureTitle25.Location = New System.Drawing.Point(177, 505)
        Me.TextBoxCoureTitle25.Name = "TextBoxCoureTitle25"
        Me.TextBoxCoureTitle25.Size = New System.Drawing.Size(221, 29)
        Me.TextBoxCoureTitle25.TabIndex = 2
        Me.TextBoxCoureTitle25.Text = "Topics in Computer Science"
        '
        'TextBoxCredit25
        '
        Me.TextBoxCredit25.Location = New System.Drawing.Point(417, 506)
        Me.TextBoxCredit25.Name = "TextBoxCredit25"
        Me.TextBoxCredit25.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit25.TabIndex = 2
        '
        'TextBoxQP24
        '
        Me.TextBoxQP24.Enabled = False
        Me.TextBoxQP24.Location = New System.Drawing.Point(665, 465)
        Me.TextBoxQP24.Name = "TextBoxQP24"
        Me.TextBoxQP24.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP24.TabIndex = 2
        '
        'TextBoxTQP24
        '
        Me.TextBoxTQP24.Enabled = False
        Me.TextBoxTQP24.Location = New System.Drawing.Point(797, 465)
        Me.TextBoxTQP24.Name = "TextBoxTQP24"
        Me.TextBoxTQP24.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP24.TabIndex = 2
        '
        'TextBoxCoureTitle24
        '
        Me.TextBoxCoureTitle24.Location = New System.Drawing.Point(177, 464)
        Me.TextBoxCoureTitle24.Name = "TextBoxCoureTitle24"
        Me.TextBoxCoureTitle24.Size = New System.Drawing.Size(221, 29)
        Me.TextBoxCoureTitle24.TabIndex = 2
        Me.TextBoxCoureTitle24.Text = "300/400 Level Elective"
        '
        'TextBoxCredit24
        '
        Me.TextBoxCredit24.Location = New System.Drawing.Point(417, 465)
        Me.TextBoxCredit24.Name = "TextBoxCredit24"
        Me.TextBoxCredit24.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit24.TabIndex = 2
        '
        'TextBoxQP23
        '
        Me.TextBoxQP23.Enabled = False
        Me.TextBoxQP23.Location = New System.Drawing.Point(665, 426)
        Me.TextBoxQP23.Name = "TextBoxQP23"
        Me.TextBoxQP23.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP23.TabIndex = 2
        '
        'TextBoxTQP23
        '
        Me.TextBoxTQP23.Enabled = False
        Me.TextBoxTQP23.Location = New System.Drawing.Point(797, 426)
        Me.TextBoxTQP23.Name = "TextBoxTQP23"
        Me.TextBoxTQP23.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP23.TabIndex = 2
        '
        'TextBoxCoureTitle23
        '
        Me.TextBoxCoureTitle23.Location = New System.Drawing.Point(177, 425)
        Me.TextBoxCoureTitle23.Name = "TextBoxCoureTitle23"
        Me.TextBoxCoureTitle23.Size = New System.Drawing.Size(221, 29)
        Me.TextBoxCoureTitle23.TabIndex = 2
        Me.TextBoxCoureTitle23.Text = "300/400 Level Elective"
        '
        'TextBoxCredit23
        '
        Me.TextBoxCredit23.Location = New System.Drawing.Point(417, 426)
        Me.TextBoxCredit23.Name = "TextBoxCredit23"
        Me.TextBoxCredit23.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit23.TabIndex = 2
        '
        'TextBoxQP22
        '
        Me.TextBoxQP22.Enabled = False
        Me.TextBoxQP22.Location = New System.Drawing.Point(665, 386)
        Me.TextBoxQP22.Name = "TextBoxQP22"
        Me.TextBoxQP22.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP22.TabIndex = 2
        '
        'TextBoxTQP22
        '
        Me.TextBoxTQP22.Enabled = False
        Me.TextBoxTQP22.Location = New System.Drawing.Point(797, 386)
        Me.TextBoxTQP22.Name = "TextBoxTQP22"
        Me.TextBoxTQP22.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP22.TabIndex = 2
        '
        'TextBoxCoureTitle22
        '
        Me.TextBoxCoureTitle22.Location = New System.Drawing.Point(177, 385)
        Me.TextBoxCoureTitle22.Name = "TextBoxCoureTitle22"
        Me.TextBoxCoureTitle22.Size = New System.Drawing.Size(221, 29)
        Me.TextBoxCoureTitle22.TabIndex = 2
        Me.TextBoxCoureTitle22.Text = "200 Level Elective"
        '
        'TextBoxCredit22
        '
        Me.TextBoxCredit22.Location = New System.Drawing.Point(417, 386)
        Me.TextBoxCredit22.Name = "TextBoxCredit22"
        Me.TextBoxCredit22.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit22.TabIndex = 2
        '
        'TextBoxQP21
        '
        Me.TextBoxQP21.Enabled = False
        Me.TextBoxQP21.Location = New System.Drawing.Point(665, 346)
        Me.TextBoxQP21.Name = "TextBoxQP21"
        Me.TextBoxQP21.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP21.TabIndex = 2
        '
        'TextBoxTQP21
        '
        Me.TextBoxTQP21.Enabled = False
        Me.TextBoxTQP21.Location = New System.Drawing.Point(797, 346)
        Me.TextBoxTQP21.Name = "TextBoxTQP21"
        Me.TextBoxTQP21.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP21.TabIndex = 2
        '
        'TextBoxQP20
        '
        Me.TextBoxQP20.Enabled = False
        Me.TextBoxQP20.Location = New System.Drawing.Point(665, 306)
        Me.TextBoxQP20.Name = "TextBoxQP20"
        Me.TextBoxQP20.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP20.TabIndex = 2
        '
        'TextBoxCoureTitle21
        '
        Me.TextBoxCoureTitle21.Enabled = False
        Me.TextBoxCoureTitle21.Location = New System.Drawing.Point(177, 345)
        Me.TextBoxCoureTitle21.Name = "TextBoxCoureTitle21"
        Me.TextBoxCoureTitle21.Size = New System.Drawing.Size(221, 29)
        Me.TextBoxCoureTitle21.TabIndex = 2
        Me.TextBoxCoureTitle21.Text = "Software Engineering"
        '
        'TextBoxCredit21
        '
        Me.TextBoxCredit21.Location = New System.Drawing.Point(417, 346)
        Me.TextBoxCredit21.Name = "TextBoxCredit21"
        Me.TextBoxCredit21.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit21.TabIndex = 2
        '
        'TextBoxTQP20
        '
        Me.TextBoxTQP20.Enabled = False
        Me.TextBoxTQP20.Location = New System.Drawing.Point(797, 306)
        Me.TextBoxTQP20.Name = "TextBoxTQP20"
        Me.TextBoxTQP20.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP20.TabIndex = 2
        '
        'TextBoxCoureTitle20
        '
        Me.TextBoxCoureTitle20.Enabled = False
        Me.TextBoxCoureTitle20.Location = New System.Drawing.Point(177, 305)
        Me.TextBoxCoureTitle20.Name = "TextBoxCoureTitle20"
        Me.TextBoxCoureTitle20.Size = New System.Drawing.Size(221, 29)
        Me.TextBoxCoureTitle20.TabIndex = 2
        Me.TextBoxCoureTitle20.Text = "Compiler Construction"
        '
        'TextBoxQP19
        '
        Me.TextBoxQP19.Enabled = False
        Me.TextBoxQP19.Location = New System.Drawing.Point(665, 266)
        Me.TextBoxQP19.Name = "TextBoxQP19"
        Me.TextBoxQP19.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP19.TabIndex = 2
        '
        'TextBoxCredit20
        '
        Me.TextBoxCredit20.Location = New System.Drawing.Point(417, 306)
        Me.TextBoxCredit20.Name = "TextBoxCredit20"
        Me.TextBoxCredit20.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit20.TabIndex = 2
        '
        'TextBoxQP18
        '
        Me.TextBoxQP18.Enabled = False
        Me.TextBoxQP18.Location = New System.Drawing.Point(665, 226)
        Me.TextBoxQP18.Name = "TextBoxQP18"
        Me.TextBoxQP18.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP18.TabIndex = 2
        '
        'TextBoxTQP19
        '
        Me.TextBoxTQP19.Enabled = False
        Me.TextBoxTQP19.Location = New System.Drawing.Point(797, 266)
        Me.TextBoxTQP19.Name = "TextBoxTQP19"
        Me.TextBoxTQP19.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP19.TabIndex = 2
        '
        'TextBoxTQP18
        '
        Me.TextBoxTQP18.Enabled = False
        Me.TextBoxTQP18.Location = New System.Drawing.Point(797, 226)
        Me.TextBoxTQP18.Name = "TextBoxTQP18"
        Me.TextBoxTQP18.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP18.TabIndex = 2
        '
        'TextBoxCoureTitle19
        '
        Me.TextBoxCoureTitle19.Enabled = False
        Me.TextBoxCoureTitle19.Location = New System.Drawing.Point(177, 265)
        Me.TextBoxCoureTitle19.Name = "TextBoxCoureTitle19"
        Me.TextBoxCoureTitle19.Size = New System.Drawing.Size(221, 29)
        Me.TextBoxCoureTitle19.TabIndex = 2
        Me.TextBoxCoureTitle19.Text = "Visual Programming"
        '
        'TextBoxQP17
        '
        Me.TextBoxQP17.Enabled = False
        Me.TextBoxQP17.Location = New System.Drawing.Point(665, 186)
        Me.TextBoxQP17.Name = "TextBoxQP17"
        Me.TextBoxQP17.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP17.TabIndex = 2
        '
        'TextBoxCredit19
        '
        Me.TextBoxCredit19.Location = New System.Drawing.Point(417, 266)
        Me.TextBoxCredit19.Name = "TextBoxCredit19"
        Me.TextBoxCredit19.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit19.TabIndex = 2
        '
        'TextBoxTQP17
        '
        Me.TextBoxTQP17.Enabled = False
        Me.TextBoxTQP17.Location = New System.Drawing.Point(797, 186)
        Me.TextBoxTQP17.Name = "TextBoxTQP17"
        Me.TextBoxTQP17.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP17.TabIndex = 2
        '
        'TextBoxCoureTitle18
        '
        Me.TextBoxCoureTitle18.Enabled = False
        Me.TextBoxCoureTitle18.Location = New System.Drawing.Point(177, 225)
        Me.TextBoxCoureTitle18.Name = "TextBoxCoureTitle18"
        Me.TextBoxCoureTitle18.Size = New System.Drawing.Size(221, 29)
        Me.TextBoxCoureTitle18.TabIndex = 2
        Me.TextBoxCoureTitle18.Text = "Database Management"
        '
        'TextBoxQP16
        '
        Me.TextBoxQP16.Enabled = False
        Me.TextBoxQP16.Location = New System.Drawing.Point(665, 146)
        Me.TextBoxQP16.Name = "TextBoxQP16"
        Me.TextBoxQP16.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP16.TabIndex = 2
        '
        'TextBoxCredit18
        '
        Me.TextBoxCredit18.Location = New System.Drawing.Point(417, 226)
        Me.TextBoxCredit18.Name = "TextBoxCredit18"
        Me.TextBoxCredit18.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit18.TabIndex = 2
        '
        'TextBoxTQP16
        '
        Me.TextBoxTQP16.Enabled = False
        Me.TextBoxTQP16.Location = New System.Drawing.Point(797, 146)
        Me.TextBoxTQP16.Name = "TextBoxTQP16"
        Me.TextBoxTQP16.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP16.TabIndex = 2
        '
        'TextBoxCoureTitle17
        '
        Me.TextBoxCoureTitle17.Enabled = False
        Me.TextBoxCoureTitle17.Location = New System.Drawing.Point(177, 185)
        Me.TextBoxCoureTitle17.Name = "TextBoxCoureTitle17"
        Me.TextBoxCoureTitle17.Size = New System.Drawing.Size(221, 29)
        Me.TextBoxCoureTitle17.TabIndex = 2
        Me.TextBoxCoureTitle17.Text = "Computer Org & Assm"
        '
        'TextBoxQP15
        '
        Me.TextBoxQP15.Enabled = False
        Me.TextBoxQP15.Location = New System.Drawing.Point(665, 107)
        Me.TextBoxQP15.Name = "TextBoxQP15"
        Me.TextBoxQP15.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP15.TabIndex = 2
        '
        'TextBoxCredit17
        '
        Me.TextBoxCredit17.Location = New System.Drawing.Point(417, 186)
        Me.TextBoxCredit17.Name = "TextBoxCredit17"
        Me.TextBoxCredit17.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit17.TabIndex = 2
        '
        'TextBoxTQP15
        '
        Me.TextBoxTQP15.Enabled = False
        Me.TextBoxTQP15.Location = New System.Drawing.Point(797, 107)
        Me.TextBoxTQP15.Name = "TextBoxTQP15"
        Me.TextBoxTQP15.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP15.TabIndex = 2
        '
        'TextBoxCoureTitle16
        '
        Me.TextBoxCoureTitle16.Enabled = False
        Me.TextBoxCoureTitle16.Location = New System.Drawing.Point(177, 145)
        Me.TextBoxCoureTitle16.Name = "TextBoxCoureTitle16"
        Me.TextBoxCoureTitle16.Size = New System.Drawing.Size(221, 29)
        Me.TextBoxCoureTitle16.TabIndex = 2
        Me.TextBoxCoureTitle16.Text = "Data Structures"
        '
        'TextBoxQP14
        '
        Me.TextBoxQP14.Enabled = False
        Me.TextBoxQP14.Location = New System.Drawing.Point(665, 70)
        Me.TextBoxQP14.Name = "TextBoxQP14"
        Me.TextBoxQP14.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP14.TabIndex = 2
        '
        'TextBoxCredit16
        '
        Me.TextBoxCredit16.Location = New System.Drawing.Point(417, 146)
        Me.TextBoxCredit16.Name = "TextBoxCredit16"
        Me.TextBoxCredit16.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit16.TabIndex = 2
        '
        'TextBoxCoureTitle15
        '
        Me.TextBoxCoureTitle15.Enabled = False
        Me.TextBoxCoureTitle15.Location = New System.Drawing.Point(177, 106)
        Me.TextBoxCoureTitle15.Name = "TextBoxCoureTitle15"
        Me.TextBoxCoureTitle15.Size = New System.Drawing.Size(221, 29)
        Me.TextBoxCoureTitle15.TabIndex = 2
        Me.TextBoxCoureTitle15.Text = "Computer Programming II"
        '
        'TextBoxTQP14
        '
        Me.TextBoxTQP14.Enabled = False
        Me.TextBoxTQP14.Location = New System.Drawing.Point(797, 70)
        Me.TextBoxTQP14.Name = "TextBoxTQP14"
        Me.TextBoxTQP14.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP14.TabIndex = 2
        '
        'TextBoxCoureTitle14
        '
        Me.TextBoxCoureTitle14.Enabled = False
        Me.TextBoxCoureTitle14.Location = New System.Drawing.Point(177, 69)
        Me.TextBoxCoureTitle14.Name = "TextBoxCoureTitle14"
        Me.TextBoxCoureTitle14.Size = New System.Drawing.Size(221, 29)
        Me.TextBoxCoureTitle14.TabIndex = 2
        Me.TextBoxCoureTitle14.Text = "Computer Programming I"
        '
        'TextBoxCredit15
        '
        Me.TextBoxCredit15.Location = New System.Drawing.Point(417, 107)
        Me.TextBoxCredit15.Name = "TextBoxCredit15"
        Me.TextBoxCredit15.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit15.TabIndex = 2
        '
        'TextBoxCredit14
        '
        Me.TextBoxCredit14.Location = New System.Drawing.Point(417, 70)
        Me.TextBoxCredit14.Name = "TextBoxCredit14"
        Me.TextBoxCredit14.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit14.TabIndex = 2
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label20.Location = New System.Drawing.Point(14, 433)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(82, 22)
        Me.Label20.TabIndex = 1
        Me.Label20.Text = "CSC-XXX"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label21.Location = New System.Drawing.Point(14, 233)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(73, 22)
        Me.Label21.TabIndex = 1
        Me.Label21.Text = "CSC-354"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label23.Location = New System.Drawing.Point(14, 393)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(79, 22)
        Me.Label23.TabIndex = 1
        Me.Label23.Text = "CSC-2XX"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label24.Location = New System.Drawing.Point(14, 354)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(68, 22)
        Me.Label24.TabIndex = 1
        Me.Label24.Text = "CSC454"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label25.Location = New System.Drawing.Point(14, 513)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(160, 22)
        Me.Label25.TabIndex = 1
        Me.Label25.Text = "CSC-498 or CSC-499"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label26.Location = New System.Drawing.Point(14, 192)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(73, 22)
        Me.Label26.TabIndex = 1
        Me.Label26.Text = "CSC-353"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label27.Location = New System.Drawing.Point(14, 313)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(73, 22)
        Me.Label27.TabIndex = 1
        Me.Label27.Text = "CSC-453"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label28.Location = New System.Drawing.Point(14, 473)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(82, 22)
        Me.Label28.TabIndex = 1
        Me.Label28.Text = "CSC-XXX"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label29.Location = New System.Drawing.Point(14, 153)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(73, 22)
        Me.Label29.TabIndex = 1
        Me.Label29.Text = "CSC-254"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label30.Location = New System.Drawing.Point(14, 273)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(73, 22)
        Me.Label30.TabIndex = 1
        Me.Label30.Text = "CSC-356"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label31.Location = New System.Drawing.Point(14, 113)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(73, 22)
        Me.Label31.TabIndex = 1
        Me.Label31.Text = "CSC-159"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label32.Location = New System.Drawing.Point(14, 73)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(73, 22)
        Me.Label32.TabIndex = 1
        Me.Label32.Text = "CSC-158"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label33.Location = New System.Drawing.Point(907, 26)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(112, 26)
        Me.Label33.TabIndex = 0
        Me.Label33.Text = "Completed"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label34.Location = New System.Drawing.Point(804, 26)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(53, 26)
        Me.Label34.TabIndex = 0
        Me.Label34.Text = "TQP"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label35.Location = New System.Drawing.Point(671, 26)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(40, 26)
        Me.Label35.TabIndex = 0
        Me.Label35.Text = "QP"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label43.Location = New System.Drawing.Point(172, 26)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(122, 26)
        Me.Label43.TabIndex = 0
        Me.Label43.Text = "Course Title"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label41.Location = New System.Drawing.Point(19, 26)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(98, 26)
        Me.Label41.TabIndex = 0
        Me.Label41.Text = "CourseID"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label36.Location = New System.Drawing.Point(539, 26)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(40, 26)
        Me.Label36.TabIndex = 0
        Me.Label36.Text = "LG"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label37.Location = New System.Drawing.Point(421, 26)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(77, 26)
        Me.Label37.TabIndex = 0
        Me.Label37.Text = "Credits"
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Orange
        Me.Panel5.Controls.Add(Me.ButtonResetMajor)
        Me.Panel5.Controls.Add(Me.LabelGPAMajor)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel5.Location = New System.Drawing.Point(3, 653)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(1057, 78)
        Me.Panel5.TabIndex = 1
        '
        'ButtonResetMajor
        '
        Me.ButtonResetMajor.BackColor = System.Drawing.Color.Orange
        Me.ButtonResetMajor.FlatAppearance.BorderSize = 0
        Me.ButtonResetMajor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonResetMajor.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonResetMajor.ForeColor = System.Drawing.Color.DarkBlue
        Me.ButtonResetMajor.Location = New System.Drawing.Point(938, 22)
        Me.ButtonResetMajor.Name = "ButtonResetMajor"
        Me.ButtonResetMajor.Size = New System.Drawing.Size(116, 38)
        Me.ButtonResetMajor.TabIndex = 1
        Me.ButtonResetMajor.Text = "RESET"
        Me.ButtonResetMajor.UseVisualStyleBackColor = False
        '
        'LabelGPAMajor
        '
        Me.LabelGPAMajor.AutoSize = True
        Me.LabelGPAMajor.Font = New System.Drawing.Font("Palatino Linotype", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelGPAMajor.ForeColor = System.Drawing.Color.DarkBlue
        Me.LabelGPAMajor.Location = New System.Drawing.Point(7, 26)
        Me.LabelGPAMajor.Name = "LabelGPAMajor"
        Me.LabelGPAMajor.Size = New System.Drawing.Size(141, 28)
        Me.LabelGPAMajor.TabIndex = 0
        Me.LabelGPAMajor.Text = "GPA = [ 0.00 ]"
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.White
        Me.TabPage3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage3.Controls.Add(Me.Panel8)
        Me.TabPage3.Controls.Add(Me.Panel7)
        Me.TabPage3.Location = New System.Drawing.Point(4, 34)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(1067, 738)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Math Minor Courses"
        Me.TabPage3.ToolTipText = "Courses for a minor "
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.CheckBox26)
        Me.Panel8.Controls.Add(Me.CheckBox27)
        Me.Panel8.Controls.Add(Me.CheckBox28)
        Me.Panel8.Controls.Add(Me.CheckBox29)
        Me.Panel8.Controls.Add(Me.CheckBox30)
        Me.Panel8.Controls.Add(Me.ComboBoxLG30)
        Me.Panel8.Controls.Add(Me.ComboBoxLG29)
        Me.Panel8.Controls.Add(Me.ComboBoxLG28)
        Me.Panel8.Controls.Add(Me.ComboBoxLG27)
        Me.Panel8.Controls.Add(Me.ComboBoxLG26)
        Me.Panel8.Controls.Add(Me.TextBoxQP30)
        Me.Panel8.Controls.Add(Me.TextBoxTQP30)
        Me.Panel8.Controls.Add(Me.TextBoxQP29)
        Me.Panel8.Controls.Add(Me.TextBoxTQP29)
        Me.Panel8.Controls.Add(Me.TextBoxQP28)
        Me.Panel8.Controls.Add(Me.TextBoxCoureTitle30)
        Me.Panel8.Controls.Add(Me.TextBoxCredit30)
        Me.Panel8.Controls.Add(Me.TextBoxTQP28)
        Me.Panel8.Controls.Add(Me.TextBoxQP27)
        Me.Panel8.Controls.Add(Me.TextBoxCoureTitle29)
        Me.Panel8.Controls.Add(Me.TextBoxCredit29)
        Me.Panel8.Controls.Add(Me.TextBoxTQP27)
        Me.Panel8.Controls.Add(Me.TextBoxQP26)
        Me.Panel8.Controls.Add(Me.TextBoxCoureTitle28)
        Me.Panel8.Controls.Add(Me.TextBoxCredit28)
        Me.Panel8.Controls.Add(Me.TextBoxTQP26)
        Me.Panel8.Controls.Add(Me.TextBoxCoureTitle27)
        Me.Panel8.Controls.Add(Me.TextBoxCoureTitle26)
        Me.Panel8.Controls.Add(Me.TextBoxCredit27)
        Me.Panel8.Controls.Add(Me.TextBoxCredit26)
        Me.Panel8.Controls.Add(Me.Label38)
        Me.Panel8.Controls.Add(Me.Label42)
        Me.Panel8.Controls.Add(Me.Label45)
        Me.Panel8.Controls.Add(Me.Label47)
        Me.Panel8.Controls.Add(Me.Label48)
        Me.Panel8.Controls.Add(Me.Label49)
        Me.Panel8.Controls.Add(Me.Label50)
        Me.Panel8.Controls.Add(Me.Label51)
        Me.Panel8.Controls.Add(Me.Label46)
        Me.Panel8.Controls.Add(Me.Label44)
        Me.Panel8.Controls.Add(Me.Label52)
        Me.Panel8.Controls.Add(Me.Label53)
        Me.Panel8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel8.Location = New System.Drawing.Point(0, 0)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(1063, 672)
        Me.Panel8.TabIndex = 3
        '
        'CheckBox26
        '
        Me.CheckBox26.AutoSize = True
        Me.CheckBox26.Enabled = False
        Me.CheckBox26.ForeColor = System.Drawing.Color.Orange
        Me.CheckBox26.Location = New System.Drawing.Point(975, 69)
        Me.CheckBox26.Name = "CheckBox26"
        Me.CheckBox26.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox26.TabIndex = 4
        Me.CheckBox26.Text = "False"
        Me.CheckBox26.UseVisualStyleBackColor = True
        '
        'CheckBox27
        '
        Me.CheckBox27.AutoSize = True
        Me.CheckBox27.Enabled = False
        Me.CheckBox27.ForeColor = System.Drawing.Color.Orange
        Me.CheckBox27.Location = New System.Drawing.Point(975, 105)
        Me.CheckBox27.Name = "CheckBox27"
        Me.CheckBox27.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox27.TabIndex = 4
        Me.CheckBox27.Text = "False"
        Me.CheckBox27.UseVisualStyleBackColor = True
        '
        'CheckBox28
        '
        Me.CheckBox28.AutoSize = True
        Me.CheckBox28.Enabled = False
        Me.CheckBox28.ForeColor = System.Drawing.Color.Orange
        Me.CheckBox28.Location = New System.Drawing.Point(975, 146)
        Me.CheckBox28.Name = "CheckBox28"
        Me.CheckBox28.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox28.TabIndex = 4
        Me.CheckBox28.Text = "False"
        Me.CheckBox28.UseVisualStyleBackColor = True
        '
        'CheckBox29
        '
        Me.CheckBox29.AutoSize = True
        Me.CheckBox29.Enabled = False
        Me.CheckBox29.ForeColor = System.Drawing.Color.Orange
        Me.CheckBox29.Location = New System.Drawing.Point(975, 185)
        Me.CheckBox29.Name = "CheckBox29"
        Me.CheckBox29.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox29.TabIndex = 4
        Me.CheckBox29.Text = "False"
        Me.CheckBox29.UseVisualStyleBackColor = True
        '
        'CheckBox30
        '
        Me.CheckBox30.AutoSize = True
        Me.CheckBox30.Enabled = False
        Me.CheckBox30.ForeColor = System.Drawing.Color.Orange
        Me.CheckBox30.Location = New System.Drawing.Point(975, 225)
        Me.CheckBox30.Name = "CheckBox30"
        Me.CheckBox30.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox30.TabIndex = 4
        Me.CheckBox30.Text = "False"
        Me.CheckBox30.UseVisualStyleBackColor = True
        '
        'ComboBoxLG30
        '
        Me.ComboBoxLG30.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG30.ForeColor = System.Drawing.Color.Orange
        Me.ComboBoxLG30.FormattingEnabled = True
        Me.ComboBoxLG30.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG30.Location = New System.Drawing.Point(600, 225)
        Me.ComboBoxLG30.Name = "ComboBoxLG30"
        Me.ComboBoxLG30.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG30.TabIndex = 3
        '
        'ComboBoxLG29
        '
        Me.ComboBoxLG29.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG29.ForeColor = System.Drawing.Color.Orange
        Me.ComboBoxLG29.FormattingEnabled = True
        Me.ComboBoxLG29.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG29.Location = New System.Drawing.Point(600, 185)
        Me.ComboBoxLG29.Name = "ComboBoxLG29"
        Me.ComboBoxLG29.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG29.TabIndex = 3
        '
        'ComboBoxLG28
        '
        Me.ComboBoxLG28.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG28.ForeColor = System.Drawing.Color.Orange
        Me.ComboBoxLG28.FormattingEnabled = True
        Me.ComboBoxLG28.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG28.Location = New System.Drawing.Point(600, 146)
        Me.ComboBoxLG28.Name = "ComboBoxLG28"
        Me.ComboBoxLG28.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG28.TabIndex = 3
        '
        'ComboBoxLG27
        '
        Me.ComboBoxLG27.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG27.ForeColor = System.Drawing.Color.Orange
        Me.ComboBoxLG27.FormattingEnabled = True
        Me.ComboBoxLG27.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG27.Location = New System.Drawing.Point(600, 105)
        Me.ComboBoxLG27.Name = "ComboBoxLG27"
        Me.ComboBoxLG27.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG27.TabIndex = 3
        '
        'ComboBoxLG26
        '
        Me.ComboBoxLG26.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG26.ForeColor = System.Drawing.Color.Orange
        Me.ComboBoxLG26.FormattingEnabled = True
        Me.ComboBoxLG26.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG26.Location = New System.Drawing.Point(600, 69)
        Me.ComboBoxLG26.Name = "ComboBoxLG26"
        Me.ComboBoxLG26.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG26.TabIndex = 3
        '
        'TextBoxQP30
        '
        Me.TextBoxQP30.Enabled = False
        Me.TextBoxQP30.Location = New System.Drawing.Point(703, 226)
        Me.TextBoxQP30.Name = "TextBoxQP30"
        Me.TextBoxQP30.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP30.TabIndex = 2
        '
        'TextBoxTQP30
        '
        Me.TextBoxTQP30.Enabled = False
        Me.TextBoxTQP30.Location = New System.Drawing.Point(835, 226)
        Me.TextBoxTQP30.Name = "TextBoxTQP30"
        Me.TextBoxTQP30.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP30.TabIndex = 2
        '
        'TextBoxQP29
        '
        Me.TextBoxQP29.Enabled = False
        Me.TextBoxQP29.Location = New System.Drawing.Point(703, 186)
        Me.TextBoxQP29.Name = "TextBoxQP29"
        Me.TextBoxQP29.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP29.TabIndex = 2
        '
        'TextBoxTQP29
        '
        Me.TextBoxTQP29.Enabled = False
        Me.TextBoxTQP29.Location = New System.Drawing.Point(835, 186)
        Me.TextBoxTQP29.Name = "TextBoxTQP29"
        Me.TextBoxTQP29.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP29.TabIndex = 2
        '
        'TextBoxQP28
        '
        Me.TextBoxQP28.Enabled = False
        Me.TextBoxQP28.Location = New System.Drawing.Point(703, 146)
        Me.TextBoxQP28.Name = "TextBoxQP28"
        Me.TextBoxQP28.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP28.TabIndex = 2
        '
        'TextBoxCoureTitle30
        '
        Me.TextBoxCoureTitle30.Location = New System.Drawing.Point(138, 225)
        Me.TextBoxCoureTitle30.Name = "TextBoxCoureTitle30"
        Me.TextBoxCoureTitle30.Size = New System.Drawing.Size(317, 29)
        Me.TextBoxCoureTitle30.TabIndex = 2
        Me.TextBoxCoureTitle30.Text = "Math Elective"
        '
        'TextBoxCredit30
        '
        Me.TextBoxCredit30.Location = New System.Drawing.Point(479, 226)
        Me.TextBoxCredit30.Name = "TextBoxCredit30"
        Me.TextBoxCredit30.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit30.TabIndex = 2
        '
        'TextBoxTQP28
        '
        Me.TextBoxTQP28.Enabled = False
        Me.TextBoxTQP28.Location = New System.Drawing.Point(835, 146)
        Me.TextBoxTQP28.Name = "TextBoxTQP28"
        Me.TextBoxTQP28.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP28.TabIndex = 2
        '
        'TextBoxQP27
        '
        Me.TextBoxQP27.Enabled = False
        Me.TextBoxQP27.Location = New System.Drawing.Point(703, 107)
        Me.TextBoxQP27.Name = "TextBoxQP27"
        Me.TextBoxQP27.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP27.TabIndex = 2
        '
        'TextBoxCoureTitle29
        '
        Me.TextBoxCoureTitle29.Enabled = False
        Me.TextBoxCoureTitle29.Location = New System.Drawing.Point(138, 185)
        Me.TextBoxCoureTitle29.Name = "TextBoxCoureTitle29"
        Me.TextBoxCoureTitle29.Size = New System.Drawing.Size(317, 29)
        Me.TextBoxCoureTitle29.TabIndex = 2
        Me.TextBoxCoureTitle29.Text = "Discrete Mathematics"
        '
        'TextBoxCredit29
        '
        Me.TextBoxCredit29.Location = New System.Drawing.Point(479, 186)
        Me.TextBoxCredit29.Name = "TextBoxCredit29"
        Me.TextBoxCredit29.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit29.TabIndex = 2
        '
        'TextBoxTQP27
        '
        Me.TextBoxTQP27.Enabled = False
        Me.TextBoxTQP27.Location = New System.Drawing.Point(835, 107)
        Me.TextBoxTQP27.Name = "TextBoxTQP27"
        Me.TextBoxTQP27.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP27.TabIndex = 2
        '
        'TextBoxQP26
        '
        Me.TextBoxQP26.Enabled = False
        Me.TextBoxQP26.Location = New System.Drawing.Point(703, 70)
        Me.TextBoxQP26.Name = "TextBoxQP26"
        Me.TextBoxQP26.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP26.TabIndex = 2
        '
        'TextBoxCoureTitle28
        '
        Me.TextBoxCoureTitle28.Enabled = False
        Me.TextBoxCoureTitle28.Location = New System.Drawing.Point(138, 145)
        Me.TextBoxCoureTitle28.Name = "TextBoxCoureTitle28"
        Me.TextBoxCoureTitle28.Size = New System.Drawing.Size(317, 29)
        Me.TextBoxCoureTitle28.TabIndex = 2
        Me.TextBoxCoureTitle28.Text = "Calculus III"
        '
        'TextBoxCredit28
        '
        Me.TextBoxCredit28.Location = New System.Drawing.Point(479, 146)
        Me.TextBoxCredit28.Name = "TextBoxCredit28"
        Me.TextBoxCredit28.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit28.TabIndex = 2
        '
        'TextBoxTQP26
        '
        Me.TextBoxTQP26.Enabled = False
        Me.TextBoxTQP26.Location = New System.Drawing.Point(835, 70)
        Me.TextBoxTQP26.Name = "TextBoxTQP26"
        Me.TextBoxTQP26.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP26.TabIndex = 2
        '
        'TextBoxCoureTitle27
        '
        Me.TextBoxCoureTitle27.Enabled = False
        Me.TextBoxCoureTitle27.Location = New System.Drawing.Point(138, 106)
        Me.TextBoxCoureTitle27.Name = "TextBoxCoureTitle27"
        Me.TextBoxCoureTitle27.Size = New System.Drawing.Size(317, 29)
        Me.TextBoxCoureTitle27.TabIndex = 2
        Me.TextBoxCoureTitle27.Text = "Calculus II"
        '
        'TextBoxCoureTitle26
        '
        Me.TextBoxCoureTitle26.Enabled = False
        Me.TextBoxCoureTitle26.Location = New System.Drawing.Point(138, 69)
        Me.TextBoxCoureTitle26.Name = "TextBoxCoureTitle26"
        Me.TextBoxCoureTitle26.Size = New System.Drawing.Size(317, 29)
        Me.TextBoxCoureTitle26.TabIndex = 2
        Me.TextBoxCoureTitle26.Text = "Calculus I"
        '
        'TextBoxCredit27
        '
        Me.TextBoxCredit27.Location = New System.Drawing.Point(479, 107)
        Me.TextBoxCredit27.Name = "TextBoxCredit27"
        Me.TextBoxCredit27.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit27.TabIndex = 2
        '
        'TextBoxCredit26
        '
        Me.TextBoxCredit26.Location = New System.Drawing.Point(479, 70)
        Me.TextBoxCredit26.Name = "TextBoxCredit26"
        Me.TextBoxCredit26.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit26.TabIndex = 2
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.ForeColor = System.Drawing.Color.Orange
        Me.Label38.Location = New System.Drawing.Point(14, 233)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(86, 22)
        Me.Label38.TabIndex = 1
        Me.Label38.Text = "MAT-XXX"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.ForeColor = System.Drawing.Color.Orange
        Me.Label42.Location = New System.Drawing.Point(14, 192)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(77, 22)
        Me.Label42.TabIndex = 1
        Me.Label42.Text = "MAT-213"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.ForeColor = System.Drawing.Color.Orange
        Me.Label45.Location = New System.Drawing.Point(14, 153)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(77, 22)
        Me.Label45.TabIndex = 1
        Me.Label45.Text = "MAT-221"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.ForeColor = System.Drawing.Color.Orange
        Me.Label47.Location = New System.Drawing.Point(14, 113)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(77, 22)
        Me.Label47.TabIndex = 1
        Me.Label47.Text = "MAT-122"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.ForeColor = System.Drawing.Color.Orange
        Me.Label48.Location = New System.Drawing.Point(14, 73)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(77, 22)
        Me.Label48.TabIndex = 1
        Me.Label48.Text = "MAT-121"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.ForeColor = System.Drawing.Color.Orange
        Me.Label49.Location = New System.Drawing.Point(945, 26)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(112, 26)
        Me.Label49.TabIndex = 0
        Me.Label49.Text = "Completed"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.ForeColor = System.Drawing.Color.Orange
        Me.Label50.Location = New System.Drawing.Point(842, 26)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(53, 26)
        Me.Label50.TabIndex = 0
        Me.Label50.Text = "TQP"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.ForeColor = System.Drawing.Color.Orange
        Me.Label51.Location = New System.Drawing.Point(709, 26)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(40, 26)
        Me.Label51.TabIndex = 0
        Me.Label51.Text = "QP"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.ForeColor = System.Drawing.Color.Orange
        Me.Label46.Location = New System.Drawing.Point(12, 25)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(98, 26)
        Me.Label46.TabIndex = 0
        Me.Label46.Text = "CourseID"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.ForeColor = System.Drawing.Color.Orange
        Me.Label44.Location = New System.Drawing.Point(142, 25)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(122, 26)
        Me.Label44.TabIndex = 0
        Me.Label44.Text = "Course Title"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.ForeColor = System.Drawing.Color.Orange
        Me.Label52.Location = New System.Drawing.Point(595, 26)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(40, 26)
        Me.Label52.TabIndex = 0
        Me.Label52.Text = "LG"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.ForeColor = System.Drawing.Color.Orange
        Me.Label53.Location = New System.Drawing.Point(483, 26)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(77, 26)
        Me.Label53.TabIndex = 0
        Me.Label53.Text = "Credits"
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.DarkBlue
        Me.Panel7.Controls.Add(Me.ButtonReseTMinor)
        Me.Panel7.Controls.Add(Me.LabelGPAMinor)
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel7.Location = New System.Drawing.Point(0, 672)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(1063, 62)
        Me.Panel7.TabIndex = 2
        '
        'ButtonReseTMinor
        '
        Me.ButtonReseTMinor.BackColor = System.Drawing.Color.DarkBlue
        Me.ButtonReseTMinor.FlatAppearance.BorderSize = 0
        Me.ButtonReseTMinor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonReseTMinor.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonReseTMinor.ForeColor = System.Drawing.Color.Orange
        Me.ButtonReseTMinor.Location = New System.Drawing.Point(941, 13)
        Me.ButtonReseTMinor.Name = "ButtonReseTMinor"
        Me.ButtonReseTMinor.Size = New System.Drawing.Size(116, 38)
        Me.ButtonReseTMinor.TabIndex = 1
        Me.ButtonReseTMinor.Text = "RESET"
        Me.ButtonReseTMinor.UseVisualStyleBackColor = False
        '
        'LabelGPAMinor
        '
        Me.LabelGPAMinor.AutoSize = True
        Me.LabelGPAMinor.Font = New System.Drawing.Font("Palatino Linotype", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelGPAMinor.ForeColor = System.Drawing.Color.Orange
        Me.LabelGPAMinor.Location = New System.Drawing.Point(12, 17)
        Me.LabelGPAMinor.Name = "LabelGPAMinor"
        Me.LabelGPAMinor.Size = New System.Drawing.Size(141, 28)
        Me.LabelGPAMinor.TabIndex = 0
        Me.LabelGPAMinor.Text = "GPA = [ 0.00 ]"
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.White
        Me.TabPage4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage4.Controls.Add(Me.Panel10)
        Me.TabPage4.Controls.Add(Me.Panel9)
        Me.TabPage4.Location = New System.Drawing.Point(4, 34)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(1067, 738)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Electives"
        Me.TabPage4.ToolTipText = "Departmental Electives"
        '
        'Panel10
        '
        Me.Panel10.Controls.Add(Me.CheckBox31)
        Me.Panel10.Controls.Add(Me.CheckBox32)
        Me.Panel10.Controls.Add(Me.CheckBox33)
        Me.Panel10.Controls.Add(Me.CheckBox34)
        Me.Panel10.Controls.Add(Me.CheckBox35)
        Me.Panel10.Controls.Add(Me.CheckBox36)
        Me.Panel10.Controls.Add(Me.CheckBox37)
        Me.Panel10.Controls.Add(Me.CheckBox38)
        Me.Panel10.Controls.Add(Me.CheckBox39)
        Me.Panel10.Controls.Add(Me.ComboBoxLG39)
        Me.Panel10.Controls.Add(Me.ComboBoxLG38)
        Me.Panel10.Controls.Add(Me.ComboBoxLG37)
        Me.Panel10.Controls.Add(Me.ComboBoxLG36)
        Me.Panel10.Controls.Add(Me.ComboBoxLG35)
        Me.Panel10.Controls.Add(Me.ComboBoxLG34)
        Me.Panel10.Controls.Add(Me.ComboBoxLG33)
        Me.Panel10.Controls.Add(Me.ComboBoxLG32)
        Me.Panel10.Controls.Add(Me.ComboBoxLG31)
        Me.Panel10.Controls.Add(Me.TextBoxQP39)
        Me.Panel10.Controls.Add(Me.TextBoxTQP39)
        Me.Panel10.Controls.Add(Me.TextBoxCourseTitle39)
        Me.Panel10.Controls.Add(Me.TextBoxCourseID9)
        Me.Panel10.Controls.Add(Me.TextBoxCredit39)
        Me.Panel10.Controls.Add(Me.TextBoxQP38)
        Me.Panel10.Controls.Add(Me.TextBoxTQP38)
        Me.Panel10.Controls.Add(Me.TextBoxQP37)
        Me.Panel10.Controls.Add(Me.TextBoxCourseTitle38)
        Me.Panel10.Controls.Add(Me.TextBoxCourseID8)
        Me.Panel10.Controls.Add(Me.TextBoxCredit38)
        Me.Panel10.Controls.Add(Me.TextBoxTQP37)
        Me.Panel10.Controls.Add(Me.TextBoxCourseTitle37)
        Me.Panel10.Controls.Add(Me.TextBoxCourseID7)
        Me.Panel10.Controls.Add(Me.TextBoxQP36)
        Me.Panel10.Controls.Add(Me.TextBoxCredit37)
        Me.Panel10.Controls.Add(Me.TextBoxQP35)
        Me.Panel10.Controls.Add(Me.TextBoxTQP36)
        Me.Panel10.Controls.Add(Me.TextBoxTQP35)
        Me.Panel10.Controls.Add(Me.TextBoxCourseTitle36)
        Me.Panel10.Controls.Add(Me.TextBoxCourseID6)
        Me.Panel10.Controls.Add(Me.TextBoxQP34)
        Me.Panel10.Controls.Add(Me.TextBoxCredit36)
        Me.Panel10.Controls.Add(Me.TextBoxCourseTitle35)
        Me.Panel10.Controls.Add(Me.TextBoxTQP34)
        Me.Panel10.Controls.Add(Me.TextBoxCourseID5)
        Me.Panel10.Controls.Add(Me.TextBoxQP33)
        Me.Panel10.Controls.Add(Me.TextBoxCredit35)
        Me.Panel10.Controls.Add(Me.TextBoxCourseTitle34)
        Me.Panel10.Controls.Add(Me.TextBoxTQP33)
        Me.Panel10.Controls.Add(Me.TextBoxCourseID4)
        Me.Panel10.Controls.Add(Me.TextBoxQP32)
        Me.Panel10.Controls.Add(Me.TextBoxCredit34)
        Me.Panel10.Controls.Add(Me.TextBoxCourseTitle33)
        Me.Panel10.Controls.Add(Me.TextBoxTQP32)
        Me.Panel10.Controls.Add(Me.TextBoxCourseID3)
        Me.Panel10.Controls.Add(Me.TextBoxQP31)
        Me.Panel10.Controls.Add(Me.TextBoxCourseTitle32)
        Me.Panel10.Controls.Add(Me.TextBoxCredit33)
        Me.Panel10.Controls.Add(Me.TextBoxCourseID2)
        Me.Panel10.Controls.Add(Me.TextBoxCourseTitle31)
        Me.Panel10.Controls.Add(Me.TextBoxTQP31)
        Me.Panel10.Controls.Add(Me.TextBoxCourseID1)
        Me.Panel10.Controls.Add(Me.TextBoxCredit32)
        Me.Panel10.Controls.Add(Me.TextBoxCredit31)
        Me.Panel10.Controls.Add(Me.Label59)
        Me.Panel10.Controls.Add(Me.Label60)
        Me.Panel10.Controls.Add(Me.Label61)
        Me.Panel10.Controls.Add(Me.Label62)
        Me.Panel10.Controls.Add(Me.Label39)
        Me.Panel10.Controls.Add(Me.Label22)
        Me.Panel10.Controls.Add(Me.Label63)
        Me.Panel10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel10.Location = New System.Drawing.Point(0, 0)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(1063, 648)
        Me.Panel10.TabIndex = 3
        '
        'CheckBox31
        '
        Me.CheckBox31.AutoSize = True
        Me.CheckBox31.Enabled = False
        Me.CheckBox31.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox31.Location = New System.Drawing.Point(976, 69)
        Me.CheckBox31.Name = "CheckBox31"
        Me.CheckBox31.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox31.TabIndex = 4
        Me.CheckBox31.Text = "False"
        Me.CheckBox31.UseVisualStyleBackColor = True
        '
        'CheckBox32
        '
        Me.CheckBox32.AutoSize = True
        Me.CheckBox32.Enabled = False
        Me.CheckBox32.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox32.Location = New System.Drawing.Point(976, 105)
        Me.CheckBox32.Name = "CheckBox32"
        Me.CheckBox32.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox32.TabIndex = 4
        Me.CheckBox32.Text = "False"
        Me.CheckBox32.UseVisualStyleBackColor = True
        '
        'CheckBox33
        '
        Me.CheckBox33.AutoSize = True
        Me.CheckBox33.Enabled = False
        Me.CheckBox33.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox33.Location = New System.Drawing.Point(976, 146)
        Me.CheckBox33.Name = "CheckBox33"
        Me.CheckBox33.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox33.TabIndex = 4
        Me.CheckBox33.Text = "False"
        Me.CheckBox33.UseVisualStyleBackColor = True
        '
        'CheckBox34
        '
        Me.CheckBox34.AutoSize = True
        Me.CheckBox34.Enabled = False
        Me.CheckBox34.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox34.Location = New System.Drawing.Point(976, 185)
        Me.CheckBox34.Name = "CheckBox34"
        Me.CheckBox34.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox34.TabIndex = 4
        Me.CheckBox34.Text = "False"
        Me.CheckBox34.UseVisualStyleBackColor = True
        '
        'CheckBox35
        '
        Me.CheckBox35.AutoSize = True
        Me.CheckBox35.Enabled = False
        Me.CheckBox35.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox35.Location = New System.Drawing.Point(976, 225)
        Me.CheckBox35.Name = "CheckBox35"
        Me.CheckBox35.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox35.TabIndex = 4
        Me.CheckBox35.Text = "False"
        Me.CheckBox35.UseVisualStyleBackColor = True
        '
        'CheckBox36
        '
        Me.CheckBox36.AutoSize = True
        Me.CheckBox36.Enabled = False
        Me.CheckBox36.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox36.Location = New System.Drawing.Point(976, 265)
        Me.CheckBox36.Name = "CheckBox36"
        Me.CheckBox36.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox36.TabIndex = 4
        Me.CheckBox36.Text = "False"
        Me.CheckBox36.UseVisualStyleBackColor = True
        '
        'CheckBox37
        '
        Me.CheckBox37.AutoSize = True
        Me.CheckBox37.Enabled = False
        Me.CheckBox37.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox37.Location = New System.Drawing.Point(976, 305)
        Me.CheckBox37.Name = "CheckBox37"
        Me.CheckBox37.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox37.TabIndex = 4
        Me.CheckBox37.Text = "False"
        Me.CheckBox37.UseVisualStyleBackColor = True
        '
        'CheckBox38
        '
        Me.CheckBox38.AutoSize = True
        Me.CheckBox38.Enabled = False
        Me.CheckBox38.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox38.Location = New System.Drawing.Point(976, 345)
        Me.CheckBox38.Name = "CheckBox38"
        Me.CheckBox38.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox38.TabIndex = 4
        Me.CheckBox38.Text = "False"
        Me.CheckBox38.UseVisualStyleBackColor = True
        '
        'CheckBox39
        '
        Me.CheckBox39.AutoSize = True
        Me.CheckBox39.Enabled = False
        Me.CheckBox39.ForeColor = System.Drawing.Color.DarkBlue
        Me.CheckBox39.Location = New System.Drawing.Point(976, 385)
        Me.CheckBox39.Name = "CheckBox39"
        Me.CheckBox39.Size = New System.Drawing.Size(66, 26)
        Me.CheckBox39.TabIndex = 4
        Me.CheckBox39.Text = "False"
        Me.CheckBox39.UseVisualStyleBackColor = True
        '
        'ComboBoxLG39
        '
        Me.ComboBoxLG39.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG39.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG39.FormattingEnabled = True
        Me.ComboBoxLG39.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG39.Location = New System.Drawing.Point(593, 385)
        Me.ComboBoxLG39.Name = "ComboBoxLG39"
        Me.ComboBoxLG39.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG39.TabIndex = 3
        '
        'ComboBoxLG38
        '
        Me.ComboBoxLG38.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG38.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG38.FormattingEnabled = True
        Me.ComboBoxLG38.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG38.Location = New System.Drawing.Point(593, 345)
        Me.ComboBoxLG38.Name = "ComboBoxLG38"
        Me.ComboBoxLG38.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG38.TabIndex = 3
        '
        'ComboBoxLG37
        '
        Me.ComboBoxLG37.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG37.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG37.FormattingEnabled = True
        Me.ComboBoxLG37.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG37.Location = New System.Drawing.Point(593, 305)
        Me.ComboBoxLG37.Name = "ComboBoxLG37"
        Me.ComboBoxLG37.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG37.TabIndex = 3
        '
        'ComboBoxLG36
        '
        Me.ComboBoxLG36.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG36.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG36.FormattingEnabled = True
        Me.ComboBoxLG36.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG36.Location = New System.Drawing.Point(593, 265)
        Me.ComboBoxLG36.Name = "ComboBoxLG36"
        Me.ComboBoxLG36.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG36.TabIndex = 3
        '
        'ComboBoxLG35
        '
        Me.ComboBoxLG35.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG35.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG35.FormattingEnabled = True
        Me.ComboBoxLG35.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG35.Location = New System.Drawing.Point(593, 225)
        Me.ComboBoxLG35.Name = "ComboBoxLG35"
        Me.ComboBoxLG35.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG35.TabIndex = 3
        '
        'ComboBoxLG34
        '
        Me.ComboBoxLG34.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG34.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG34.FormattingEnabled = True
        Me.ComboBoxLG34.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG34.Location = New System.Drawing.Point(593, 185)
        Me.ComboBoxLG34.Name = "ComboBoxLG34"
        Me.ComboBoxLG34.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG34.TabIndex = 3
        '
        'ComboBoxLG33
        '
        Me.ComboBoxLG33.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG33.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG33.FormattingEnabled = True
        Me.ComboBoxLG33.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG33.Location = New System.Drawing.Point(593, 146)
        Me.ComboBoxLG33.Name = "ComboBoxLG33"
        Me.ComboBoxLG33.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG33.TabIndex = 3
        '
        'ComboBoxLG32
        '
        Me.ComboBoxLG32.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG32.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG32.FormattingEnabled = True
        Me.ComboBoxLG32.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG32.Location = New System.Drawing.Point(593, 105)
        Me.ComboBoxLG32.Name = "ComboBoxLG32"
        Me.ComboBoxLG32.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG32.TabIndex = 3
        '
        'ComboBoxLG31
        '
        Me.ComboBoxLG31.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxLG31.ForeColor = System.Drawing.Color.DarkBlue
        Me.ComboBoxLG31.FormattingEnabled = True
        Me.ComboBoxLG31.Items.AddRange(New Object() {"--", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"})
        Me.ComboBoxLG31.Location = New System.Drawing.Point(593, 69)
        Me.ComboBoxLG31.Name = "ComboBoxLG31"
        Me.ComboBoxLG31.Size = New System.Drawing.Size(82, 30)
        Me.ComboBoxLG31.TabIndex = 3
        '
        'TextBoxQP39
        '
        Me.TextBoxQP39.Enabled = False
        Me.TextBoxQP39.Location = New System.Drawing.Point(697, 386)
        Me.TextBoxQP39.Name = "TextBoxQP39"
        Me.TextBoxQP39.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP39.TabIndex = 2
        '
        'TextBoxTQP39
        '
        Me.TextBoxTQP39.Enabled = False
        Me.TextBoxTQP39.Location = New System.Drawing.Point(829, 386)
        Me.TextBoxTQP39.Name = "TextBoxTQP39"
        Me.TextBoxTQP39.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP39.TabIndex = 2
        '
        'TextBoxCourseTitle39
        '
        Me.TextBoxCourseTitle39.Location = New System.Drawing.Point(153, 386)
        Me.TextBoxCourseTitle39.Name = "TextBoxCourseTitle39"
        Me.TextBoxCourseTitle39.Size = New System.Drawing.Size(280, 29)
        Me.TextBoxCourseTitle39.TabIndex = 2
        Me.TextBoxCourseTitle39.Text = "General Elective"
        '
        'TextBoxCourseID9
        '
        Me.TextBoxCourseID9.Location = New System.Drawing.Point(29, 386)
        Me.TextBoxCourseID9.Name = "TextBoxCourseID9"
        Me.TextBoxCourseID9.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCourseID9.TabIndex = 2
        '
        'TextBoxCredit39
        '
        Me.TextBoxCredit39.Location = New System.Drawing.Point(458, 386)
        Me.TextBoxCredit39.Name = "TextBoxCredit39"
        Me.TextBoxCredit39.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit39.TabIndex = 2
        '
        'TextBoxQP38
        '
        Me.TextBoxQP38.Enabled = False
        Me.TextBoxQP38.Location = New System.Drawing.Point(697, 346)
        Me.TextBoxQP38.Name = "TextBoxQP38"
        Me.TextBoxQP38.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP38.TabIndex = 2
        '
        'TextBoxTQP38
        '
        Me.TextBoxTQP38.Enabled = False
        Me.TextBoxTQP38.Location = New System.Drawing.Point(829, 346)
        Me.TextBoxTQP38.Name = "TextBoxTQP38"
        Me.TextBoxTQP38.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP38.TabIndex = 2
        '
        'TextBoxQP37
        '
        Me.TextBoxQP37.Enabled = False
        Me.TextBoxQP37.Location = New System.Drawing.Point(697, 306)
        Me.TextBoxQP37.Name = "TextBoxQP37"
        Me.TextBoxQP37.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP37.TabIndex = 2
        '
        'TextBoxCourseTitle38
        '
        Me.TextBoxCourseTitle38.Location = New System.Drawing.Point(153, 346)
        Me.TextBoxCourseTitle38.Name = "TextBoxCourseTitle38"
        Me.TextBoxCourseTitle38.Size = New System.Drawing.Size(280, 29)
        Me.TextBoxCourseTitle38.TabIndex = 2
        Me.TextBoxCourseTitle38.Text = "General Elective"
        '
        'TextBoxCourseID8
        '
        Me.TextBoxCourseID8.Location = New System.Drawing.Point(29, 346)
        Me.TextBoxCourseID8.Name = "TextBoxCourseID8"
        Me.TextBoxCourseID8.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCourseID8.TabIndex = 2
        '
        'TextBoxCredit38
        '
        Me.TextBoxCredit38.Location = New System.Drawing.Point(458, 346)
        Me.TextBoxCredit38.Name = "TextBoxCredit38"
        Me.TextBoxCredit38.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit38.TabIndex = 2
        '
        'TextBoxTQP37
        '
        Me.TextBoxTQP37.Enabled = False
        Me.TextBoxTQP37.Location = New System.Drawing.Point(829, 306)
        Me.TextBoxTQP37.Name = "TextBoxTQP37"
        Me.TextBoxTQP37.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP37.TabIndex = 2
        '
        'TextBoxCourseTitle37
        '
        Me.TextBoxCourseTitle37.Location = New System.Drawing.Point(153, 306)
        Me.TextBoxCourseTitle37.Name = "TextBoxCourseTitle37"
        Me.TextBoxCourseTitle37.Size = New System.Drawing.Size(280, 29)
        Me.TextBoxCourseTitle37.TabIndex = 2
        Me.TextBoxCourseTitle37.Text = "General Elective"
        '
        'TextBoxCourseID7
        '
        Me.TextBoxCourseID7.Location = New System.Drawing.Point(29, 306)
        Me.TextBoxCourseID7.Name = "TextBoxCourseID7"
        Me.TextBoxCourseID7.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCourseID7.TabIndex = 2
        '
        'TextBoxQP36
        '
        Me.TextBoxQP36.Enabled = False
        Me.TextBoxQP36.Location = New System.Drawing.Point(697, 266)
        Me.TextBoxQP36.Name = "TextBoxQP36"
        Me.TextBoxQP36.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP36.TabIndex = 2
        '
        'TextBoxCredit37
        '
        Me.TextBoxCredit37.Location = New System.Drawing.Point(458, 306)
        Me.TextBoxCredit37.Name = "TextBoxCredit37"
        Me.TextBoxCredit37.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit37.TabIndex = 2
        '
        'TextBoxQP35
        '
        Me.TextBoxQP35.Enabled = False
        Me.TextBoxQP35.Location = New System.Drawing.Point(697, 226)
        Me.TextBoxQP35.Name = "TextBoxQP35"
        Me.TextBoxQP35.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP35.TabIndex = 2
        '
        'TextBoxTQP36
        '
        Me.TextBoxTQP36.Enabled = False
        Me.TextBoxTQP36.Location = New System.Drawing.Point(829, 266)
        Me.TextBoxTQP36.Name = "TextBoxTQP36"
        Me.TextBoxTQP36.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP36.TabIndex = 2
        '
        'TextBoxTQP35
        '
        Me.TextBoxTQP35.Enabled = False
        Me.TextBoxTQP35.Location = New System.Drawing.Point(829, 226)
        Me.TextBoxTQP35.Name = "TextBoxTQP35"
        Me.TextBoxTQP35.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP35.TabIndex = 2
        '
        'TextBoxCourseTitle36
        '
        Me.TextBoxCourseTitle36.Location = New System.Drawing.Point(153, 266)
        Me.TextBoxCourseTitle36.Name = "TextBoxCourseTitle36"
        Me.TextBoxCourseTitle36.Size = New System.Drawing.Size(280, 29)
        Me.TextBoxCourseTitle36.TabIndex = 2
        Me.TextBoxCourseTitle36.Text = "General Elective"
        '
        'TextBoxCourseID6
        '
        Me.TextBoxCourseID6.Location = New System.Drawing.Point(29, 266)
        Me.TextBoxCourseID6.Name = "TextBoxCourseID6"
        Me.TextBoxCourseID6.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCourseID6.TabIndex = 2
        '
        'TextBoxQP34
        '
        Me.TextBoxQP34.Enabled = False
        Me.TextBoxQP34.Location = New System.Drawing.Point(697, 186)
        Me.TextBoxQP34.Name = "TextBoxQP34"
        Me.TextBoxQP34.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP34.TabIndex = 2
        '
        'TextBoxCredit36
        '
        Me.TextBoxCredit36.Location = New System.Drawing.Point(458, 266)
        Me.TextBoxCredit36.Name = "TextBoxCredit36"
        Me.TextBoxCredit36.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit36.TabIndex = 2
        '
        'TextBoxCourseTitle35
        '
        Me.TextBoxCourseTitle35.Location = New System.Drawing.Point(153, 226)
        Me.TextBoxCourseTitle35.Name = "TextBoxCourseTitle35"
        Me.TextBoxCourseTitle35.Size = New System.Drawing.Size(280, 29)
        Me.TextBoxCourseTitle35.TabIndex = 2
        Me.TextBoxCourseTitle35.Text = "General Elective"
        '
        'TextBoxTQP34
        '
        Me.TextBoxTQP34.Enabled = False
        Me.TextBoxTQP34.Location = New System.Drawing.Point(829, 186)
        Me.TextBoxTQP34.Name = "TextBoxTQP34"
        Me.TextBoxTQP34.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP34.TabIndex = 2
        '
        'TextBoxCourseID5
        '
        Me.TextBoxCourseID5.Location = New System.Drawing.Point(29, 226)
        Me.TextBoxCourseID5.Name = "TextBoxCourseID5"
        Me.TextBoxCourseID5.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCourseID5.TabIndex = 2
        '
        'TextBoxQP33
        '
        Me.TextBoxQP33.Enabled = False
        Me.TextBoxQP33.Location = New System.Drawing.Point(697, 146)
        Me.TextBoxQP33.Name = "TextBoxQP33"
        Me.TextBoxQP33.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP33.TabIndex = 2
        '
        'TextBoxCredit35
        '
        Me.TextBoxCredit35.Location = New System.Drawing.Point(458, 226)
        Me.TextBoxCredit35.Name = "TextBoxCredit35"
        Me.TextBoxCredit35.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit35.TabIndex = 2
        '
        'TextBoxCourseTitle34
        '
        Me.TextBoxCourseTitle34.Location = New System.Drawing.Point(153, 186)
        Me.TextBoxCourseTitle34.Name = "TextBoxCourseTitle34"
        Me.TextBoxCourseTitle34.Size = New System.Drawing.Size(280, 29)
        Me.TextBoxCourseTitle34.TabIndex = 2
        Me.TextBoxCourseTitle34.Text = "General Elective"
        '
        'TextBoxTQP33
        '
        Me.TextBoxTQP33.Enabled = False
        Me.TextBoxTQP33.Location = New System.Drawing.Point(829, 146)
        Me.TextBoxTQP33.Name = "TextBoxTQP33"
        Me.TextBoxTQP33.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP33.TabIndex = 2
        '
        'TextBoxCourseID4
        '
        Me.TextBoxCourseID4.Location = New System.Drawing.Point(29, 186)
        Me.TextBoxCourseID4.Name = "TextBoxCourseID4"
        Me.TextBoxCourseID4.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCourseID4.TabIndex = 2
        '
        'TextBoxQP32
        '
        Me.TextBoxQP32.Enabled = False
        Me.TextBoxQP32.Location = New System.Drawing.Point(697, 107)
        Me.TextBoxQP32.Name = "TextBoxQP32"
        Me.TextBoxQP32.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP32.TabIndex = 2
        '
        'TextBoxCredit34
        '
        Me.TextBoxCredit34.Location = New System.Drawing.Point(458, 186)
        Me.TextBoxCredit34.Name = "TextBoxCredit34"
        Me.TextBoxCredit34.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit34.TabIndex = 2
        '
        'TextBoxCourseTitle33
        '
        Me.TextBoxCourseTitle33.Location = New System.Drawing.Point(153, 146)
        Me.TextBoxCourseTitle33.Name = "TextBoxCourseTitle33"
        Me.TextBoxCourseTitle33.Size = New System.Drawing.Size(280, 29)
        Me.TextBoxCourseTitle33.TabIndex = 2
        Me.TextBoxCourseTitle33.Text = "General Elective"
        '
        'TextBoxTQP32
        '
        Me.TextBoxTQP32.Enabled = False
        Me.TextBoxTQP32.Location = New System.Drawing.Point(829, 107)
        Me.TextBoxTQP32.Name = "TextBoxTQP32"
        Me.TextBoxTQP32.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP32.TabIndex = 2
        '
        'TextBoxCourseID3
        '
        Me.TextBoxCourseID3.Location = New System.Drawing.Point(29, 146)
        Me.TextBoxCourseID3.Name = "TextBoxCourseID3"
        Me.TextBoxCourseID3.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCourseID3.TabIndex = 2
        '
        'TextBoxQP31
        '
        Me.TextBoxQP31.Enabled = False
        Me.TextBoxQP31.Location = New System.Drawing.Point(697, 70)
        Me.TextBoxQP31.Name = "TextBoxQP31"
        Me.TextBoxQP31.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxQP31.TabIndex = 2
        '
        'TextBoxCourseTitle32
        '
        Me.TextBoxCourseTitle32.Location = New System.Drawing.Point(153, 107)
        Me.TextBoxCourseTitle32.Name = "TextBoxCourseTitle32"
        Me.TextBoxCourseTitle32.Size = New System.Drawing.Size(280, 29)
        Me.TextBoxCourseTitle32.TabIndex = 2
        Me.TextBoxCourseTitle32.Text = "General Elective"
        '
        'TextBoxCredit33
        '
        Me.TextBoxCredit33.Location = New System.Drawing.Point(458, 146)
        Me.TextBoxCredit33.Name = "TextBoxCredit33"
        Me.TextBoxCredit33.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit33.TabIndex = 2
        '
        'TextBoxCourseID2
        '
        Me.TextBoxCourseID2.Location = New System.Drawing.Point(29, 107)
        Me.TextBoxCourseID2.Name = "TextBoxCourseID2"
        Me.TextBoxCourseID2.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCourseID2.TabIndex = 2
        '
        'TextBoxCourseTitle31
        '
        Me.TextBoxCourseTitle31.Location = New System.Drawing.Point(153, 70)
        Me.TextBoxCourseTitle31.Name = "TextBoxCourseTitle31"
        Me.TextBoxCourseTitle31.Size = New System.Drawing.Size(280, 29)
        Me.TextBoxCourseTitle31.TabIndex = 2
        Me.TextBoxCourseTitle31.Text = "General Elective"
        '
        'TextBoxTQP31
        '
        Me.TextBoxTQP31.Enabled = False
        Me.TextBoxTQP31.Location = New System.Drawing.Point(829, 70)
        Me.TextBoxTQP31.Name = "TextBoxTQP31"
        Me.TextBoxTQP31.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxTQP31.TabIndex = 2
        '
        'TextBoxCourseID1
        '
        Me.TextBoxCourseID1.Location = New System.Drawing.Point(29, 70)
        Me.TextBoxCourseID1.Name = "TextBoxCourseID1"
        Me.TextBoxCourseID1.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCourseID1.TabIndex = 2
        '
        'TextBoxCredit32
        '
        Me.TextBoxCredit32.Location = New System.Drawing.Point(458, 107)
        Me.TextBoxCredit32.Name = "TextBoxCredit32"
        Me.TextBoxCredit32.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit32.TabIndex = 2
        '
        'TextBoxCredit31
        '
        Me.TextBoxCredit31.Location = New System.Drawing.Point(458, 70)
        Me.TextBoxCredit31.Name = "TextBoxCredit31"
        Me.TextBoxCredit31.Size = New System.Drawing.Size(100, 29)
        Me.TextBoxCredit31.TabIndex = 2
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label59.Location = New System.Drawing.Point(946, 26)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(112, 26)
        Me.Label59.TabIndex = 0
        Me.Label59.Text = "Completed"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label60.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label60.Location = New System.Drawing.Point(836, 26)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(53, 26)
        Me.Label60.TabIndex = 0
        Me.Label60.Text = "TQP"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label61.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label61.Location = New System.Drawing.Point(703, 26)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(40, 26)
        Me.Label61.TabIndex = 0
        Me.Label61.Text = "QP"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label62.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label62.Location = New System.Drawing.Point(589, 26)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(40, 26)
        Me.Label62.TabIndex = 0
        Me.Label62.Text = "LG"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label39.Location = New System.Drawing.Point(24, 26)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(98, 26)
        Me.Label39.TabIndex = 0
        Me.Label39.Text = "CourseID"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label22.Location = New System.Drawing.Point(151, 26)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(122, 26)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "Course Title"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label63.Location = New System.Drawing.Point(462, 26)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(77, 26)
        Me.Label63.TabIndex = 0
        Me.Label63.Text = "Credits"
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.Orange
        Me.Panel9.Controls.Add(Me.ResetElectives)
        Me.Panel9.Controls.Add(Me.LabelGPAElectives)
        Me.Panel9.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel9.Location = New System.Drawing.Point(0, 648)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(1063, 86)
        Me.Panel9.TabIndex = 2
        '
        'ResetElectives
        '
        Me.ResetElectives.BackColor = System.Drawing.Color.Orange
        Me.ResetElectives.FlatAppearance.BorderSize = 0
        Me.ResetElectives.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ResetElectives.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ResetElectives.ForeColor = System.Drawing.Color.DarkBlue
        Me.ResetElectives.Location = New System.Drawing.Point(944, 19)
        Me.ResetElectives.Name = "ResetElectives"
        Me.ResetElectives.Size = New System.Drawing.Size(116, 38)
        Me.ResetElectives.TabIndex = 1
        Me.ResetElectives.Text = "RESET"
        Me.ResetElectives.UseVisualStyleBackColor = False
        '
        'LabelGPAElectives
        '
        Me.LabelGPAElectives.AutoSize = True
        Me.LabelGPAElectives.Font = New System.Drawing.Font("Palatino Linotype", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelGPAElectives.ForeColor = System.Drawing.Color.DarkBlue
        Me.LabelGPAElectives.Location = New System.Drawing.Point(10, 23)
        Me.LabelGPAElectives.Name = "LabelGPAElectives"
        Me.LabelGPAElectives.Size = New System.Drawing.Size(141, 28)
        Me.LabelGPAElectives.TabIndex = 0
        Me.LabelGPAElectives.Text = "GPA = [ 0.00 ]"
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.White
        Me.TabPage5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage5.Controls.Add(Me.Panel15)
        Me.TabPage5.Controls.Add(Me.Panel14)
        Me.TabPage5.Controls.Add(Me.Panel13)
        Me.TabPage5.Controls.Add(Me.Panel12)
        Me.TabPage5.Controls.Add(Me.Panel11)
        Me.TabPage5.Location = New System.Drawing.Point(4, 34)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(1067, 738)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Report"
        Me.TabPage5.ToolTipText = "Extra courses"
        '
        'Panel15
        '
        Me.Panel15.BackColor = System.Drawing.Color.Orange
        Me.Panel15.Controls.Add(Me.LabelTotalCredits)
        Me.Panel15.Controls.Add(Me.LabelCGPA)
        Me.Panel15.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel15.Location = New System.Drawing.Point(0, 643)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(1063, 91)
        Me.Panel15.TabIndex = 3
        '
        'LabelCGPA
        '
        Me.LabelCGPA.AutoSize = True
        Me.LabelCGPA.Font = New System.Drawing.Font("Palatino Linotype", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelCGPA.Location = New System.Drawing.Point(33, 36)
        Me.LabelCGPA.Name = "LabelCGPA"
        Me.LabelCGPA.Size = New System.Drawing.Size(118, 28)
        Me.LabelCGPA.TabIndex = 2
        Me.LabelCGPA.Text = "CGPA = [ ] "
        '
        'Panel14
        '
        Me.Panel14.BackColor = System.Drawing.Color.DarkBlue
        Me.Panel14.Controls.Add(Me.LabelGPAGen)
        Me.Panel14.Controls.Add(Me.LabelSNGen)
        Me.Panel14.Controls.Add(Me.Label57)
        Me.Panel14.Controls.Add(Me.LabelErrorsGen)
        Me.Panel14.Location = New System.Drawing.Point(560, 324)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(497, 313)
        Me.Panel14.TabIndex = 2
        '
        'LabelGPAGen
        '
        Me.LabelGPAGen.AutoSize = True
        Me.LabelGPAGen.ForeColor = System.Drawing.Color.White
        Me.LabelGPAGen.Location = New System.Drawing.Point(387, 276)
        Me.LabelGPAGen.Name = "LabelGPAGen"
        Me.LabelGPAGen.Size = New System.Drawing.Size(52, 22)
        Me.LabelGPAGen.TabIndex = 4
        Me.LabelGPAGen.Text = "GPA: "
        Me.LabelGPAGen.Visible = False
        '
        'LabelSNGen
        '
        Me.LabelSNGen.AutoSize = True
        Me.LabelSNGen.Location = New System.Drawing.Point(58, 41)
        Me.LabelSNGen.Name = "LabelSNGen"
        Me.LabelSNGen.Size = New System.Drawing.Size(38, 22)
        Me.LabelSNGen.TabIndex = 3
        Me.LabelSNGen.Text = "S/N"
        Me.LabelSNGen.Visible = False
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(179, 11)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(138, 22)
        Me.Label57.TabIndex = 1
        Me.Label57.Text = "General Electives"
        '
        'LabelErrorsGen
        '
        Me.LabelErrorsGen.AutoSize = True
        Me.LabelErrorsGen.Location = New System.Drawing.Point(121, 41)
        Me.LabelErrorsGen.Name = "LabelErrorsGen"
        Me.LabelErrorsGen.Size = New System.Drawing.Size(57, 22)
        Me.LabelErrorsGen.TabIndex = 3
        Me.LabelErrorsGen.Text = "Errors"
        Me.LabelErrorsGen.Visible = False
        '
        'Panel13
        '
        Me.Panel13.BackColor = System.Drawing.Color.DarkBlue
        Me.Panel13.Controls.Add(Me.LabelGPAMi)
        Me.Panel13.Controls.Add(Me.LabelSNMi)
        Me.Panel13.Controls.Add(Me.Label56)
        Me.Panel13.Controls.Add(Me.LabelErrorsMi)
        Me.Panel13.Location = New System.Drawing.Point(3, 324)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(533, 313)
        Me.Panel13.TabIndex = 2
        '
        'LabelGPAMi
        '
        Me.LabelGPAMi.AutoSize = True
        Me.LabelGPAMi.ForeColor = System.Drawing.Color.White
        Me.LabelGPAMi.Location = New System.Drawing.Point(425, 276)
        Me.LabelGPAMi.Name = "LabelGPAMi"
        Me.LabelGPAMi.Size = New System.Drawing.Size(52, 22)
        Me.LabelGPAMi.TabIndex = 4
        Me.LabelGPAMi.Text = "GPA: "
        Me.LabelGPAMi.Visible = False
        '
        'LabelSNMi
        '
        Me.LabelSNMi.AutoSize = True
        Me.LabelSNMi.Location = New System.Drawing.Point(32, 41)
        Me.LabelSNMi.Name = "LabelSNMi"
        Me.LabelSNMi.Size = New System.Drawing.Size(38, 22)
        Me.LabelSNMi.TabIndex = 3
        Me.LabelSNMi.Text = "S/N"
        Me.LabelSNMi.Visible = False
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(216, 11)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(101, 22)
        Me.Label56.TabIndex = 1
        Me.Label56.Text = "Math Minor"
        '
        'LabelErrorsMi
        '
        Me.LabelErrorsMi.AutoSize = True
        Me.LabelErrorsMi.Location = New System.Drawing.Point(95, 41)
        Me.LabelErrorsMi.Name = "LabelErrorsMi"
        Me.LabelErrorsMi.Size = New System.Drawing.Size(57, 22)
        Me.LabelErrorsMi.TabIndex = 3
        Me.LabelErrorsMi.Text = "Errors"
        Me.LabelErrorsMi.Visible = False
        '
        'Panel12
        '
        Me.Panel12.AutoScroll = True
        Me.Panel12.BackColor = System.Drawing.Color.Orange
        Me.Panel12.Controls.Add(Me.LabelGPAMa)
        Me.Panel12.Controls.Add(Me.LabelSNM)
        Me.Panel12.Controls.Add(Me.Label55)
        Me.Panel12.Controls.Add(Me.LabelErrorsM)
        Me.Panel12.Location = New System.Drawing.Point(560, 3)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(497, 315)
        Me.Panel12.TabIndex = 1
        '
        'LabelGPAMa
        '
        Me.LabelGPAMa.AutoSize = True
        Me.LabelGPAMa.ForeColor = System.Drawing.Color.White
        Me.LabelGPAMa.Location = New System.Drawing.Point(387, 270)
        Me.LabelGPAMa.Name = "LabelGPAMa"
        Me.LabelGPAMa.Size = New System.Drawing.Size(52, 22)
        Me.LabelGPAMa.TabIndex = 4
        Me.LabelGPAMa.Text = "GPA: "
        Me.LabelGPAMa.Visible = False
        '
        'LabelSNM
        '
        Me.LabelSNM.AutoSize = True
        Me.LabelSNM.Location = New System.Drawing.Point(58, 35)
        Me.LabelSNM.Name = "LabelSNM"
        Me.LabelSNM.Size = New System.Drawing.Size(38, 22)
        Me.LabelSNM.TabIndex = 3
        Me.LabelSNM.Text = "S/N"
        Me.LabelSNM.Visible = False
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(201, 10)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(95, 22)
        Me.Label55.TabIndex = 1
        Me.Label55.Text = "Major Core"
        '
        'LabelErrorsM
        '
        Me.LabelErrorsM.AutoSize = True
        Me.LabelErrorsM.Location = New System.Drawing.Point(121, 35)
        Me.LabelErrorsM.Name = "LabelErrorsM"
        Me.LabelErrorsM.Size = New System.Drawing.Size(57, 22)
        Me.LabelErrorsM.TabIndex = 3
        Me.LabelErrorsM.Text = "Errors"
        Me.LabelErrorsM.Visible = False
        '
        'Panel11
        '
        Me.Panel11.AutoScroll = True
        Me.Panel11.BackColor = System.Drawing.Color.Orange
        Me.Panel11.Controls.Add(Me.LabelGPAUni)
        Me.Panel11.Controls.Add(Me.LabelSN)
        Me.Panel11.Controls.Add(Me.LabelErrors)
        Me.Panel11.Controls.Add(Me.Label58)
        Me.Panel11.Controls.Add(Me.Label54)
        Me.Panel11.Location = New System.Drawing.Point(3, 3)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(533, 315)
        Me.Panel11.TabIndex = 0
        '
        'LabelGPAUni
        '
        Me.LabelGPAUni.AutoSize = True
        Me.LabelGPAUni.ForeColor = System.Drawing.Color.White
        Me.LabelGPAUni.Location = New System.Drawing.Point(425, 266)
        Me.LabelGPAUni.Name = "LabelGPAUni"
        Me.LabelGPAUni.Size = New System.Drawing.Size(52, 22)
        Me.LabelGPAUni.TabIndex = 4
        Me.LabelGPAUni.Text = "GPA: "
        Me.LabelGPAUni.Visible = False
        '
        'LabelSN
        '
        Me.LabelSN.AutoSize = True
        Me.LabelSN.Location = New System.Drawing.Point(32, 35)
        Me.LabelSN.Name = "LabelSN"
        Me.LabelSN.Size = New System.Drawing.Size(38, 22)
        Me.LabelSN.TabIndex = 3
        Me.LabelSN.Text = "S/N"
        Me.LabelSN.Visible = False
        '
        'LabelErrors
        '
        Me.LabelErrors.AutoSize = True
        Me.LabelErrors.Location = New System.Drawing.Point(95, 35)
        Me.LabelErrors.Name = "LabelErrors"
        Me.LabelErrors.Size = New System.Drawing.Size(57, 22)
        Me.LabelErrors.TabIndex = 3
        Me.LabelErrors.Text = "Errors"
        Me.LabelErrors.Visible = False
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(80, 45)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(0, 22)
        Me.Label58.TabIndex = 2
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(168, 10)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(197, 22)
        Me.Label54.TabIndex = 1
        Me.Label54.Text = "University Requirements"
        '
        'Panel1
        '
        Me.Panel1.BackgroundImage = CType(resources.GetObject("Panel1.BackgroundImage"), System.Drawing.Image)
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Panel1.Location = New System.Drawing.Point(3, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(157, 84)
        Me.Panel1.TabIndex = 1
        '
        'LabelTitle
        '
        Me.LabelTitle.AutoSize = True
        Me.LabelTitle.Font = New System.Drawing.Font("Palatino Linotype", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelTitle.ForeColor = System.Drawing.Color.DarkBlue
        Me.LabelTitle.Location = New System.Drawing.Point(88, 8)
        Me.LabelTitle.Name = "LabelTitle"
        Me.LabelTitle.Size = New System.Drawing.Size(526, 32)
        Me.LabelTitle.TabIndex = 2
        Me.LabelTitle.Text = "Department of Mathematics/Computer Science"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.LabelMath)
        Me.Panel2.Controls.Add(Me.LabelTitle)
        Me.Panel2.Location = New System.Drawing.Point(165, 20)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(901, 75)
        Me.Panel2.TabIndex = 2
        '
        'LabelMath
        '
        Me.LabelMath.AutoSize = True
        Me.LabelMath.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMath.ForeColor = System.Drawing.Color.DarkBlue
        Me.LabelMath.Location = New System.Drawing.Point(190, 40)
        Me.LabelMath.Name = "LabelMath"
        Me.LabelMath.Size = New System.Drawing.Size(320, 26)
        Me.LabelMath.TabIndex = 3
        Me.LabelMath.Text = "CS Major (Mathematics Emphasis)"
        '
        'LabelTotalCredits
        '
        Me.LabelTotalCredits.AutoSize = True
        Me.LabelTotalCredits.Font = New System.Drawing.Font("Palatino Linotype", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelTotalCredits.Location = New System.Drawing.Point(851, 36)
        Me.LabelTotalCredits.Name = "LabelTotalCredits"
        Me.LabelTotalCredits.Size = New System.Drawing.Size(148, 28)
        Me.LabelTotalCredits.TabIndex = 3
        Me.LabelTotalCredits.Text = "Total Credits: "
        Me.LabelTotalCredits.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1078, 865)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.TabControl1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Form1"
        Me.Text = "Mathematics Emphasis"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.Panel15.ResumeLayout(False)
        Me.Panel15.PerformLayout()
        Me.Panel14.ResumeLayout(False)
        Me.Panel14.PerformLayout()
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout()
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents Panel1 As Panel
    Friend WithEvents LabelTitle As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents LabelMath As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents ComboBoxLG13 As ComboBox
    Friend WithEvents ComboBoxLG12 As ComboBox
    Friend WithEvents ComboBoxLG11 As ComboBox
    Friend WithEvents ComboBoxLG10 As ComboBox
    Friend WithEvents ComboBoxLG9 As ComboBox
    Friend WithEvents ComboBoxLG8 As ComboBox
    Friend WithEvents ComboBoxLG7 As ComboBox
    Friend WithEvents ComboBoxLG6 As ComboBox
    Friend WithEvents ComboBoxLG5 As ComboBox
    Friend WithEvents ComboBoxLG4 As ComboBox
    Friend WithEvents ComboBoxLG3 As ComboBox
    Friend WithEvents ComboBoxLG2 As ComboBox
    Friend WithEvents ComboBoxLG1 As ComboBox
    Friend WithEvents TextBoxQP13 As TextBox
    Friend WithEvents TextBoxTQP13 As TextBox
    Friend WithEvents TextBoxCredit13 As TextBox
    Friend WithEvents TextBoxQP12 As TextBox
    Friend WithEvents TextBoxTQP12 As TextBox
    Friend WithEvents TextBoxCredit12 As TextBox
    Friend WithEvents TextBoxQP11 As TextBox
    Friend WithEvents TextBoxTQP11 As TextBox
    Friend WithEvents TextBoxCredit11 As TextBox
    Friend WithEvents TextBoxQP10 As TextBox
    Friend WithEvents TextBoxTQP10 As TextBox
    Friend WithEvents TextBoxCredit10 As TextBox
    Friend WithEvents TextBoxQP9 As TextBox
    Friend WithEvents TextBoxTQP9 As TextBox
    Friend WithEvents TextBoxCredit9 As TextBox
    Friend WithEvents TextBoxQP8 As TextBox
    Friend WithEvents TextBoxTQP8 As TextBox
    Friend WithEvents TextBoxQP7 As TextBox
    Friend WithEvents TextBoxCredit8 As TextBox
    Friend WithEvents TextBoxTQP7 As TextBox
    Friend WithEvents TextBoxQP6 As TextBox
    Friend WithEvents TextBoxCredit7 As TextBox
    Friend WithEvents TextBoxQP5 As TextBox
    Friend WithEvents TextBoxTQP6 As TextBox
    Friend WithEvents TextBoxTQP5 As TextBox
    Friend WithEvents TextBoxQP4 As TextBox
    Friend WithEvents TextBoxCredit6 As TextBox
    Friend WithEvents TextBoxTQP4 As TextBox
    Friend WithEvents TextBoxQP3 As TextBox
    Friend WithEvents TextBoxCredit5 As TextBox
    Friend WithEvents TextBoxTQP3 As TextBox
    Friend WithEvents TextBoxQP2 As TextBox
    Friend WithEvents TextBoxCredit4 As TextBox
    Friend WithEvents TextBoxTQP2 As TextBox
    Friend WithEvents TextBoxQP1 As TextBox
    Friend WithEvents TextBoxCredit3 As TextBox
    Friend WithEvents TextBoxTQP1 As TextBox
    Friend WithEvents TextBoxCredit2 As TextBox
    Friend WithEvents TextBoxCredit1 As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents ButtonResetUni As Button
    Friend WithEvents LabelGPA As Label
    Friend WithEvents CheckBox5 As CheckBox
    Friend WithEvents CheckBox7 As CheckBox
    Friend WithEvents CheckBox9 As CheckBox
    Friend WithEvents CheckBox11 As CheckBox
    Friend WithEvents CheckBox12 As CheckBox
    Friend WithEvents CheckBox13 As CheckBox
    Friend WithEvents CheckBox10 As CheckBox
    Friend WithEvents CheckBox8 As CheckBox
    Friend WithEvents CheckBox6 As CheckBox
    Friend WithEvents CheckBox4 As CheckBox
    Friend WithEvents CheckBox3 As CheckBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents CheckBox14 As CheckBox
    Friend WithEvents CheckBox15 As CheckBox
    Friend WithEvents CheckBox16 As CheckBox
    Friend WithEvents CheckBox17 As CheckBox
    Friend WithEvents CheckBox18 As CheckBox
    Friend WithEvents CheckBox20 As CheckBox
    Friend WithEvents CheckBox21 As CheckBox
    Friend WithEvents CheckBox22 As CheckBox
    Friend WithEvents CheckBox23 As CheckBox
    Friend WithEvents CheckBox24 As CheckBox
    Friend WithEvents CheckBox25 As CheckBox
    Friend WithEvents CheckBox19 As CheckBox
    Friend WithEvents ComboBoxLG25 As ComboBox
    Friend WithEvents ComboBoxLG24 As ComboBox
    Friend WithEvents ComboBoxLG23 As ComboBox
    Friend WithEvents ComboBoxLG22 As ComboBox
    Friend WithEvents ComboBoxLG21 As ComboBox
    Friend WithEvents ComboBoxLG20 As ComboBox
    Friend WithEvents ComboBoxLG19 As ComboBox
    Friend WithEvents ComboBoxLG18 As ComboBox
    Friend WithEvents ComboBoxLG17 As ComboBox
    Friend WithEvents ComboBoxLG16 As ComboBox
    Friend WithEvents ComboBoxLG15 As ComboBox
    Friend WithEvents ComboBoxLG14 As ComboBox
    Friend WithEvents TextBoxQP25 As TextBox
    Friend WithEvents TextBoxTQP25 As TextBox
    Friend WithEvents TextBoxCredit25 As TextBox
    Friend WithEvents TextBoxQP24 As TextBox
    Friend WithEvents TextBoxTQP24 As TextBox
    Friend WithEvents TextBoxCredit24 As TextBox
    Friend WithEvents TextBoxQP23 As TextBox
    Friend WithEvents TextBoxTQP23 As TextBox
    Friend WithEvents TextBoxCredit23 As TextBox
    Friend WithEvents TextBoxQP22 As TextBox
    Friend WithEvents TextBoxTQP22 As TextBox
    Friend WithEvents TextBoxCredit22 As TextBox
    Friend WithEvents TextBoxQP21 As TextBox
    Friend WithEvents TextBoxTQP21 As TextBox
    Friend WithEvents TextBoxQP20 As TextBox
    Friend WithEvents TextBoxCredit21 As TextBox
    Friend WithEvents TextBoxTQP20 As TextBox
    Friend WithEvents TextBoxQP19 As TextBox
    Friend WithEvents TextBoxCredit20 As TextBox
    Friend WithEvents TextBoxQP18 As TextBox
    Friend WithEvents TextBoxTQP19 As TextBox
    Friend WithEvents TextBoxTQP18 As TextBox
    Friend WithEvents TextBoxQP17 As TextBox
    Friend WithEvents TextBoxCredit19 As TextBox
    Friend WithEvents TextBoxTQP17 As TextBox
    Friend WithEvents TextBoxQP16 As TextBox
    Friend WithEvents TextBoxCredit18 As TextBox
    Friend WithEvents TextBoxTQP16 As TextBox
    Friend WithEvents TextBoxQP15 As TextBox
    Friend WithEvents TextBoxCredit17 As TextBox
    Friend WithEvents TextBoxTQP15 As TextBox
    Friend WithEvents TextBoxQP14 As TextBox
    Friend WithEvents TextBoxCredit16 As TextBox
    Friend WithEvents TextBoxTQP14 As TextBox
    Friend WithEvents TextBoxCredit15 As TextBox
    Friend WithEvents TextBoxCredit14 As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents ButtonResetMajor As Button
    Friend WithEvents LabelGPAMajor As Label
    Friend WithEvents Panel8 As Panel
    Friend WithEvents CheckBox26 As CheckBox
    Friend WithEvents CheckBox27 As CheckBox
    Friend WithEvents CheckBox28 As CheckBox
    Friend WithEvents CheckBox29 As CheckBox
    Friend WithEvents CheckBox30 As CheckBox
    Friend WithEvents ComboBoxLG30 As ComboBox
    Friend WithEvents ComboBoxLG29 As ComboBox
    Friend WithEvents ComboBoxLG28 As ComboBox
    Friend WithEvents ComboBoxLG27 As ComboBox
    Friend WithEvents ComboBoxLG26 As ComboBox
    Friend WithEvents TextBoxQP30 As TextBox
    Friend WithEvents TextBoxTQP30 As TextBox
    Friend WithEvents TextBoxQP29 As TextBox
    Friend WithEvents TextBoxTQP29 As TextBox
    Friend WithEvents TextBoxQP28 As TextBox
    Friend WithEvents TextBoxCredit30 As TextBox
    Friend WithEvents TextBoxTQP28 As TextBox
    Friend WithEvents TextBoxQP27 As TextBox
    Friend WithEvents TextBoxCredit29 As TextBox
    Friend WithEvents TextBoxTQP27 As TextBox
    Friend WithEvents TextBoxQP26 As TextBox
    Friend WithEvents TextBoxCredit28 As TextBox
    Friend WithEvents TextBoxTQP26 As TextBox
    Friend WithEvents TextBoxCredit27 As TextBox
    Friend WithEvents TextBoxCredit26 As TextBox
    Friend WithEvents Label38 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents Label51 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents Label53 As Label
    Friend WithEvents Panel7 As Panel
    Friend WithEvents ButtonReseTMinor As Button
    Friend WithEvents LabelGPAMinor As Label
    Friend WithEvents Panel10 As Panel
    Friend WithEvents CheckBox31 As CheckBox
    Friend WithEvents CheckBox32 As CheckBox
    Friend WithEvents CheckBox33 As CheckBox
    Friend WithEvents CheckBox34 As CheckBox
    Friend WithEvents CheckBox35 As CheckBox
    Friend WithEvents CheckBox36 As CheckBox
    Friend WithEvents CheckBox37 As CheckBox
    Friend WithEvents CheckBox38 As CheckBox
    Friend WithEvents CheckBox39 As CheckBox
    Friend WithEvents ComboBoxLG39 As ComboBox
    Friend WithEvents ComboBoxLG38 As ComboBox
    Friend WithEvents ComboBoxLG37 As ComboBox
    Friend WithEvents ComboBoxLG36 As ComboBox
    Friend WithEvents ComboBoxLG35 As ComboBox
    Friend WithEvents ComboBoxLG34 As ComboBox
    Friend WithEvents ComboBoxLG33 As ComboBox
    Friend WithEvents ComboBoxLG32 As ComboBox
    Friend WithEvents ComboBoxLG31 As ComboBox
    Friend WithEvents TextBoxQP39 As TextBox
    Friend WithEvents TextBoxTQP39 As TextBox
    Friend WithEvents TextBoxCredit39 As TextBox
    Friend WithEvents TextBoxQP38 As TextBox
    Friend WithEvents TextBoxTQP38 As TextBox
    Friend WithEvents TextBoxQP37 As TextBox
    Friend WithEvents TextBoxCredit38 As TextBox
    Friend WithEvents TextBoxTQP37 As TextBox
    Friend WithEvents TextBoxQP36 As TextBox
    Friend WithEvents TextBoxCredit37 As TextBox
    Friend WithEvents TextBoxQP35 As TextBox
    Friend WithEvents TextBoxTQP36 As TextBox
    Friend WithEvents TextBoxTQP35 As TextBox
    Friend WithEvents TextBoxQP34 As TextBox
    Friend WithEvents TextBoxCredit36 As TextBox
    Friend WithEvents TextBoxTQP34 As TextBox
    Friend WithEvents TextBoxQP33 As TextBox
    Friend WithEvents TextBoxCredit35 As TextBox
    Friend WithEvents TextBoxTQP33 As TextBox
    Friend WithEvents TextBoxQP32 As TextBox
    Friend WithEvents TextBoxCredit34 As TextBox
    Friend WithEvents TextBoxTQP32 As TextBox
    Friend WithEvents TextBoxQP31 As TextBox
    Friend WithEvents TextBoxCredit33 As TextBox
    Friend WithEvents TextBoxTQP31 As TextBox
    Friend WithEvents TextBoxCredit32 As TextBox
    Friend WithEvents TextBoxCredit31 As TextBox
    Friend WithEvents Label59 As Label
    Friend WithEvents Label60 As Label
    Friend WithEvents Label61 As Label
    Friend WithEvents Label62 As Label
    Friend WithEvents Label63 As Label
    Friend WithEvents Panel9 As Panel
    Friend WithEvents ResetElectives As Button
    Friend WithEvents LabelGPAElectives As Label
    Friend WithEvents TextBoxCourseID9 As TextBox
    Friend WithEvents TextBoxCourseID8 As TextBox
    Friend WithEvents TextBoxCourseID7 As TextBox
    Friend WithEvents TextBoxCourseID6 As TextBox
    Friend WithEvents TextBoxCourseID5 As TextBox
    Friend WithEvents TextBoxCourseID4 As TextBox
    Friend WithEvents TextBoxCourseID3 As TextBox
    Friend WithEvents TextBoxCourseID2 As TextBox
    Friend WithEvents TextBoxCourseID1 As TextBox
    Friend WithEvents TextBoxCourseTitle39 As TextBox
    Friend WithEvents TextBoxCourseTitle38 As TextBox
    Friend WithEvents TextBoxCourseTitle37 As TextBox
    Friend WithEvents TextBoxCourseTitle36 As TextBox
    Friend WithEvents TextBoxCourseTitle35 As TextBox
    Friend WithEvents TextBoxCourseTitle34 As TextBox
    Friend WithEvents TextBoxCourseTitle33 As TextBox
    Friend WithEvents TextBoxCourseTitle32 As TextBox
    Friend WithEvents TextBoxCourseTitle31 As TextBox
    Friend WithEvents Label39 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents TextBoxCourseTitle13 As TextBox
    Friend WithEvents TextBoxCourseTitle12 As TextBox
    Friend WithEvents TextBoxCourseTitle11 As TextBox
    Friend WithEvents TextBoxCourseTitle10 As TextBox
    Friend WithEvents TextBoxCourseTitle9 As TextBox
    Friend WithEvents TextBoxCourseTitle8 As TextBox
    Friend WithEvents TextBoxCourseTitle7 As TextBox
    Friend WithEvents TextBoxCourseTitle6 As TextBox
    Friend WithEvents TextBoxCourseTitle5 As TextBox
    Friend WithEvents TextBoxCourseTitle4 As TextBox
    Friend WithEvents TextBoxCourseTitle3 As TextBox
    Friend WithEvents TextBoxCourseTitle2 As TextBox
    Friend WithEvents TextBoxCourseTitle1 As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents TextBoxCoureTitle25 As TextBox
    Friend WithEvents TextBoxCoureTitle24 As TextBox
    Friend WithEvents TextBoxCoureTitle23 As TextBox
    Friend WithEvents TextBoxCoureTitle22 As TextBox
    Friend WithEvents TextBoxCoureTitle21 As TextBox
    Friend WithEvents TextBoxCoureTitle20 As TextBox
    Friend WithEvents TextBoxCoureTitle19 As TextBox
    Friend WithEvents TextBoxCoureTitle18 As TextBox
    Friend WithEvents TextBoxCoureTitle17 As TextBox
    Friend WithEvents TextBoxCoureTitle16 As TextBox
    Friend WithEvents TextBoxCoureTitle15 As TextBox
    Friend WithEvents TextBoxCoureTitle14 As TextBox
    Friend WithEvents Label43 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents TextBoxCoureTitle30 As TextBox
    Friend WithEvents TextBoxCoureTitle29 As TextBox
    Friend WithEvents TextBoxCoureTitle28 As TextBox
    Friend WithEvents TextBoxCoureTitle27 As TextBox
    Friend WithEvents TextBoxCoureTitle26 As TextBox
    Friend WithEvents Label46 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Panel14 As Panel
    Friend WithEvents Label57 As Label
    Friend WithEvents Panel13 As Panel
    Friend WithEvents Label56 As Label
    Friend WithEvents Panel12 As Panel
    Friend WithEvents Label55 As Label
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Label54 As Label
    Friend WithEvents Panel15 As Panel
    Friend WithEvents LabelCGPA As Label
    Friend WithEvents Label58 As Label
    Friend WithEvents LabelErrors As Label
    Friend WithEvents LabelSN As Label
    Friend WithEvents LabelSNM As Label
    Friend WithEvents LabelErrorsM As Label
    Friend WithEvents LabelGPAMa As Label
    Friend WithEvents LabelGPAUni As Label
    Friend WithEvents LabelGPAGen As Label
    Friend WithEvents LabelSNGen As Label
    Friend WithEvents LabelErrorsGen As Label
    Friend WithEvents LabelGPAMi As Label
    Friend WithEvents LabelSNMi As Label
    Friend WithEvents LabelErrorsMi As Label
    Friend WithEvents CheckBoxLangII As CheckBox
    Friend WithEvents CheckBoxLangI As CheckBox
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label65 As Label
    Friend WithEvents Label64 As Label
    Friend WithEvents LabelTotalCredits As Label
End Class

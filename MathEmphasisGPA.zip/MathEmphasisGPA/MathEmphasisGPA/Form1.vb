﻿#RonaldLashley
#LincolnUniversity(PA)
#GraduatingClassofMay2017
#ComputerScienceMajor


Public Class Form1
    Dim totalCredit As Double
    Dim totalTQP As Double
    Dim sumCreditsElective, sumTQPElective As Double
    Dim sumCreditsMinor, sumTQPMinor As Double
    Dim sumCreditsMajor, sumTQPMajor As Double
    Dim sumCredits, sumTQP As Double
    Dim Uninames(12) As String
    Dim Majornames(11) As String
    Dim Minornames(4) As String
    Dim Electivenames(9) As String
    Dim counter, counter1, counter2, counter3
    Private Function QP(ByVal L As String) As Double
        If L = "A" Then
            QP = 4.0
        ElseIf L = "A-" Then
            QP = 3.7
        ElseIf L = "B+" Then
            QP = 3.3
        ElseIf L = "B" Then
            QP = 3.0
        ElseIf L = "B-" Then
            QP = 2.7
        ElseIf L = "C+" Then
            QP = 2.3
        ElseIf L = "C" Then
            QP = 2.0
        ElseIf L = "C-" Then
            QP = 1.7
        ElseIf L = "D" Then
            QP = 1.0
        ElseIf L = "F" Then
            QP = 0.0
        Else
            QP = -1
        End If
        Return QP
    End Function
    Private Sub calculateGPAElectives()
        counter3 = 0
        sumCreditsElective = 0
        sumTQPElective = 0
        Dim GPA = 0.00
        Dim CR31, CR32, CR33, CR34, CR35, CR36, CR37, CR38, CR39 As Double
        Dim TQP31, TQP32, TQP33, TQP34, TQP35, TQP36, TQP37, TQP38, TQP39 As Double
        TextBoxQP31.Text = QP(ComboBoxLG31.SelectedItem)
        TextBoxQP32.Text = QP(ComboBoxLG32.SelectedItem)
        TextBoxQP33.Text = QP(ComboBoxLG33.SelectedItem)
        TextBoxQP34.Text = QP(ComboBoxLG34.SelectedItem)
        TextBoxQP35.Text = QP(ComboBoxLG35.SelectedItem)
        TextBoxQP36.Text = QP(ComboBoxLG36.SelectedItem)
        TextBoxQP37.Text = QP(ComboBoxLG37.SelectedItem)
        TextBoxQP38.Text = QP(ComboBoxLG38.SelectedItem)
        TextBoxQP39.Text = QP(ComboBoxLG39.SelectedItem)
        If IsNumeric(TextBoxCredit31.Text) Then
            CR31 = CDbl(TextBoxCredit31.Text)
            sumCreditsElective = sumCreditsElective + CR31
        Else
            CR31 = 0
        End If
        If IsNumeric(TextBoxCredit32.Text) Then
            CR32 = CDbl(TextBoxCredit32.Text)
            sumCreditsElective = sumCreditsElective + CR32
        Else
            CR32 = 0
        End If
        If IsNumeric(TextBoxCredit33.Text) Then
            CR33 = CDbl(TextBoxCredit33.Text)
            sumCreditsElective = sumCreditsElective + CR33
        Else
            CR33 = 0
        End If
        If IsNumeric(TextBoxCredit34.Text) Then
            CR34 = CDbl(TextBoxCredit34.Text)
            sumCreditsElective = sumCreditsElective + CR34
        Else
            CR34 = 0
        End If
        If IsNumeric(TextBoxCredit35.Text) Then
            CR35 = CDbl(TextBoxCredit35.Text)
            sumCreditsElective = sumCreditsElective + CR35
        Else
            CR35 = 0
        End If
        If IsNumeric(TextBoxCredit36.Text) Then
            CR36 = CDbl(TextBoxCredit36.Text)
            sumCreditsElective = sumCreditsElective + CR36
        Else
            CR36 = 0
        End If
        If IsNumeric(TextBoxCredit37.Text) Then
            CR37 = CDbl(TextBoxCredit37.Text)
            sumCreditsElective = sumCreditsElective + CR37
        Else
            CR37 = 0
        End If
        If IsNumeric(TextBoxCredit38.Text) Then
            CR38 = CDbl(TextBoxCredit38.Text)
            sumCreditsElective = sumCreditsElective + CR38
        Else
            CR38 = 0
        End If
        If IsNumeric(TextBoxCredit39.Text) Then
            CR39 = CDbl(TextBoxCredit39.Text)
            sumCreditsElective = sumCreditsElective + CR39
        Else
            CR39 = 0
        End If

        If CDbl(TextBoxQP31.Text) <> -1 Then
            TQP31 = CDbl(TextBoxQP31.Text) * CR31
            sumTQPElective = sumTQPElective + TQP31
            TextBoxTQP31.Text = Str(TQP31)
            CheckBox31.Checked = True
            CheckBox31.Text = "True"
        Else
            Electivenames(counter3) = TextBoxCourseTitle31.Text
            counter3 += 1
        End If
        If CDbl(TextBoxQP32.Text) <> -1 Then
            TQP32 = CDbl(TextBoxQP32.Text) * CR32
            sumTQPElective = sumTQPElective + TQP32
            TextBoxTQP32.Text = Str(TQP32)
            CheckBox32.Checked = True
            CheckBox32.Text = "True"
        Else
            Electivenames(counter3) = TextBoxCourseTitle32.Text
            counter3 += 1
        End If
        If CDbl(TextBoxQP33.Text) <> -1 Then
            TQP33 = CDbl(TextBoxQP33.Text) * CR33
            sumTQPElective = sumTQPElective + TQP33
            TextBoxTQP33.Text = Str(TQP33)
            CheckBox33.Checked = True
            CheckBox33.Text = "True"
        Else
            Electivenames(counter3) = TextBoxCourseTitle33.Text
            counter3 += 1
        End If
        If CDbl(TextBoxQP34.Text) <> -1 Then
            TQP34 = CDbl(TextBoxQP34.Text) * CR34
            sumTQPElective = sumTQPElective + TQP34
            TextBoxTQP34.Text = Str(TQP34)
            CheckBox34.Checked = True
            CheckBox34.Text = "True"
        Else
            Electivenames(counter3) = TextBoxCourseTitle34.Text
            counter3 += 1
        End If
        If CDbl(TextBoxQP35.Text) <> -1 Then
            TQP35 = CDbl(TextBoxQP35.Text) * CR35
            sumTQPElective = sumTQPElective + TQP35
            TextBoxTQP35.Text = Str(TQP35)
            CheckBox35.Checked = True
            CheckBox35.Text = "True"
        Else
            Electivenames(counter3) = TextBoxCourseTitle35.Text
            counter3 += 1
        End If
        If CDbl(TextBoxQP36.Text) <> -1 Then
            TQP36 = CDbl(TextBoxQP36.Text) * CR36
            sumTQPElective = sumTQPElective + TQP36
            TextBoxTQP36.Text = Str(TQP36)
            CheckBox36.Checked = True
            CheckBox36.Text = "True"
        Else
            Electivenames(counter3) = TextBoxCourseTitle36.Text
            counter3 += 1
        End If
        If CDbl(TextBoxQP37.Text) <> -1 Then
            TQP37 = CDbl(TextBoxQP37.Text) * CR37
            sumTQPElective = sumTQPElective + TQP37
            TextBoxTQP37.Text = Str(TQP37)
            CheckBox37.Checked = True
            CheckBox37.Text = "True"
        Else
            Electivenames(counter3) = TextBoxCourseTitle37.Text
            counter3 += 1
        End If
        If CDbl(TextBoxQP38.Text) <> -1 Then
            TQP38 = CDbl(TextBoxQP38.Text) * CR38
            sumTQPElective = sumTQPElective + TQP38
            TextBoxTQP38.Text = Str(TQP38)
            CheckBox38.Checked = True
            CheckBox38.Text = "True"
        Else
            Electivenames(counter3) = TextBoxCourseTitle38.Text
            counter3 += 1
        End If
        If CDbl(TextBoxQP39.Text) <> -1 Then
            TQP39 = CDbl(TextBoxQP39.Text) * CR39
            sumTQPElective = sumTQPElective + TQP39
            TextBoxTQP39.Text = Str(TQP39)
            CheckBox39.Checked = True
            CheckBox39.Text = "True"
        Else
            Electivenames(counter3) = TextBoxCourseTitle39.Text
            counter3 += 1
        End If
        GPA = sumTQPElective / sumCreditsElective
        LabelGPAElectives.Text = "GPA = [ " & String.Format("{0:F3}", GPA) & " ]"
    End Sub
    Private Sub calculateGPAMinor()
        counter2 = 0
        sumCreditsMinor = 0
        sumTQPMinor = 0
        Dim GPA = 0.00
        Dim CR26, CR27, CR28, CR29, CR30 As Double
        Dim TQP26, TQP27, TQP28, TQP29, TQP30 As Double
        TextBoxQP26.Text = QP(ComboBoxLG26.SelectedItem)
        TextBoxQP27.Text = QP(ComboBoxLG27.SelectedItem)
        TextBoxQP28.Text = QP(ComboBoxLG28.SelectedItem)
        TextBoxQP29.Text = QP(ComboBoxLG29.SelectedItem)
        TextBoxQP30.Text = QP(ComboBoxLG30.SelectedItem)
        If IsNumeric(TextBoxCredit26.Text) Then
            CR26 = CDbl(TextBoxCredit26.Text)
            sumCreditsMinor = sumCreditsMinor + CR26
        Else
            CR26 = 0
        End If
        If IsNumeric(TextBoxCredit27.Text) Then
            CR27 = CDbl(TextBoxCredit27.Text)
            sumCreditsMinor = sumCreditsMinor + CR27
        Else
            CR27 = 0
        End If
        If IsNumeric(TextBoxCredit28.Text) Then
            CR28 = CDbl(TextBoxCredit28.Text)
            sumCreditsMinor = sumCreditsMinor + CR28
        Else
            CR28 = 0
        End If
        If IsNumeric(TextBoxCredit29.Text) Then
            CR29 = CDbl(TextBoxCredit29.Text)
            sumCreditsMinor = sumCreditsMinor + CR29
        Else
            CR29 = 0
        End If
        If IsNumeric(TextBoxCredit30.Text) Then
            CR30 = CDbl(TextBoxCredit30.Text)
            sumCreditsMinor = sumCreditsMinor + CR30
        Else
            CR30 = 0
        End If
        If CDbl(TextBoxQP26.Text) <> -1 Then
            TQP26 = CDbl(TextBoxQP26.Text) * CR26
            sumTQPMinor = sumTQPMinor + TQP26
            TextBoxTQP26.Text = Str(TQP26)
            CheckBox26.Checked = True
            CheckBox26.Text = "True"
        Else
            Minornames(counter2) = TextBoxCoureTitle26.Text
            counter2 += 1
        End If

        If CDbl(TextBoxQP27.Text) <> -1 Then
            TQP27 = CDbl(TextBoxQP27.Text) * CR27
            sumTQPMinor = sumTQPMinor + TQP27
            TextBoxTQP27.Text = Str(TQP27)
            CheckBox27.Checked = True
            CheckBox27.Text = "True"
        Else
            Minornames(counter2) = TextBoxCoureTitle27.Text
            counter2 += 1
        End If

        If CDbl(TextBoxQP28.Text) <> -1 Then
            TQP28 = CDbl(TextBoxQP28.Text) * CR28
            sumTQPMinor = sumTQPMinor + TQP28
            TextBoxTQP28.Text = Str(TQP28)
            CheckBox28.Checked = True
            CheckBox28.Text = "True"
        Else
            Minornames(counter2) = TextBoxCoureTitle28.Text
            counter2 += 1
        End If

        If CDbl(TextBoxQP29.Text) <> -1 Then
            TQP29 = CDbl(TextBoxQP29.Text) * CR29
            sumTQPMinor = sumTQPMinor + TQP29
            TextBoxTQP29.Text = Str(TQP29)
            CheckBox29.Checked = True
            CheckBox29.Text = "True"
        Else
            Minornames(counter2) = TextBoxCoureTitle29.Text
            counter2 += 1
        End If

        If CDbl(TextBoxQP30.Text) <> -1 Then
            TQP30 = CDbl(TextBoxQP30.Text) * CR30
            sumTQPMinor = sumTQPMinor + TQP30
            TextBoxTQP30.Text = Str(TQP30)
            CheckBox30.Checked = True
            CheckBox30.Text = "True"
        Else
            Minornames(counter2) = TextBoxCoureTitle30.Text
            counter2 += 1
        End If
        GPA = sumTQPMinor / sumCreditsMinor
        LabelGPAMinor.Text = "GPA = [ " & String.Format("{0:F3}", GPA) & " ]"
    End Sub
    Private Sub calculateGPAMajor()
        counter1 = 0
        sumCreditsMajor = 0
        sumTQPMajor = 0
        Dim GPA = 0.00
        Dim CR14, CR15, CR16, CR17, CR18, CR19, CR20, CR21, CR22, CR23, CR24, CR25 As Double
        Dim TQP14, TQP15, TQP16, TQP17, TQP18, TQP19, TQP20, TQP21, TQP22, TQP23, TQP24, TQP25 As Double
        TextBoxQP14.Text = QP(ComboBoxLG14.SelectedItem)
        TextBoxQP15.Text = QP(ComboBoxLG15.SelectedItem)
        TextBoxQP16.Text = QP(ComboBoxLG16.SelectedItem)
        TextBoxQP17.Text = QP(ComboBoxLG17.SelectedItem)
        TextBoxQP18.Text = QP(ComboBoxLG18.SelectedItem)
        TextBoxQP19.Text = QP(ComboBoxLG19.SelectedItem)
        TextBoxQP20.Text = QP(ComboBoxLG20.SelectedItem)
        TextBoxQP21.Text = QP(ComboBoxLG21.SelectedItem)
        TextBoxQP22.Text = QP(ComboBoxLG22.SelectedItem)
        TextBoxQP23.Text = QP(ComboBoxLG23.SelectedItem)
        TextBoxQP24.Text = QP(ComboBoxLG24.SelectedItem)
        TextBoxQP25.Text = QP(ComboBoxLG25.SelectedItem)
        If IsNumeric(TextBoxCredit14.Text) Then
            CR14 = CDbl(TextBoxCredit14.Text)
            sumCreditsMajor = sumCreditsMajor + CR14
        Else
            CR14 = 0
        End If
        If IsNumeric(TextBoxCredit15.Text) Then
            CR15 = CDbl(TextBoxCredit15.Text)
            sumCreditsMajor = sumCreditsMajor + CR15
        Else
            CR15 = 0
        End If
        If IsNumeric(TextBoxCredit16.Text) Then
            CR16 = CDbl(TextBoxCredit16.Text)
            sumCreditsMajor = sumCreditsMajor + CR16
        Else
            CR16 = 0
        End If
        If IsNumeric(TextBoxCredit17.Text) Then
            CR17 = CDbl(TextBoxCredit17.Text)
            sumCreditsMajor = sumCreditsMajor + CR17
        Else
            CR17 = 0
        End If
        If IsNumeric(TextBoxCredit18.Text) Then
            CR18 = CDbl(TextBoxCredit18.Text)
            sumCreditsMajor = sumCreditsMajor + CR18
        Else
            CR18 = 0
        End If
        If IsNumeric(TextBoxCredit19.Text) Then
            CR19 = CDbl(TextBoxCredit19.Text)
            sumCreditsMajor = sumCreditsMajor + CR19
        Else
            CR19 = 0
        End If
        If IsNumeric(TextBoxCredit20.Text) Then
            CR20 = CDbl(TextBoxCredit20.Text)
            sumCreditsMajor = sumCreditsMajor + CR20
        Else
            CR20 = 0
        End If
        If IsNumeric(TextBoxCredit21.Text) Then
            CR21 = CDbl(TextBoxCredit21.Text)
            sumCreditsMajor = sumCreditsMajor + CR21
        Else
            CR21 = 0
        End If
        If IsNumeric(TextBoxCredit22.Text) Then
            CR22 = CDbl(TextBoxCredit22.Text)
            sumCreditsMajor = sumCreditsMajor + CR22
        Else
            CR22 = 0
        End If
        If IsNumeric(TextBoxCredit23.Text) Then
            CR23 = CDbl(TextBoxCredit23.Text)
            sumCreditsMajor = sumCreditsMajor + CR23
        Else
            CR23 = 0
        End If
        If IsNumeric(TextBoxCredit24.Text) Then
            CR24 = CDbl(TextBoxCredit24.Text)
            sumCreditsMajor = sumCreditsMajor + CR24
        Else
            CR24 = 0
        End If
        If IsNumeric(TextBoxCredit25.Text) Then
            CR25 = CDbl(TextBoxCredit25.Text)
            sumCreditsMajor = sumCreditsMajor + CR25
        Else
            CR25 = 0
        End If
        If CDbl(TextBoxQP14.Text) <> -1 Then
            TQP14 = CDbl(TextBoxQP14.Text) * CR14
            sumTQPMajor = sumTQPMajor + TQP14
            TextBoxTQP14.Text = Str(TQP14)
            CheckBox14.Checked = True
            CheckBox14.Text = "True"
            CheckBoxLangI.Checked = True
            CheckBoxLangI.Text = "True"
        Else
            Majornames(counter1) = TextBoxCoureTitle14.Text
            counter1 += 1
        End If
        If CDbl(TextBoxQP15.Text) <> -1 Then
            TQP15 = CDbl(TextBoxQP15.Text) * CR15
            sumTQPMajor = sumTQPMajor + TQP15
            TextBoxTQP15.Text = Str(TQP15)
            CheckBox15.Checked = True
            CheckBox15.Text = "True"
            CheckBoxLangII.Checked = True
            CheckBoxLangII.Text = "True"
        Else
            Majornames(counter1) = TextBoxCoureTitle15.Text
            counter1 += 1
        End If
        If CDbl(TextBoxQP16.Text) <> -1 Then
            TQP16 = CDbl(TextBoxQP16.Text) * CR16
            sumTQPMajor = sumTQPMajor + TQP16
            TextBoxTQP16.Text = Str(TQP16)
            CheckBox16.Checked = True
            CheckBox16.Text = "True"
        Else
            Majornames(counter1) = TextBoxCoureTitle16.Text
            counter1 += 1
        End If
        If CDbl(TextBoxQP17.Text) <> -1 Then
            TQP17 = CDbl(TextBoxQP17.Text) * CR17
            sumTQPMajor = sumTQPMajor + TQP17
            TextBoxTQP17.Text = Str(TQP17)
            CheckBox17.Checked = True
            CheckBox17.Text = "True"
        Else
            Majornames(counter1) = TextBoxCoureTitle17.Text
            counter1 += 1
        End If
        If CDbl(TextBoxQP18.Text) <> -1 Then
            TQP18 = CDbl(TextBoxQP18.Text) * CR18
            sumTQPMajor = sumTQPMajor + TQP18
            TextBoxTQP18.Text = Str(TQP18)
            CheckBox18.Checked = True
            CheckBox18.Text = "True"
        Else
            Majornames(counter1) = TextBoxCoureTitle18.Text
            counter1 += 1
        End If
        If CDbl(TextBoxQP19.Text) <> -1 Then
            TQP19 = CDbl(TextBoxQP19.Text) * CR19
            sumTQPMajor = sumTQPMajor + TQP19
            TextBoxTQP19.Text = Str(TQP19)
            CheckBox19.Checked = True
            CheckBox19.Text = "True"
        Else
            Majornames(counter1) = TextBoxCoureTitle19.Text
            counter1 += 1
        End If
        If CDbl(TextBoxQP20.Text) <> -1 Then
            TQP20 = CDbl(TextBoxQP20.Text) * CR20
            sumTQPMajor = sumTQPMajor + TQP20
            TextBoxTQP20.Text = Str(TQP20)
            CheckBox20.Checked = True
            CheckBox20.Text = "True"
        Else
            Majornames(counter1) = TextBoxCoureTitle20.Text
            counter1 += 1
        End If
        If CDbl(TextBoxQP21.Text) <> -1 Then
            TQP21 = CDbl(TextBoxQP21.Text) * CR21
            sumTQPMajor = sumTQPMajor + TQP21
            TextBoxTQP21.Text = Str(TQP21)
            CheckBox21.Checked = True
            CheckBox21.Text = "True"
        Else
            Majornames(counter1) = TextBoxCoureTitle21.Text
            counter1 += 1
        End If
        If CDbl(TextBoxQP22.Text) <> -1 Then
            TQP22 = CDbl(TextBoxQP22.Text) * CR22
            sumTQPMajor = sumTQPMajor + TQP22
            TextBoxTQP22.Text = Str(TQP22)
            CheckBox22.Checked = True
            CheckBox22.Text = "True"
        Else
            Majornames(counter1) = TextBoxCoureTitle22.Text
            counter1 += 1
        End If
        If CDbl(TextBoxQP23.Text) <> -1 Then
            TQP23 = CDbl(TextBoxQP23.Text) * CR23
            sumTQPMajor = sumTQPMajor + TQP23
            TextBoxTQP23.Text = Str(TQP23)
            CheckBox23.Checked = True
            CheckBox23.Text = "True"
        Else
            Majornames(counter1) = TextBoxCoureTitle23.Text
            counter1 += 1
        End If
        If CDbl(TextBoxQP24.Text) <> -1 Then
            TQP24 = CDbl(TextBoxQP24.Text) * CR24
            sumTQPMajor = sumTQPMajor + TQP24
            TextBoxTQP24.Text = Str(TQP24)
            CheckBox24.Checked = True
            CheckBox24.Text = "True"
        Else
            Majornames(counter1) = TextBoxCoureTitle24.Text
            counter1 += 1
        End If
        If CDbl(TextBoxQP25.Text) <> -1 Then
            TQP25 = CDbl(TextBoxQP25.Text) * CR25
            sumTQPMajor = sumTQPMajor + TQP25
            TextBoxTQP25.Text = Str(TQP25)
            CheckBox25.Checked = True
            CheckBox25.Text = "True"
        Else
            Majornames(counter1) = TextBoxCoureTitle25.Text
            counter1 += 1
        End If
        GPA = sumTQPMajor / sumCreditsMajor
        LabelGPAMajor.Text = "GPA = [ " & String.Format("{0:F3}", GPA) & " ]"
    End Sub
    Private Sub calculateGPA()
        counter = 0
        sumCredits = 0
        sumTQP = 0
        Dim GPA = 0.00
        Dim CR1, CR2, CR3, CR4, CR5, CR6, CR7, CR8, CR9, CR10, CR11, CR12, CR13 As Double
        Dim TQP1, TQP2, TQP3, TQP4, TQP5, TQP6, TQP7, TQP8, TQP9, TQP10, TQP11, TQP12, TQP13 As Double
        TextBoxQP1.Text = QP(ComboBoxLG1.SelectedItem)
        TextBoxQP2.Text = QP(ComboBoxLG2.SelectedItem)
        TextBoxQP3.Text = QP(ComboBoxLG3.SelectedItem)
        TextBoxQP4.Text = QP(ComboBoxLG4.SelectedItem)
        TextBoxQP5.Text = QP(ComboBoxLG5.SelectedItem)
        TextBoxQP6.Text = QP(ComboBoxLG6.SelectedItem)
        TextBoxQP7.Text = QP(ComboBoxLG7.SelectedItem)
        TextBoxQP8.Text = QP(ComboBoxLG8.SelectedItem)
        TextBoxQP9.Text = QP(ComboBoxLG9.SelectedItem)
        TextBoxQP10.Text = QP(ComboBoxLG10.SelectedItem)
        TextBoxQP11.Text = QP(ComboBoxLG11.SelectedItem)
        TextBoxQP12.Text = QP(ComboBoxLG12.SelectedItem)
        TextBoxQP13.Text = QP(ComboBoxLG13.SelectedItem)
        If IsNumeric(TextBoxCredit1.Text) Then
            CR1 = CDbl(TextBoxCredit1.Text)
            sumCredits = sumCredits + CR1
        Else
            CR1 = 0
        End If
        If IsNumeric(TextBoxCredit2.Text) Then
            CR2 = CDbl(TextBoxCredit2.Text)
            sumCredits = sumCredits + CR2
        Else
            CR2 = 0
        End If
        If IsNumeric(TextBoxCredit4.Text) Then
            CR4 = CDbl(TextBoxCredit4.Text)
            sumCredits = sumCredits + CR4
        Else
            CR4 = 0
        End If
        If IsNumeric(TextBoxCredit3.Text) Then
            CR3 = CDbl(TextBoxCredit3.Text)
            sumCredits = sumCredits + CR3
        Else
            CR3 = 0
        End If
        If IsNumeric(TextBoxCredit5.Text) Then
            CR5 = CDbl(TextBoxCredit5.Text)
            sumCredits = sumCredits + CR5
        Else
            CR5 = 0
        End If
        If IsNumeric(TextBoxCredit6.Text) Then
            CR6 = CDbl(TextBoxCredit6.Text)
            sumCredits = sumCredits + CR6
        Else
            CR6 = 0
        End If
        If IsNumeric(TextBoxCredit7.Text) Then
            CR7 = CDbl(TextBoxCredit7.Text)
            sumCredits = sumCredits + CR7
        Else
            CR7 = 0
        End If
        If IsNumeric(TextBoxCredit8.Text) Then
            CR8 = CDbl(TextBoxCredit8.Text)
            sumCredits = sumCredits + CR8
        Else
            CR8 = 0
        End If
        If IsNumeric(TextBoxCredit9.Text) Then
            CR9 = CDbl(TextBoxCredit9.Text)
            sumCredits = sumCredits + CR9
        Else
            CR9 = 0
        End If
        If IsNumeric(TextBoxCredit10.Text) Then
            CR10 = CDbl(TextBoxCredit10.Text)
            sumCredits = sumCredits + CR10
        Else
            CR10 = 0
        End If
        If IsNumeric(TextBoxCredit11.Text) Then
            CR11 = CDbl(TextBoxCredit11.Text)
            sumCredits = sumCredits + CR11
        Else
            CR11 = 0
        End If
        If IsNumeric(TextBoxCredit12.Text) Then
            CR12 = CDbl(TextBoxCredit12.Text)
            sumCredits = sumCredits + CR12
        Else
            CR12 = 0
        End If
        If IsNumeric(TextBoxCredit13.Text) Then
            CR13 = CDbl(TextBoxCredit13.Text)
            sumCredits = sumCredits + CR13
        Else
            CR13 = 0
        End If
        If CDbl(TextBoxQP1.Text) <> -1 Then
            TQP1 = CDbl(TextBoxQP1.Text) * CR1
            sumTQP = sumTQP + TQP1
            TextBoxTQP1.Text = Str(TQP1)
            CheckBox1.Checked = True
            CheckBox1.Text = "True"
        Else
            Uninames(counter) = TextBoxCourseTitle1.Text
            counter += 1
        End If
        If CDbl(TextBoxQP2.Text) <> -1 Then
            TQP2 = CDbl(TextBoxQP2.Text) * CR2
            sumTQP = sumTQP + TQP2
            TextBoxTQP2.Text = Str(TQP2)
            CheckBox2.Checked = True
            CheckBox2.Text = "True"
        Else
            Uninames(counter) = TextBoxCourseTitle2.Text
            counter += 1
        End If
        If CDbl(TextBoxQP3.Text) <> -1 Then
            TQP3 = CDbl(TextBoxQP3.Text) * CR3
            sumTQP = sumTQP + TQP3
            TextBoxTQP3.Text = Str(TQP3)
            CheckBox3.Checked = True
            CheckBox3.Text = "True"
        Else
            Uninames(counter) = TextBoxCourseTitle3.Text
            counter += 1
        End If
        If CDbl(TextBoxQP4.Text) <> -1 Then
            TQP4 = CDbl(TextBoxQP4.Text) * CR4
            sumTQP = sumTQP + TQP4
            TextBoxTQP4.Text = Str(TQP4)
            CheckBox4.Checked = True
            CheckBox4.Text = "True"
        Else
            Uninames(counter) = TextBoxCourseTitle4.Text
            counter += 1
        End If
        If CDbl(TextBoxQP5.Text) <> -1 Then
            TQP5 = CDbl(TextBoxQP5.Text) * CR5
            sumTQP = sumTQP + TQP5
            TextBoxTQP5.Text = Str(TQP5)
            CheckBox5.Checked = True
            CheckBox5.Text = "True"
        Else
            Uninames(counter) = TextBoxCourseTitle5.Text
            counter += 1
        End If
        If CDbl(TextBoxQP6.Text) <> -1 Then
            TQP6 = CDbl(TextBoxQP6.Text) * CR6
            sumTQP = sumTQP + TQP6
            TextBoxTQP6.Text = Str(TQP6)
            CheckBox6.Checked = True
            CheckBox6.Text = "True"
        Else
            Uninames(counter) = TextBoxCourseTitle6.Text
            counter += 1
        End If
        If CDbl(TextBoxQP7.Text) <> -1 Then
            TQP7 = CDbl(TextBoxQP7.Text) * CR7
            sumTQP = sumTQP + TQP7
            TextBoxTQP7.Text = Str(TQP7)
            CheckBox7.Checked = True
            CheckBox7.Text = "True"
        Else
            Uninames(counter) = TextBoxCourseTitle7.Text
            counter += 1
        End If
        If CDbl(TextBoxQP8.Text) <> -1 Then
            TQP8 = CDbl(TextBoxQP8.Text) * CR8
            sumTQP = sumTQP + TQP8
            TextBoxTQP8.Text = Str(TQP8)
            CheckBox8.Checked = True
            CheckBox8.Text = "True"
        Else
            Uninames(counter) = TextBoxCourseTitle8.Text
            counter += 1
        End If
        If CDbl(TextBoxQP9.Text) <> -1 Then
            TQP9 = CDbl(TextBoxQP9.Text) * CR9
            sumTQP = sumTQP + TQP9
            TextBoxTQP9.Text = Str(TQP9)
            CheckBox9.Checked = True
            CheckBox9.Text = "True"
        Else
            Uninames(counter) = TextBoxCourseTitle9.Text
            counter += 1
        End If
        If CDbl(TextBoxQP10.Text) <> -1 Then
            TQP10 = CDbl(TextBoxQP10.Text) * CR10
            sumTQP = sumTQP + TQP10
            TextBoxTQP10.Text = Str(TQP10)
            CheckBox10.Checked = True
            CheckBox10.Text = "True"
        Else
            Uninames(counter) = TextBoxCourseTitle10.Text
            counter += 1
        End If
        If CDbl(TextBoxQP11.Text) <> -1 Then
            TQP11 = CDbl(TextBoxQP11.Text) * CR11
            sumTQP = sumTQP + TQP11
            TextBoxTQP11.Text = Str(TQP11)
            CheckBox11.Checked = True
            CheckBox11.Text = "True"
        Else
            Uninames(counter) = TextBoxCourseTitle11.Text
            counter += 1
        End If
        If CDbl(TextBoxQP12.Text) <> -1 Then
            TQP12 = CDbl(TextBoxQP12.Text) * CR12
            sumTQP = sumTQP + TQP12
            TextBoxTQP12.Text = Str(TQP12)
            CheckBox12.Checked = True
            CheckBox12.Text = "True"
        Else
            Uninames(counter) = TextBoxCourseTitle12.Text
            counter += 1
        End If
        If CDbl(TextBoxQP13.Text) <> -1 Then
            TQP13 = CDbl(TextBoxQP13.Text) * CR13
            sumTQP = sumTQP + TQP13
            TextBoxTQP13.Text = Str(TQP13)
            CheckBox13.Checked = True
            CheckBox13.Text = "True"
        Else
            Uninames(counter) = TextBoxCourseTitle13.Text
            counter += 1
        End If
        GPA = sumTQP / sumCredits
        LabelGPA.Text = "GPA = [ " & String.Format("{0:F3}", GPA) & " ]"
    End Sub
    Private Sub TextBoxCredit_TextChanged(sender As Object, e As EventArgs) Handles TextBoxCredit1.TextChanged, TextBoxCredit9.TextChanged, TextBoxCredit8.TextChanged, TextBoxCredit7.TextChanged, TextBoxCredit6.TextChanged, TextBoxCredit5.TextChanged, TextBoxCredit4.TextChanged, TextBoxCredit3.TextChanged, TextBoxCredit2.TextChanged, TextBoxCredit13.TextChanged, TextBoxCredit12.TextChanged, TextBoxCredit11.TextChanged, TextBoxCredit10.TextChanged, TextBox5.TextChanged, TextBox1.TextChanged
        Call calculateGPA()
    End Sub
    Private Sub TextBoxCreditMajor_TextChanged(sender As Object, e As EventArgs) Handles TextBoxCredit14.TextChanged, TextBoxCredit25.TextChanged, TextBoxCredit24.TextChanged, TextBoxCredit23.TextChanged, TextBoxCredit22.TextChanged, TextBoxCredit21.TextChanged, TextBoxCredit20.TextChanged, TextBoxCredit19.TextChanged, TextBoxCredit18.TextChanged, TextBoxCredit17.TextChanged, TextBoxCredit16.TextChanged, TextBoxCredit15.TextChanged
        Call calculateGPAMajor()
    End Sub

    Private Sub ComboBoxLGMajor_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBoxLG14.SelectedIndexChanged, ComboBoxLG25.SelectedIndexChanged, ComboBoxLG24.SelectedIndexChanged, ComboBoxLG23.SelectedIndexChanged, ComboBoxLG22.SelectedIndexChanged, ComboBoxLG21.SelectedIndexChanged, ComboBoxLG20.SelectedIndexChanged, ComboBoxLG19.SelectedIndexChanged, ComboBoxLG18.SelectedIndexChanged, ComboBoxLG17.SelectedIndexChanged, ComboBoxLG16.SelectedIndexChanged, ComboBoxLG15.SelectedIndexChanged
        Call calculateGPAMajor()
    End Sub

    Private Sub ComboBoxLG_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBoxLG1.SelectedIndexChanged, ComboBoxLG9.SelectedIndexChanged, ComboBoxLG8.SelectedIndexChanged, ComboBoxLG7.SelectedIndexChanged, ComboBoxLG6.SelectedIndexChanged, ComboBoxLG5.SelectedIndexChanged, ComboBoxLG4.SelectedIndexChanged, ComboBoxLG3.SelectedIndexChanged, ComboBoxLG2.SelectedIndexChanged, ComboBoxLG13.SelectedIndexChanged, ComboBoxLG12.SelectedIndexChanged, ComboBoxLG11.SelectedIndexChanged, ComboBoxLG10.SelectedIndexChanged, ComboBox2.SelectedIndexChanged, ComboBox1.SelectedIndexChanged
        Call calculateGPA()
    End Sub

    Private Sub ButtonResetUni_Click(sender As Object, e As EventArgs) Handles ButtonResetUni.Click
        ComboBoxLG1.SelectedItem = "--"
        ComboBoxLG2.SelectedItem = "--"
        ComboBoxLG3.SelectedItem = "--"
        ComboBoxLG4.SelectedItem = "--"
        ComboBoxLG5.SelectedItem = "--"
        ComboBoxLG6.SelectedItem = "--"
        ComboBoxLG7.SelectedItem = "--"
        ComboBoxLG8.SelectedItem = "--"
        ComboBoxLG9.SelectedItem = "--"
        ComboBoxLG10.SelectedItem = "--"
        ComboBoxLG11.SelectedItem = "--"
        ComboBoxLG12.SelectedItem = "--"
        ComboBoxLG13.SelectedItem = "--"
        TextBoxCredit1.Text = ""
        TextBoxCredit2.Text = ""
        TextBoxCredit3.Text = ""
        TextBoxCredit4.Text = ""
        TextBoxCredit5.Text = ""
        TextBoxCredit6.Text = ""
        TextBoxCredit7.Text = ""
        TextBoxCredit8.Text = ""
        TextBoxCredit9.Text = ""
        TextBoxCredit10.Text = ""
        TextBoxCredit11.Text = ""
        TextBoxCredit12.Text = ""
        TextBoxCredit13.Text = ""
        TextBoxQP1.Text = ""
        TextBoxQP2.Text = ""
        TextBoxQP3.Text = ""
        TextBoxQP4.Text = ""
        TextBoxQP5.Text = ""
        TextBoxQP6.Text = ""
        TextBoxQP7.Text = ""
        TextBoxQP8.Text = ""
        TextBoxQP9.Text = ""
        TextBoxQP10.Text = ""
        TextBoxQP11.Text = ""
        TextBoxQP12.Text = ""
        TextBoxQP13.Text = ""
        TextBoxTQP1.Text = ""
        TextBoxTQP2.Text = ""
        TextBoxTQP3.Text = ""
        TextBoxTQP4.Text = ""
        TextBoxTQP5.Text = ""
        TextBoxTQP6.Text = ""
        TextBoxTQP7.Text = ""
        TextBoxTQP8.Text = ""
        TextBoxTQP9.Text = ""
        TextBoxTQP10.Text = ""
        TextBoxTQP11.Text = ""
        TextBoxTQP12.Text = ""
        TextBoxTQP13.Text = ""
        LabelGPA.Text = "[GPA = 0.00 ]"
        CheckBox1.Checked = False
        CheckBox1.Text = "False"
        CheckBox2.Checked = False
        CheckBox2.Text = "False"
        CheckBox3.Checked = False
        CheckBox3.Text = "False"
        CheckBox4.Checked = False
        CheckBox4.Text = "False"
        CheckBox5.Checked = False
        CheckBox5.Text = "False"
        CheckBox6.Checked = False
        CheckBox6.Text = "False"
        CheckBox7.Checked = False
        CheckBox7.Text = "False"
        CheckBox8.Checked = False
        CheckBox8.Text = "False"
        CheckBox9.Checked = False
        CheckBox9.Text = "False"
        CheckBox10.Checked = False
        CheckBox10.Text = "False"
        CheckBox11.Checked = False
        CheckBox11.Text = "False"
        CheckBox12.Checked = False
        CheckBox12.Text = "False"
        CheckBox13.Checked = False
        CheckBox13.Text = "False"
    End Sub

    Private Sub TextBoxCreditMinor_TextChanged(sender As Object, e As EventArgs) Handles TextBoxCredit26.TextChanged, TextBoxCredit30.TextChanged, TextBoxCredit29.TextChanged, TextBoxCredit28.TextChanged, TextBoxCredit27.TextChanged
        Call calculateGPAMinor()
    End Sub

    Private Sub ComboBoxLGMinor_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBoxLG26.SelectedIndexChanged, ComboBoxLG30.SelectedIndexChanged, ComboBoxLG29.SelectedIndexChanged, ComboBoxLG28.SelectedIndexChanged, ComboBoxLG27.SelectedIndexChanged
        Call calculateGPAMinor()
    End Sub

    Private Sub ButtonReseTMinor_Click(sender As Object, e As EventArgs) Handles ButtonReseTMinor.Click
        ComboBoxLG26.SelectedItem = "--"
        ComboBoxLG27.SelectedItem = "--"
        ComboBoxLG28.SelectedItem = "--"
        ComboBoxLG29.SelectedItem = "--"
        ComboBoxLG30.SelectedItem = "--"
        TextBoxCredit26.Text = ""
        TextBoxCredit27.Text = ""
        TextBoxCredit28.Text = ""
        TextBoxCredit29.Text = ""
        TextBoxCredit30.Text = ""
        TextBoxQP26.Text = ""
        TextBoxQP27.Text = ""
        TextBoxQP28.Text = ""
        TextBoxQP29.Text = ""
        TextBoxQP30.Text = ""
        TextBoxTQP26.Text = ""
        TextBoxTQP27.Text = ""
        TextBoxTQP28.Text = ""
        TextBoxTQP29.Text = ""
        TextBoxTQP30.Text = ""
        CheckBox26.Checked = False
        CheckBox26.Text = "False"
        CheckBox27.Checked = False
        CheckBox27.Text = "False"
        CheckBox28.Checked = False
        CheckBox28.Text = "False"
        CheckBox29.Checked = False
        CheckBox29.Text = "False"
        CheckBox30.Checked = False
        CheckBox30.Text = "False"
    End Sub

    Private Sub TextBoxCreditElectives_TextChanged(sender As Object, e As EventArgs) Handles TextBoxCredit31.TextChanged, TextBoxCredit39.TextChanged, TextBoxCredit38.TextChanged, TextBoxCredit37.TextChanged, TextBoxCredit36.TextChanged, TextBoxCredit35.TextChanged, TextBoxCredit34.TextChanged, TextBoxCredit33.TextChanged, TextBoxCredit32.TextChanged
        Call calculateGPAElectives()
    End Sub

    Private Sub ComboBoxLGElectives_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBoxLG31.SelectedIndexChanged, ComboBoxLG39.SelectedIndexChanged, ComboBoxLG38.SelectedIndexChanged, ComboBoxLG37.SelectedIndexChanged, ComboBoxLG36.SelectedIndexChanged, ComboBoxLG35.SelectedIndexChanged, ComboBoxLG34.SelectedIndexChanged, ComboBoxLG33.SelectedIndexChanged, ComboBoxLG32.SelectedIndexChanged
        Call calculateGPAElectives()
    End Sub

    Private Sub TabPage5_Enter(sender As Object, e As EventArgs) Handles TabPage5.Enter
        Call calculateGPA()
        Call calculateGPAElectives()
        Call calculateGPAMajor()
        Call calculateGPAMinor()
        totalCredit = sumCredits + sumCreditsElective + sumCreditsMajor + sumCreditsMinor
        totalTQP = sumTQP + sumTQPElective + sumTQPMajor + sumTQPMinor
        LabelTotalCredits.Visible = True
        LabelTotalCredits.Text = "Total Credits: " & totalCredit
        Dim GPA As Double
        GPA = totalTQP / totalCredit
        LabelCGPA.Text = "CGPA = [ " & String.Format("{0:F3}", GPA) & " ]"
        GPA = sumTQP / sumCredits
        LabelGPAMi.Visible = True
        LabelGPAMa.Visible = True
        LabelGPAUni.Visible = True
        LabelGPAGen.Visible = True
        LabelGPAUni.Text = "GPA: " & String.Format("{0:F3}", GPA)
        GPA = sumTQPMajor / sumCreditsMajor
        LabelGPAMa.Text = "GPA: " & String.Format("{0:F3}", GPA)
        GPA = sumTQPMinor / sumCreditsMinor
        LabelGPAMi.Text = "GPA: " & String.Format("{0:F3}", GPA)
        GPA = sumTQPElective / sumCreditsElective
        LabelGPAGen.Text = "GPA: " & String.Format("{0:F3}", GPA)
        Dim I As Integer
        LabelErrors.Visible = True
        LabelSN.Visible = True
        If counter = 0 Then
            LabelErrors.Text = "Completed University Core Requirements"
            LabelSN.Text = ""
        ElseIf counter = 1 Then
            LabelErrors.Text = "Incomplete Courses: " & vbCrLf
            LabelSN.Text = "#" & vbCrLf
            LabelSN.Text += Str(1) & vbCrLf
            LabelErrors.Text += Uninames(0) & vbCrLf
        Else
            LabelErrors.Text = "Incomplete Courses: " & vbCrLf
            LabelSN.Text = "#" & vbCrLf
            For I = 0 To counter - 1 Step 1
                LabelSN.Text += Str(I + 1) & vbCrLf
                LabelErrors.Text += Uninames(I) & vbCrLf
            Next
        End If
        LabelErrorsM.Visible = True
        LabelSNM.Visible = True
        If counter1 = 0 Then
            LabelErrorsM.Text = "Completed Major Core Courses"
            LabelSNM.Text = ""
        ElseIf counter1 = 1 Then
            LabelErrorsM.Text = "Incomplete Courses: " & vbCrLf
            LabelSNM.Text = "#" & vbCrLf
            LabelSNM.Text += Str(1) & vbCrLf
            LabelErrorsM.Text += Majornames(0) & vbCrLf
        Else
            LabelErrorsM.Text = "Incomplete Courses: " & vbCrLf
            LabelSNM.Text = "#" & vbCrLf
            For I = 0 To counter1 - 1 Step 1
                LabelSNM.Text += Str(I + 1) & vbCrLf
                LabelErrorsM.Text += Majornames(I) & vbCrLf
            Next
        End If

        LabelErrorsMi.Visible = True
        LabelSNMi.Visible = True
        If counter2 = 0 Then
            LabelErrorsM.Text = "Completed Major Core Courses"
            LabelSNM.Text = ""
        ElseIf counter2 = 1 Then
            LabelErrorsMi.Text = "Incomplete Courses: " & vbCrLf
            LabelSNMi.Text = "#" & vbCrLf
            LabelSNMi.Text += Str(1) & vbCrLf
            LabelErrorsMi.Text += Minornames(0) & vbCrLf
        Else
            LabelErrorsMi.Text = "Incomplete Courses: " & vbCrLf
            LabelSNMi.Text = "#" & vbCrLf
            For I = 0 To counter2 - 1 Step 1
                LabelSNMi.Text += Str(I + 1) & vbCrLf
                LabelErrorsMi.Text += Minornames(I) & vbCrLf
            Next
        End If

        LabelErrorsGen.Visible = True
        LabelSNGen.Visible = True
        If counter3 = 0 Then
            LabelErrorsGen.Text = "Completed Major Core Courses"
            LabelSNGen.Text = ""
        ElseIf counter3 = 1 Then
            LabelErrorsGen.Text = "Incomplete Courses: " & vbCrLf
            LabelSNGen.Text = "#" & vbCrLf
            LabelSNGen.Text += Str(1) & vbCrLf
            LabelErrorsGen.Text += Electivenames(0) & vbCrLf
        Else
            LabelErrorsGen.Text = "Incomplete Courses: " & vbCrLf
            LabelSNGen.Text = "#" & vbCrLf
            For I = 0 To counter3 - 1 Step 1
                LabelSNGen.Text += Str(I + 1) & vbCrLf
                LabelErrorsGen.Text += Electivenames(I) & vbCrLf
            Next
        End If
    End Sub
End Class
